import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { getFullCssContent } from './helpers/css-helper.js';

describe('AGENTS.md & PLAN.md Compliance and Regression Guard', () => {
  const srcDir = path.resolve(__dirname, '../src');

  const getAllFiles = (dir, ext) => {
    let results = [];
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        results = results.concat(getAllFiles(fullPath, ext));
      } else if (entry.isFile() && entry.name.endsWith(ext)) {
        results.push({
          name: path.relative(srcDir, fullPath).replace(/\\/g, '/'),
          content: fs.readFileSync(fullPath, 'utf-8')
        });
      }
    }
    return results;
  };

  const jsFiles = getAllFiles(srcDir, '.js');
  const htmlFiles = getAllFiles(srcDir, '.html');
  const cssFiles = getAllFiles(srcDir, '.css');

  const cssContent = getFullCssContent();

  describe('1. No Emoji Compliance (AGENTS.md Sec 2)', () => {
    // Windows 8.1 で豆腐化する Unicode 絵文字・特殊記号（⭐, ★, 🚀, ❌, 👍 等）の混入を禁止
    const emojiRegex = /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u;

    it('should not contain emojis in any JavaScript source file', () => {
      for (const file of jsFiles) {
        const matches = file.content.match(emojiRegex);
        expect(matches, `Emoji detected in src/${file.name}: ${matches ? matches[0] : ''}`).toBeNull();
      }
    });

    it('should not contain emojis in any HTML file in src/', () => {
      for (const file of htmlFiles) {
        const matches = file.content.match(emojiRegex);
        expect(matches, `Emoji detected in src/${file.name}: ${matches ? matches[0] : ''}`).toBeNull();
      }
    });

    it('should not contain emojis in style.css', () => {
      const matches = cssContent.match(emojiRegex);
      expect(matches, `Emoji detected in style.css: ${matches ? matches[0] : ''}`).toBeNull();
    });
  });

  describe('2. Chromium 109 Compatibility (AGENTS.md Sec 1 & PLAN.md Sec 1.2)', () => {
    // Chromium 110 以降で導入された新しい配列操作メソッドの利用を禁止
    const bannedMethods = [
      'toSorted',
      'toReversed',
      'toSpliced',
      'with',
      'findLast',
      'findLastIndex'
    ];

    it('should not use post-Chromium-109 Array methods in JavaScript sources', () => {
      for (const file of jsFiles) {
        for (const method of bannedMethods) {
          const regex = new RegExp(`\\.${method}\\s*\\(`, 'g');
          const matches = file.content.match(regex);
          expect(matches, `Banned ECMAScript method '.${method}()' found in src/${file.name} (Chromium 109 incompatible)`).toBeNull();
        }
      }
    });
  });

  describe('3. Objective Terminology Guard (AGENTS.md Sec 2 & Sec 4)', () => {
    // UIテキストやコメントにおける過度な誇張表現の混入を防止
    const exaggeratedTerms = ['神速', '爆速'];

    it('should not contain exaggerated marketing buzzwords in JavaScript sources', () => {
      for (const file of jsFiles) {
        for (const term of exaggeratedTerms) {
          const regex = new RegExp(term, 'g');
          const matches = file.content.match(regex);
          expect(matches, `Exaggerated term "${term}" found in src/${file.name}`).toBeNull();
        }
      }
    });

    it('should not contain exaggerated marketing buzzwords in Cargo.toml', () => {
      const cargoTomlPath = path.resolve(__dirname, '../src-tauri/Cargo.toml');
      const cargoContent = fs.readFileSync(cargoTomlPath, 'utf-8');
      for (const term of exaggeratedTerms) {
        const regex = new RegExp(term, 'g');
        const matches = cargoContent.match(regex);
        expect(matches, `Exaggerated term "${term}" found in Cargo.toml`).toBeNull();
      }
    });

    it('should not contain exaggerated marketing buzzwords like "一瞬" in CSS sources (including comments)', () => {
      const cssExaggeratedTerms = ['神速', '爆速', '一瞬'];
      for (const file of cssFiles) {
        for (const term of cssExaggeratedTerms) {
          const regex = new RegExp(term, 'g');
          const matches = file.content.match(regex);
          expect(matches, `Exaggerated term "${term}" found in src/${file.name}`).toBeNull();
        }
      }
    });

    it('should not contain casual bug-fix comments like "レースコンディション対策" in JS and CSS sources', () => {
      const casualTerms = ['レースコンディション対策', 'バグ回避', '回避策'];
      for (const file of [...jsFiles, ...cssFiles]) {
        for (const term of casualTerms) {
          const regex = new RegExp(term, 'g');
          const matches = file.content.match(regex);
          expect(matches, `Casual comment "${term}" found in src/${file.name} (must be elevated to objective technical explanation)`).toBeNull();
        }
      }
    });
  });

  describe('4. Modal and Dialog Header Consistency (AGENTS.md Sec 2)', () => {
    it('should not have border-bottom on modal headers in style.css', () => {
      const modalHeaderMatch = cssContent.match(/\.modal-header\s*\{[^}]*\}/g) || [];
      for (const block of modalHeaderMatch) {
        expect(block).not.toMatch(/border-bottom:\s*(?!none\b)[^;]+;/);
      }
    });

    it('should use SVG close button in modal headers across HTML templates', () => {
      for (const file of htmlFiles) {
        if (file.content.includes('modal-header')) {
          expect(file.content).toContain('modal-close-btn');
          expect(file.content).toContain('<svg');
        }
      }
    });
  });

  describe('5. Native Runtime Architecture Boundary (AGENTS.md Sec 1 & 3)', () => {
    it('should document update_thumbnails.py as a standalone tool not invoked by runtime', () => {
      const scriptPath = path.resolve(__dirname, '../scripts/update_thumbnails.py');
      expect(fs.existsSync(scriptPath)).toBe(true);
      const content = fs.readFileSync(scriptPath, 'utf-8');
      expect(content).toContain('Veloce 本体のランタイム（Tauri / Rust / WebView）からは一切呼び出されません');
    });

    it('should not invoke python scripts from src/ runtime JavaScript', () => {
      // ランタイムのJSコードから Python スクリプトの実行や直接参照がないことを保証
      for (const file of jsFiles) {
        expect(file.content).not.toMatch(/update_thumbnails\.py/);
        expect(file.content).not.toMatch(/python\s+.*\.py/i);
      }
    });
  });
});
