import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { getFullCssContent } from './helpers/css-helper.js';

describe('Style Unification and DOM Optimization Tests', () => {
  const rootDir = path.resolve(__dirname, '..');
  const indexHtmlPath = path.join(rootDir, 'src', 'index.html');
  const rendererJsPath = path.join(rootDir, 'src', 'renderer', 'renderer.js');
  const rendererInspectorJsPath = path.join(rootDir, 'src', 'renderer', 'renderer-inspector.js');
  const rendererDialogsJsPath = path.join(rootDir, 'src', 'renderer', 'renderer-dialogs.js');
  const rendererUiJsPath = path.join(rootDir, 'src', 'renderer', 'renderer-ui.js');

  it('verifies style.css color token definitions and zero hardcoded RGB values', () => {
    const css = getFullCssContent();

    // --glow-gold-rgb が :root に定義されていること
    expect(css).toContain('--glow-gold-rgb: 230, 199, 98;');
    expect(css).toContain('--text-rgb: 205, 219, 224;');
    expect(css).toContain('--bg-darker-rgb: 30, 30, 30;');

    // 230, 199, 98 の出現回数が定義の1回のみであること
    const goldRgbMatches = css.match(/230,\s*199,\s*98/g);
    expect(goldRgbMatches).not.toBeNull();
    expect(goldRgbMatches.length).toBe(1);

    // 224, 82, 99 の出現回数が定義の1回のみであること
    const dangerRgbMatches = css.match(/224,\s*82,\s*99/g);
    expect(dangerRgbMatches).not.toBeNull();
    expect(dangerRgbMatches.length).toBe(1);

    // 205, 219, 224 の出現回数が定義の1回のみであること
    const textRgbMatches = css.match(/205,\s*219,\s*224/g);
    expect(textRgbMatches).not.toBeNull();
    expect(textRgbMatches.length).toBe(1);

    // 30, 30, 30 の出現回数が定義の1回のみであること
    const bgDarkerRgbMatches = css.match(/30,\s*30,\s*30/g);
    expect(bgDarkerRgbMatches).not.toBeNull();
    expect(bgDarkerRgbMatches.length).toBe(1);

    // ハードコードされたフォールバック色の排除
    expect(css).not.toContain('var(--text-color, #cddbe0)');
    expect(css).not.toContain('var(--accent-color, #257e8c)');

    // 追加されたヘルパークラスが正しく存在すること
    expect(css).toContain('.diff-tag-empty {');
    expect(css).toContain('.menu-item-icon {');
    expect(css).toContain('.menu-item-text {');
    expect(css).toContain('.render-error-box {');
    expect(css).toContain('.btn-browse-path {');
    expect(css).toContain('.cond-path-input {');
    expect(css).toContain('.resizer-toggle-horizontal {');
    expect(css).toContain('.resizer-toggle-vertical {');

    // リサイザートグルがホバー時にも中央揃え translate(-50%, -50%) を維持すること（右下へのズレ防止）
    expect(css).toMatch(/\.resizer-toggle:hover\s*\{[^}]*transform:\s*translate\(-50%,\s*-50%\)\s*scale\(1\.05\);/);
  });

  it('verifies index.html has zero inline style attributes', () => {
    const html = fs.readFileSync(indexHtmlPath, 'utf-8');

    // style="..." 属性が一切存在しないこと
    const inlineStyleMatches = html.match(/\bstyle\s*=\s*["'][^"']*["']/gi);
    expect(inlineStyleMatches).toBeNull();

    // 必須要素が存在すること
    expect(html).toContain('id="border-overlay"');
    expect(html).toContain('id="bookmark-overflow-btn"');
    expect(html).toContain('id="inspector-header-path"');
  });

  it('verifies renderer-ui.js uses diff-tag-empty class and optimized height guards', () => {
    const code = fs.readFileSync(rendererUiJsPath, 'utf-8');

    // diff-tag-empty クラスが使用されていること
    expect(code).toContain('<span class="diff-tag-empty">なし</span>');

    // 仮想スクロールスペーサーとファイル行で数値キャッシュ比較ガードが使用されていること
    expect(code).toContain('topSpacer._cachedHeight !== topSpacerHeight');
    expect(code).toContain('bottomSpacer._cachedHeight !== bottomSpacerHeight');
    expect(code).toContain('tr._cachedRowHeight !== rowHeight');

    // style="..." が存在しないこと
    const inlineStyleMatches = code.match(/\bstyle\s*=\s*["'][^"']*["']/gi);
    expect(inlineStyleMatches).toBeNull();
  });

  it('verifies renderer.js, renderer-inspector.js and renderer-dialogs.js have zero inline style attributes and use optimized DOM access', () => {
    const code = fs.readFileSync(rendererJsPath, 'utf-8');
    const inspectorCode = fs.readFileSync(rendererInspectorJsPath, 'utf-8');
    const dialogsCode = fs.readFileSync(rendererDialogsJsPath, 'utf-8');

    const resizerCode = fs.readFileSync(path.join(rootDir, 'src', 'renderer', 'renderer-resizer.js'), 'utf-8');

    // style="..." 属性が一切存在しないこと
    const inlineStyleMatches = code.match(/\bstyle\s*=\s*["'][^"']*["']/gi);
    expect(inlineStyleMatches).toBeNull();
    const inspectorInlineStyleMatches = inspectorCode.match(/\bstyle\s*=\s*["'][^"']*["']/gi);
    expect(inspectorInlineStyleMatches).toBeNull();
    const dialogsInlineStyleMatches = dialogsCode.match(/\bstyle\s*=\s*["'][^"']*["']/gi);
    expect(dialogsInlineStyleMatches).toBeNull();
    const resizerInlineStyleMatches = resizerCode.match(/\bstyle\s*=\s*["'][^"']*["']/gi);
    expect(resizerInlineStyleMatches).toBeNull();

    // インスペクターコピーボタンで O(1) firstElementChild が使用されていること
    expect(inspectorCode).toContain('secEl.copyBtn = secEl.copyWrapper.firstElementChild;');

    // エラー表示で render-error-box クラスが使用されていること
    expect(inspectorCode).toContain('<div class="render-error-box">');

    // スマートフォルダ条件入力UIで適切なCSSクラスが使用されていること
    expect(dialogsCode).toContain('cond-value-input dialog-input flex-1');
    expect(dialogsCode).toContain('btn-browse-path dialog-btn');
    expect(dialogsCode).toContain('cond-path-input flex-1');

    // リサイザートグルがインラインCSSではなくクラスで指定されていること
    expect(resizerCode).toContain('resizer-toggle ${isHorizontal ? \'resizer-toggle-horizontal\' : \'resizer-toggle-vertical\'}');
    expect(resizerCode).not.toContain('btn.style.cssText =');

    // 余計な「メタデータが含まれていないか、読み取れませんでした。」の警告テキストが削除されていること
    expect(code).not.toContain('メタデータが含まれていないか、読み取れませんでした。');
  });

  it('verifies index.html maintains inspector-empty element for empty folders', () => {
    const html = fs.readFileSync(indexHtmlPath, 'utf-8');
    expect(html).toContain('id="inspector-empty"');
    expect(html).toContain('画像を選択してタグを表示');
  });

  it('verifies header heights across all panes are unified to 32px via --header-height token', () => {
    const css = getFullCssContent();

    // --header-height トークンが 32px で定義されていること
    expect(css).toContain('--header-height: 32px;');

    // サムネイルコントロールヘッダーが var(--header-height) を使用し上下均等パディングであること
    expect(css).toMatch(/#thumbnail-controls\s*\{[^}]*height:\s*var\(--header-height\);/);
    expect(css).toMatch(/#thumbnail-controls\s*\{[^}]*padding:\s*0\s+8px;/);

    // 各ペインヘッダーが var(--header-height) に統一されていること
    expect(css).toMatch(/\.pane-header\s*\{[^}]*height:\s*var\(--header-height\);/);
    expect(css).toMatch(/#file-table\s+th\s*\{[^}]*height:\s*var\(--header-height\);/);
    expect(css).toMatch(/\.inspector-header-layout\s*\{[^}]*height:\s*var\(--header-height\);/);
  });

  it('verifies resizer-left-pane is removed from flow when left-top is collapsed to align folder header height with thumbnail controls', () => {
    const css = getFullCssContent();

    // #left-pane が position: relative を持っていること
    expect(css).toMatch(/#left-pane\s*\{[^}]*position:\s*relative;/);

    // 左上（スマートフォルダ）折りたたみ時に #resizer-left-pane が position: absolute でフロー外になり、フォルダヘッダーがサムネイルヘッダーと同一高さラインに整列すること
    expect(css).toMatch(/:root\[data-left-top-collapsed="true"\]\s+#resizer-left-pane\s*\{[^}]*position:\s*absolute;/);
    expect(css).toMatch(/:root\[data-left-top-collapsed="true"\]\s+#resizer-left-pane\s*\{[^}]*top:\s*0;/);
  });

  it('verifies resizers offset their height via negative margin so header heights are identical whether upper panes are shown or collapsed', () => {
    const css = getFullCssContent();

    // スマートフォルダ表示時でもフォルダヘッダー高さ(32px)がリサイザー(4px)で膨らまないよう、
    // #resizer-left-pane に margin-bottom: -4px が設定されていること
    expect(css).toMatch(/#resizer-left-pane\s*\{[^}]*margin-bottom:\s*-4px;/);

    // リストペイン表示時でもサムネイルコントロールヘッダー高さ(32px)がリサイザー(4px)で膨らまないよう、
    // #resizer-center に margin-bottom: -4px が設定されていること
    expect(css).toMatch(/#resizer-center\s*\{[^}]*margin-bottom:\s*-4px;/);
  });

  it('verifies empty state elements (.empty-state-msg, .empty-state-text, .empty-state-icon) prevent text selection', () => {
    const css = getFullCssContent();

    expect(css).toMatch(/\.empty-state-msg\s*\{[^}]*user-select:\s*none;/);
    expect(css).toMatch(/\.empty-state-msg\s*\{[^}]*pointer-events:\s*none;/);

    expect(css).toMatch(/\.empty-state-icon\s*\{[^}]*user-select:\s*none;/);
    expect(css).toMatch(/\.empty-state-icon\s*\{[^}]*pointer-events:\s*none;/);

    expect(css).toMatch(/\.empty-state-text\s*\{[^}]*user-select:\s*none;/);
    expect(css).toMatch(/\.empty-state-text\s*\{[^}]*pointer-events:\s*none;/);
  });

  it('verifies smart-folder-count inherits font and color styling to match smart folder name', () => {
    const css = getFullCssContent();

    expect(css).toMatch(/\.smart-folder-count\s*\{[^}]*font-size:\s*inherit;/);
    expect(css).toMatch(/\.smart-folder-count\s*\{[^}]*font-family:\s*inherit;/);
    expect(css).toMatch(/\.smart-folder-count\s*\{[^}]*font-weight:\s*inherit;/);
    expect(css).toMatch(/\.smart-folder-count\s*\{[^}]*color:\s*inherit;/);
    expect(css).toMatch(/\.smart-folder-count\s*\{[^}]*line-height:\s*inherit;/);
  });
});


