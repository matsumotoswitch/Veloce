import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import '../src/renderer/renderer-state.js';

describe('Thumbnail Cache Rebuild Bug Fixes', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-07-03T12:00:00Z'));
    window.appState = {
      thumbnailUrls: new Map(),
      selection: new Set()
    };
    window.veloceAPI = {
      convertFileSrc: vi.fn(path => `asset://${path}`),
      getThumbnail: vi.fn(async (path) => `data:image/jpeg;base64,/9j/mock`)
    };
    // Mock the DOM for updateDOM
    document.body.innerHTML = `
      <div class="virtual-content">
        <div data-filepath="test.jpg">
          <img class="thumbnail-img" />
        </div>
      </div>
    `;
    window.URL.revokeObjectURL = vi.fn();
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('should not call URL.revokeObjectURL for https urls', () => {
    appState.thumbnailUrls.set('test.jpg', 'https://veloce.localhost/thumbnail/?path=test.jpg');
    const oldUrl = appState.thumbnailUrls.get('test.jpg');
    if (oldUrl && oldUrl.startsWith('blob:')) window.URL.revokeObjectURL(oldUrl);
    appState.thumbnailUrls.delete('test.jpg');
    
    expect(window.URL.revokeObjectURL).not.toHaveBeenCalled();
    expect(appState.thumbnailUrls.has('test.jpg')).toBe(false);
  });

  it('should call URL.revokeObjectURL for blob urls', () => {
    appState.thumbnailUrls.set('test.jpg', 'blob:http://localhost/1234');
    const oldUrl = appState.thumbnailUrls.get('test.jpg');
    if (oldUrl && oldUrl.startsWith('blob:')) window.URL.revokeObjectURL(oldUrl);
    appState.thumbnailUrls.delete('test.jpg');
    
    expect(window.URL.revokeObjectURL).toHaveBeenCalledWith('blob:http://localhost/1234');
    expect(appState.thumbnailUrls.has('test.jpg')).toBe(false);
  });

  it('should fallback to convertFileSrc on img.onerror', () => {
    const img = document.createElement('img');
    img.className = 'thumbnail-img';
    img.src = 'https://veloce.localhost/thumbnail/?path=test.jpg';
    
    // Simulate the onerror handler from renderer-ui.js
    img.onerror = function() {
      this.classList.remove('loading');
      const fallback = window.veloceAPI.convertFileSrc('test.jpg');
      if (this.src !== fallback && !this.src.startsWith('asset://')) {
        if (window.appState && window.appState.thumbnailUrls) {
          window.appState.thumbnailUrls.set('test.jpg', fallback);
        }
        this.src = fallback;
      }
    };

    img.onerror();

    expect(img.src).toContain('asset://test.jpg');
    expect(appState.thumbnailUrls.get('test.jpg')).toBe('asset://test.jpg');
  });

  it('should dispatch error event if img.complete is true but naturalWidth is 0', () => {
    appState.thumbnailUrls.set('test.jpg', 'broken-image-url');
    const img = document.createElement('img');
    img.className = 'thumbnail-img';
    img.dataset.currentSrc = '';
    let errorDispatched = false;
    
    img.addEventListener('error', () => {
      errorDispatched = true;
    });

    // Mock naturalWidth and complete
    Object.defineProperty(img, 'complete', { value: true, configurable: true });
    Object.defineProperty(img, 'naturalWidth', { value: 0, configurable: true });
    
    // Simulate the logic from updateVirtualGrid
    img.src = appState.thumbnailUrls.get('test.jpg');
    if (img.complete) {
        img.classList.remove('loading');
        if (img.naturalWidth === 0 && img.src !== 'data:image/svg+xml;base64,...') {
            img.dispatchEvent(new Event('error'));
        }
    }

    expect(errorDispatched).toBe(true);
  });


  it('should fallback to Web Worker if Rust cache is empty (mock test)', async () => {
    // 擬似的に Web Worker の動作をテスト
    const workerPool = {
      generate: vi.fn(async () => 'blob:worker-generated')
    };
    
    window.veloceAPI.getThumbnail.mockResolvedValueOnce(null); // キャッシュミス
    window.veloceAPI.saveThumbnail = vi.fn().mockResolvedValue(true);
    
    const filePath = 'test.webp';
    let url = await window.veloceAPI.getThumbnail(filePath);
    
    if (!url) {
      const assetUrl = window.veloceAPI.convertFileSrc(filePath);
      url = await workerPool.generate(filePath, assetUrl);
      window.veloceAPI.saveThumbnail(filePath, url);
    }
    
    expect(workerPool.generate).toHaveBeenCalledWith('test.webp', 'asset://test.webp');
    expect(window.veloceAPI.saveThumbnail).toHaveBeenCalledWith('test.webp', 'blob:worker-generated');
    expect(url).toBe('blob:worker-generated');
  });

  it('should trigger debouncedUpdateSmartFolderCounts when queue is cleared', () => {
    window.debouncedUpdateSmartFolderCounts = vi.fn();
    
    // Mock the clear method logic of ThumbnailQueueManager
    const manager = {
      priorityQueue: [1, 2, 3],
      preloadQueue: [4, 5],
      activeTasks: new Set(['a']),
      clear() {
        this.priorityQueue = [];
        this.preloadQueue = [];
        this.activeTasks.clear();
        if (typeof window.debouncedUpdateSmartFolderCounts === 'function') {
          window.debouncedUpdateSmartFolderCounts();
        }
      }
    };
    
    manager.clear();
    
    expect(manager.priorityQueue.length).toBe(0);
    expect(manager.preloadQueue.length).toBe(0);
    expect(manager.activeTasks.size).toBe(0);
    expect(window.debouncedUpdateSmartFolderCounts).toHaveBeenCalled();
  });

  it('should trigger debouncedUpdateSmartFolderCounts when thumbnail generation completes', () => {
    window.debouncedUpdateSmartFolderCounts = vi.fn();
    
    // Mock the completion logic of processNext in ThumbnailQueueManager
    const manager = {
      priorityQueue: [],
      preloadQueue: [],
      activeTasks: new Set(),
      appState: { preloadCursor: 100, totalCount: 100 },
      processNext() {
        // ... tasks run ...
        if (this.priorityQueue.length === 0 && 
            this.preloadQueue.length === 0 && 
            this.activeTasks.size === 0 && 
            this.appState.preloadCursor >= this.appState.totalCount) {
          if (typeof window.debouncedUpdateSmartFolderCounts === 'function') {
            window.debouncedUpdateSmartFolderCounts();
          }
        }
      }
    };
    
    manager.processNext();
    expect(window.debouncedUpdateSmartFolderCounts).toHaveBeenCalled();
    
    // If not complete, it should not trigger
    window.debouncedUpdateSmartFolderCounts.mockClear();
    manager.activeTasks.add('task1');
    manager.processNext();
    expect(window.debouncedUpdateSmartFolderCounts).not.toHaveBeenCalled();
  });

  it('remove() should reset retry count so new files are not blocked by stale retries', () => {
    // 不具合再現: file-changed イベントが連続発生した場合にリトライカウントが積み上がり
    // SVGフォールバックになってしまう問題を検証
    const manager = {
      priorityQueue: [],
      priorityQueueSet: new Set(),
      preloadQueue: [],
      activeTasks: new Set(),
      _retryMap: new Map(),
      _dirtyTasks: null,
      remove(filePath) {
        this.priorityQueue = this.priorityQueue.filter(req => req.filePath !== filePath);
        this.priorityQueueSet.delete(filePath);
        this.preloadQueue = this.preloadQueue.filter(p => p !== filePath);
        if (this._retryMap) {
          this._retryMap.delete(filePath);
        }
        if (this.activeTasks.has(filePath)) {
          if (!this._dirtyTasks) this._dirtyTasks = new Set();
          this._dirtyTasks.add(filePath);
        }
      }
    };

    const filePath = 'C:\\Users\\test\\new-image.png';

    // リトライカウントが溜まった状態をシミュレート
    manager._retryMap.set(filePath, 2);

    // file-changed イベント → remove() 呼び出し
    manager.remove(filePath);

    // リトライカウントがリセットされること
    expect(manager._retryMap.has(filePath)).toBe(false);
  });

  it('remove() should set _dirtyTasks flag when task is actively running', () => {
    const manager = {
      priorityQueue: [],
      priorityQueueSet: new Set(),
      preloadQueue: [],
      activeTasks: new Set(),
      _retryMap: null,
      _dirtyTasks: null,
      remove(filePath) {
        this.priorityQueue = this.priorityQueue.filter(req => req.filePath !== filePath);
        this.priorityQueueSet.delete(filePath);
        this.preloadQueue = this.preloadQueue.filter(p => p !== filePath);
        if (this._retryMap) {
          this._retryMap.delete(filePath);
        }
        if (this.activeTasks.has(filePath)) {
          if (!this._dirtyTasks) this._dirtyTasks = new Set();
          this._dirtyTasks.add(filePath);
        }
      }
    };

    const filePath = 'C:\\Users\\test\\new-image.png';

    // タスクが実行中の状態
    manager.activeTasks.add(filePath);

    // file-changed イベント → remove() 呼び出し
    manager.remove(filePath);

    // _dirtyTasks フラグが立っていること（後でrunTaskが再キューする）
    expect(manager._dirtyTasks).not.toBeNull();
    expect(manager._dirtyTasks.has(filePath)).toBe(true);
  });

  it('remove() should NOT set _dirtyTasks when task is not running', () => {
    const manager = {
      priorityQueue: [{ filePath: 'C:\\test.png' }],
      priorityQueueSet: new Set(['C:\\test.png']),
      preloadQueue: [],
      activeTasks: new Set(), // タスクは実行中ではない
      _retryMap: null,
      _dirtyTasks: null,
      remove(filePath) {
        this.priorityQueue = this.priorityQueue.filter(req => req.filePath !== filePath);
        this.priorityQueueSet.delete(filePath);
        this.preloadQueue = this.preloadQueue.filter(p => p !== filePath);
        if (this._retryMap) {
          this._retryMap.delete(filePath);
        }
        if (this.activeTasks.has(filePath)) {
          if (!this._dirtyTasks) this._dirtyTasks = new Set();
          this._dirtyTasks.add(filePath);
        }
      }
    };

    const filePath = 'C:\\test.png';
    manager.remove(filePath);

    // キューからは削除されること
    expect(manager.priorityQueue.length).toBe(0);
    // _dirtyTasks は設定されないこと（タスク未実行のため）
    expect(manager._dirtyTasks).toBeNull();
  });

  describe('Immediate Viewport Thumbnail & Directory Load Optimization', () => {
    it('should reset savedScrollTopGrid to 0 when navigating to a different folder or smart folder', () => {
      // フォルダ遷移時、以前のスクロール位置を引き継がず0にリセットされ、
      // initialChunk が破棄されずに即時表示されることを検証
      const mockTabs = [
        { path: 'C:/folderA', scrollTop: 500 },
        { path: 'smart://fav_5', scrollTop: 0 }
      ];
      const activeTabIndex = 1;
      const currentDir = 'smart://fav_5';

      const isReloadingCurrent = mockTabs[activeTabIndex].path === currentDir && mockTabs[activeTabIndex].scrollTop !== 0;
      const savedScrollTopGrid = isReloadingCurrent ? 500 : (mockTabs[activeTabIndex].scrollTop || 0);

      expect(savedScrollTopGrid).toBe(0);
    });

    it('should synchronously invoke renderAll upon onDirectoryLoaded without debounce delay', () => {
      let renderAllCalled = false;
      const uiManagerMock = {
        renderAll: () => { renderAllCalled = true; },
        updateSelectionUI: () => {}
      };

      const payload = {
        path: 'smart://fav_5',
        totalCount: 50,
        initialChunk: [{ path: 'C:/img1.png', mtime: 0, hasThumbnailCache: true }]
      };

      // onDirectoryLoaded 受信時、100ms debounce を待たずに同期的に renderAll が実行されること
      const appStateMock = {
        currentDirectory: 'smart://fav_5',
        totalCount: 0,
        preloadCursor: -1,
        thumbnailTotalRequested: 0,
        thumbnailCompleted: 0,
        thumbnailCounted: new Set(),
        selectedIndex: -1
      };

      if (payload.path === appStateMock.currentDirectory) {
        appStateMock.totalCount = payload.totalCount;
        if (payload.initialChunk) {
          appStateMock.initialChunk = payload.initialChunk;
        }
        appStateMock.preloadCursor = 0;
        uiManagerMock.renderAll();
      }

      expect(renderAllCalled).toBe(true);
      expect(appStateMock.initialChunk).toHaveLength(1);
      expect(appStateMock.preloadCursor).toBe(0);
    });

    it('should set wrapper.dataset.filename and omit native title for unified custom tooltip on thumbnails', () => {
      const file = { name: 'very_long_filename_12345.png', path: 'C:/photos/very_long_filename_12345.png' };
      const wrapper = document.createElement('div');
      const label = document.createElement('div');
      wrapper.appendChild(label);

      // ロジック検証: ネイティブtitleを廃止し、カスタムツールチップ用に dataset.filename を設定
      if (file.name) {
        label.textContent = file.name;
        wrapper.dataset.filename = file.name;
        label.removeAttribute('title');
        wrapper.removeAttribute('title');
      } else {
        label.textContent = '';
        delete wrapper.dataset.filename;
        label.removeAttribute('title');
        wrapper.removeAttribute('title');
      }

      expect(wrapper.dataset.filename).toBe('very_long_filename_12345.png');
      expect(wrapper.getAttribute('title')).toBeNull();
      expect(label.getAttribute('title')).toBeNull();
    });

    it('should trigger tooltip only when target is within thumbnail-label', () => {
      const wrapper = document.createElement('div');
      wrapper.className = 'thumbnail-item';
      const img = document.createElement('img');
      img.className = 'thumbnail-img';
      const label = document.createElement('div');
      label.className = 'thumbnail-label';
      label.textContent = 'sample_image.png';

      wrapper.appendChild(img);
      wrapper.appendChild(label);

      // 画像本体をホバーした場合 -> label は null（ツールチップ非表示）
      const targetImg = img;
      expect(targetImg.closest('.thumbnail-label')).toBeNull();

      // ファイル名ラベルをホバーした場合 -> label が取得できツールチップ表示対象
      const targetLabel = label;
      expect(targetLabel.closest('.thumbnail-label')).toBe(label);
      expect(targetLabel.closest('.thumbnail-label').textContent).toBe('sample_image.png');
    });
  });

  describe('Uncached New Files Priority Queueing in Grid', () => {
    let originalThumbnailManager;

    beforeEach(() => {
      originalThumbnailManager = window.thumbnailManager;
    });

    afterEach(() => {
      window.thumbnailManager = originalThumbnailManager;
    });

    it('updateVirtualGrid should enqueue uncached files (hasThumbnailCache: false) to thumbnailManager priority batch and set loading placeholder', async () => {
      const enqueuedBatches = [];
      window.thumbnailManager = {
        enqueuePriorityBatch: vi.fn((paths) => {
          enqueuedBatches.push(...paths);
        }),
        enqueuePriority: vi.fn()
      };

      const testFiles = [
        { path: 'C:/media/cached1.png', name: 'cached1.png', mtime: 1000, hasThumbnailCache: true },
        { path: 'C:/media/new1.png', name: 'new1.png', mtime: 2000, hasThumbnailCache: false },
        { path: 'C:/media/new2.webp', name: 'new2.webp', mtime: 3000, hasThumbnailCache: false },
        { path: 'C:/media/cached2.png', name: 'cached2.png', mtime: 4000, hasThumbnailCache: true }
      ];

      const { appState: sharedAppState } = await import('../src/renderer/renderer-state.js');
      sharedAppState.totalCount = testFiles.length;
      sharedAppState.initialChunk = testFiles;
      sharedAppState.thumbnailUrls.clear();
      sharedAppState.selection.clear();
      sharedAppState.ratings = {};
      sharedAppState.dragState = { isAppDragging: false };
      window.appState = sharedAppState;

      const gridContainer = document.createElement('div');
      gridContainer.id = 'grid-view';
      gridContainer.getBoundingClientRect = () => ({ width: 800, height: 600 });
      Object.defineProperty(gridContainer, 'clientWidth', { value: 800, configurable: true });
      Object.defineProperty(gridContainer, 'clientHeight', { value: 600, configurable: true });
      Object.defineProperty(gridContainer, 'scrollTop', { value: 0, writable: true, configurable: true });

      const gridSpacer = document.createElement('div');
      gridSpacer.className = 'virtual-spacer';

      const gridContent = document.createElement('div');
      gridContent.className = 'virtual-content';

      gridContainer.appendChild(gridSpacer);
      gridContainer.appendChild(gridContent);

      const { UIManager } = await import('../src/renderer/renderer-ui.js');
      const ui = new UIManager(sharedAppState);
      ui.elements.thumbnailGrid = gridContainer;
      ui.elements.thumbnailSizeSlider = { value: '180' };

      await ui.updateVirtualGrid(true);

      // 1. 未生成の2ファイルのみが enqueuePriorityBatch に投入されていること
      expect(enqueuedBatches).toEqual([
        { filePath: 'C:/media/new1.png', skipDbCheck: true },
        { filePath: 'C:/media/new2.webp', skipDbCheck: true }
      ]);

      // 2. DOM要素の検証
      // children[0] (cached1.png): キャッシュ済みなのでカスタムプロトコルURLが設定される
      const cached1Img = gridContent.children[0].querySelector('.thumbnail-img');
      expect(cached1Img.src).toContain('https://veloce.localhost/thumbnail/?path=');
      expect(sharedAppState.thumbnailUrls.get('C:/media/cached1.png')).toContain('https://veloce.localhost/thumbnail/?path=');

      // children[1] (new1.png): 未生成なのでプレースホルダーとloadingクラスが設定され、Workerによる生成を待つ
      const new1Img = gridContent.children[1].querySelector('.thumbnail-img');
      expect(new1Img.src).toContain('data:image/gif;base64');
      expect(new1Img.classList.contains('loading')).toBe(true);

      // children[2] (new2.webp): 未生成なのでプレースホルダーとloadingクラス
      const new2Img = gridContent.children[2].querySelector('.thumbnail-img');
      expect(new2Img.src).toContain('data:image/gif;base64');
      expect(new2Img.classList.contains('loading')).toBe(true);

      // children[3] (cached2.png): キャッシュ済み
      const cached2Img = gridContent.children[3].querySelector('.thumbnail-img');
      expect(cached2Img.src).toContain('https://veloce.localhost/thumbnail/?path=');
    });

    it('updateVirtualGrid should append token parameter to veloce.localhost fallback URL when videoServerToken is set', async () => {
      const prevPort = window.videoServerPort;
      const prevToken = window.videoServerToken;
      window.videoServerPort = 0;
      window.videoServerToken = 'test_session_token_128bit';

      try {
        window.thumbnailManager = {
          enqueuePriorityBatch: vi.fn(),
          enqueuePriority: vi.fn()
        };

        const testFiles = [
          { path: 'C:/media/cached_token.png', name: 'cached_token.png', mtime: 1500, hashKey: '0123456789abcdef', hasThumbnailCache: true }
        ];

        const { appState: sharedAppState } = await import('../src/renderer/renderer-state.js');
        sharedAppState.totalCount = testFiles.length;
        sharedAppState.initialChunk = testFiles;
        sharedAppState.thumbnailUrls.clear();
        sharedAppState.selection.clear();
        sharedAppState.ratings = {};
        sharedAppState.dragState = { isAppDragging: false };
        window.appState = sharedAppState;

        const gridContainer = document.createElement('div');
        gridContainer.id = 'thumbnail-grid';
        Object.defineProperty(gridContainer, 'clientWidth', { value: 800, configurable: true });
        Object.defineProperty(gridContainer, 'clientHeight', { value: 600, configurable: true });
        const gridContent = document.createElement('div');
        gridContent.id = 'virtual-grid-content';
        gridContainer.appendChild(gridContent);
        document.body.appendChild(gridContainer);

        const { UIManager } = await import('../src/renderer/renderer-ui.js');
        const ui = new UIManager(sharedAppState);
        ui.elements.thumbnailGrid = gridContainer;
        ui.elements.thumbnailSizeSlider = { value: '180' };

        await ui.updateVirtualGrid(true);

        const cachedUrl = sharedAppState.thumbnailUrls.get('C:/media/cached_token.png');
        expect(cachedUrl).toContain('https://veloce.localhost/thumbnail/?path=');
        expect(cachedUrl).toContain('&hash=0123456789abcdef');
        expect(cachedUrl).toContain('&token=test_session_token_128bit');
      } finally {
        window.videoServerPort = prevPort;
        window.videoServerToken = prevToken;
      }
    });

    it('updateVirtualGrid should not enqueue files when all visible items have cached thumbnails', async () => {
      const enqueueMock = vi.fn();
      window.thumbnailManager = {
        enqueuePriorityBatch: enqueueMock,
        enqueuePriority: vi.fn()
      };

      const testFiles = [
        { path: 'C:/media/cached1.png', name: 'cached1.png', mtime: 1000, hasThumbnailCache: true },
        { path: 'C:/media/cached2.png', name: 'cached2.png', mtime: 2000, hasThumbnailCache: true }
      ];

      const { appState: sharedAppState } = await import('../src/renderer/renderer-state.js');
      sharedAppState.totalCount = testFiles.length;
      sharedAppState.initialChunk = testFiles;
      sharedAppState.thumbnailUrls.clear();
      sharedAppState.selection.clear();
      sharedAppState.ratings = {};
      sharedAppState.dragState = { isAppDragging: false };
      window.appState = sharedAppState;

      const gridContainer = document.createElement('div');
      gridContainer.id = 'grid-view';
      gridContainer.getBoundingClientRect = () => ({ width: 800, height: 600 });
      Object.defineProperty(gridContainer, 'clientWidth', { value: 800, configurable: true });
      Object.defineProperty(gridContainer, 'clientHeight', { value: 600, configurable: true });
      Object.defineProperty(gridContainer, 'scrollTop', { value: 0, writable: true, configurable: true });

      const gridSpacer = document.createElement('div');
      gridSpacer.className = 'virtual-spacer';

      const gridContent = document.createElement('div');
      gridContent.className = 'virtual-content';

      gridContainer.appendChild(gridSpacer);
      gridContainer.appendChild(gridContent);

      const { UIManager } = await import('../src/renderer/renderer-ui.js');
      const ui = new UIManager(sharedAppState);
      ui.elements.thumbnailGrid = gridContainer;
      ui.elements.thumbnailSizeSlider = { value: '180' };

      await ui.updateVirtualGrid(true);

      expect(enqueueMock).not.toHaveBeenCalled();
    });
  });

  describe('Native Downsampled Thumbnail Generation Pipeline', () => {
    beforeEach(() => {
      vi.useRealTimers();
    });

    afterEach(() => {
      vi.useFakeTimers();
    });

    it('getImageDimensionsFromBlob should accurately parse PNG dimensions', async () => {
      const { getImageDimensionsFromBlob } = await import('../src/renderer/renderer-thumbnails.js');
      // PNG: 1920 x 1080
      const pngHeader = new Uint8Array([
        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, // signature
        0x00, 0x00, 0x00, 0x0D, // IHDR length 13
        0x49, 0x48, 0x44, 0x52, // "IHDR"
        0x00, 0x00, 0x07, 0x80, // width: 1920
        0x00, 0x00, 0x04, 0x38, // height: 1080
        0x08, 0x06, 0x00, 0x00, 0x00 // bit_depth, color_type, etc.
      ]);
      const blob = new Blob([pngHeader], { type: 'image/png' });
      const dims = await getImageDimensionsFromBlob(blob);
      expect(dims).toEqual({ width: 1920, height: 1080 });
    });

    it('getImageDimensionsFromBlob should accurately parse WebP (VP8X) dimensions', async () => {
      const { getImageDimensionsFromBlob } = await import('../src/renderer/renderer-thumbnails.js');
      // WebP VP8X: width=1024, height=768 (stored as width-1 = 1023 (0x0003FF), height-1 = 767 (0x0002FF))
      const webpHeader = new Uint8Array([
        0x52, 0x49, 0x46, 0x46, // "RIFF"
        0x20, 0x00, 0x00, 0x00, // size dummy
        0x57, 0x45, 0x42, 0x50, // "WEBP"
        0x56, 0x50, 0x38, 0x58, // "VP8X"
        0x0A, 0x00, 0x00, 0x00, // chunk size 10
        0x00, 0x00, 0x00, 0x00, // flags
        0xFF, 0x03, 0x00,       // width - 1 = 1023 (24bit LE: 0xFF, 0x03, 0x00)
        0xFF, 0x02, 0x00        // height - 1 = 767 (24bit LE: 0xFF, 0x02, 0x00)
      ]);
      const blob = new Blob([webpHeader], { type: 'image/webp' });
      const dims = await getImageDimensionsFromBlob(blob);
      expect(dims).toEqual({ width: 1024, height: 768 });
    });

    it('getImageDimensionsFromBlob should accurately parse JPEG SOF0 dimensions', async () => {
      const { getImageDimensionsFromBlob } = await import('../src/renderer/renderer-thumbnails.js');
      // JPEG SOF0: height=600 (0x0258), width=800 (0x0320)
      const jpegHeader = new Uint8Array([
        0xFF, 0xD8,             // SOI
        0xFF, 0xC0,             // SOF0
        0x00, 0x11,             // segment length 17
        0x08,                   // precision
        0x02, 0x58,             // height: 600
        0x03, 0x20,             // width: 800
        0x03, 0x01, 0x11, 0x00  // components
      ]);
      const blob = new Blob([jpegHeader], { type: 'image/jpeg' });
      const dims = await getImageDimensionsFromBlob(blob);
      expect(dims).toEqual({ width: 800, height: 600 });
    });

    it('getImageDimensionsFromBlob should accurately parse JPEG with large EXIF APP1 segment (>512 bytes)', async () => {
      const { getImageDimensionsFromBlob } = await import('../src/renderer/renderer-thumbnails.js');
      // SOI + APP1 (Exif: 1024 bytes) + SOF0 (1920x1080)
      const exifLength = 1024;
      const totalLen = 2 + (2 + exifLength) + (2 + 17);
      const data = new Uint8Array(totalLen);
      let offset = 0;
      // SOI
      data[offset++] = 0xFF; data[offset++] = 0xD8;
      // APP1 marker
      data[offset++] = 0xFF; data[offset++] = 0xE1;
      // APP1 length (exifLength + 2)
      data[offset++] = ((exifLength + 2) >> 8) & 0xFF;
      data[offset++] = (exifLength + 2) & 0xFF;
      // Dummy Exif payload
      offset += exifLength;
      // SOF0 marker
      data[offset++] = 0xFF; data[offset++] = 0xC0;
      data[offset++] = 0x00; data[offset++] = 0x11; // segment length
      data[offset++] = 0x08; // precision
      data[offset++] = 0x04; data[offset++] = 0x38; // height: 1080 (0x0438)
      data[offset++] = 0x07; data[offset++] = 0x80; // width: 1920 (0x0780)
      data[offset++] = 0x03; data[offset++] = 0x01; data[offset++] = 0x11; data[offset++] = 0x00;

      const blob = new Blob([data], { type: 'image/jpeg' });
      const dims = await getImageDimensionsFromBlob(blob);
      expect(dims).toEqual({ width: 1920, height: 1080 });
    });

    it('getImageDimensionsFromBlob should safely return null for invalid or corrupted data', async () => {
      const { getImageDimensionsFromBlob } = await import('../src/renderer/renderer-thumbnails.js');
      const corrupted = new Uint8Array([0x00, 0x01, 0x02, 0x03]);
      const blob = new Blob([corrupted]);
      const dims = await getImageDimensionsFromBlob(blob);
      expect(dims).toBeNull();
    });

    it('runTask should bypass getThumbnail IPC when skipDbCheck is true', async () => {
      const { ThumbnailQueueManager } = await import('../src/renderer/renderer-thumbnails.js');
      const manager = new ThumbnailQueueManager(4);
      
      const getThumbnailSpy = vi.fn().mockResolvedValue(null);
      window.veloceAPI.getThumbnail = getThumbnailSpy;
      window.veloceAPI.saveThumbnail = vi.fn().mockResolvedValue('asset://saved');
      
      // Mock worker generate
      const { thumbnailWorkerPool } = await import('../src/renderer/renderer-thumbnails.js');
      const generateSpy = vi.spyOn(thumbnailWorkerPool, 'generate').mockResolvedValue({
        url: 'blob:test',
        base64Promise: Promise.resolve('data:image/jpeg;base64,...')
      });

      // skipDbCheck: true で実行
      await manager.runTask('C:/media/test_skip.png', true);

      // getThumbnail IPC は一切呼ばれないこと
      expect(getThumbnailSpy).not.toHaveBeenCalled();
      // worker.generate は即座に呼ばれること
      expect(generateSpy).toHaveBeenCalled();

      // skipDbCheck: false（デフォルト）で実行
      getThumbnailSpy.mockClear();
      generateSpy.mockClear();
      await manager.runTask('C:/media/test_normal.png', false);

      // getThumbnail IPC が呼ばれること
      expect(getThumbnailSpy).toHaveBeenCalledWith('C:/media/test_normal.png');
      expect(generateSpy).toHaveBeenCalled();

      generateSpy.mockRestore();
    });

    it('should use pre-encoded BROKEN_MP4_FALLBACK_URL without redundant btoa execution', async () => {
      const { BROKEN_MP4_FALLBACK_URL } = await import('../src/renderer/renderer-ui.js');
      expect(BROKEN_MP4_FALLBACK_URL).toBeDefined();
      expect(BROKEN_MP4_FALLBACK_URL).toMatch(/^data:image\/svg\+xml;base64,/);
    });
  });

  describe('Self-Healing Watchdog Process', () => {
    it('should early return and avoid DOM scans when in table/list mode or when idle and healthy', async () => {
      const { checkThumbnailSelfHealing } = await import('../src/renderer/renderer-thumbnails.js');

      // 1. activeCenterPane が 'table' (リストビュー) の場合 -> 早期リターン 0
      window.appState = { activeCenterPane: 'table', dragState: { isAppDragging: false } };
      window.uiManager = { _domByPath: new Map([['path1', { children: [{ classList: { contains: () => true } }] }]]) };
      expect(checkThumbnailSelfHealing()).toBe(0);

      // 2. _domByPath が空の場合 -> 早期リターン 0
      window.appState.activeCenterPane = 'grid';
      window.uiManager._domByPath = new Map();
      expect(checkThumbnailSelfHealing()).toBe(0);

      // 3. 全サムネイルがロード済み（healthy）かつキュー・タスクが空の場合 -> DOM走査を行わず早期リターン 0
      const domMap = new Map();
      const childGetter = vi.fn();
      domMap.set('C:/images/pic1.png', {
        get children() {
          childGetter();
          return [{ classList: { contains: () => false }, src: 'https://veloce.localhost/thumbnail/pic1' }];
        }
      });
      window.uiManager._domByPath = domMap;
      window.appState.thumbnailUrls = new Map([
        ['C:/images/pic1.png', 'https://veloce.localhost/thumbnail/pic1']
      ]);
      window.thumbnailManager = {
        priorityQueue: [],
        preloadQueue: [],
        activeTasks: new Set(),
        enqueuePriority: vi.fn(),
        processNext: vi.fn()
      };

      const retries = checkThumbnailSelfHealing();
      expect(retries).toBe(0);
      // 完全アイドル時は DOM の children[0] に一度もアクセスせずに早期リターンすること
      expect(childGetter).not.toHaveBeenCalled();
      expect(window.thumbnailManager.enqueuePriority).not.toHaveBeenCalled();

      // 4. スタック中のサムネイルが存在する場合 -> 自動検知して再キューすること
      domMap.set('C:/images/stuck.png', {
        children: [{
          classList: { contains: (cls) => cls === 'loading' },
          src: 'data:image/gif;base64,...'
        }]
      });
      const retriesStuck = checkThumbnailSelfHealing();
      expect(retriesStuck).toBe(1);
      expect(window.thumbnailManager.enqueuePriority).toHaveBeenCalledWith('C:/images/stuck.png');
    });

    it('scheduleThumbnailSelfHealing should debounce and trigger self-healing on-demand', async () => {
      vi.useFakeTimers();
      const { scheduleThumbnailSelfHealing, cancelThumbnailSelfHealing, checkThumbnailSelfHealing } = await import('../src/renderer/renderer-thumbnails.js');

      window.appState = { activeCenterPane: 'grid', dragState: { isAppDragging: false } };
      window.uiManager = { _domByPath: new Map() };

      scheduleThumbnailSelfHealing(1000);
      scheduleThumbnailSelfHealing(500); // 連続スケジュール時のデバウンス

      expect(vi.getTimerCount()).toBe(1);

      // 500ms 経過後に自己修復が発火すること
      vi.advanceTimersByTime(500);
      expect(vi.getTimerCount()).toBe(0);

      // キャンセルの検証
      scheduleThumbnailSelfHealing(1000);
      expect(vi.getTimerCount()).toBe(1);
      cancelThumbnailSelfHealing();
      expect(vi.getTimerCount()).toBe(0);

      vi.useRealTimers();
    });
  });

  describe('Thumbnail Cache Rebuild Workflow & Persistence', () => {
    beforeEach(() => {
      vi.useRealTimers();
    });

    afterEach(() => {
      vi.useFakeTimers();
    });

    it('runTask should persist thumbnail via saveThumbnail even if aborted by folder navigation', async () => {
      const { ThumbnailQueueManager, thumbnailWorkerPool } = await import('../src/renderer/renderer-thumbnails.js');
      const manager = new ThumbnailQueueManager(4);

      window.veloceAPI.getThumbnail = vi.fn().mockResolvedValue(null);
      const saveThumbnailMock = vi.fn().mockResolvedValue('http://127.0.0.1:1234/?path=test.png&thumb=1');
      window.veloceAPI.saveThumbnail = saveThumbnailMock;

      let resolveBase64;
      const base64Promise = new Promise((resolve) => { resolveBase64 = resolve; });

      vi.spyOn(thumbnailWorkerPool, 'generate').mockImplementation(async () => {
        return {
          url: 'blob:mock-blob',
          base64Promise,
          width: 200,
          height: 200
        };
      });

      const taskPromise = manager.runTask('test.png', true);

      // タスク起動後にフォルダ移動が発生して abort された状態をシミュレート
      manager.abortController.abort();

      // Base64 変換が完了
      resolveBase64('data:image/jpeg;base64,abc123xyz');

      await taskPromise;
      await new Promise(r => setTimeout(r, 10));

      // フォルダ移動後でも saveThumbnail は確実に呼ばれ、SQLite DB にキャッシュが永続化されること
      expect(saveThumbnailMock).toHaveBeenCalledWith('test.png', 'data:image/jpeg;base64,abc123xyz');
    });

    it('folder cache rebuild should clear old cache, enqueue all paths, and set progress tracking', async () => {
      const pathsToRebuild = ['C:/photos/img1.png', 'C:/photos/img2.webp', 'C:/photos/img3.jpg'];
      const unshiftPreloadMock = vi.fn();
      window.thumbnailManager = {
        unshiftPreload: unshiftPreloadMock
      };

      const clearCacheMock = vi.fn().mockResolvedValue([]);
      window.veloceAPI.clearMetadataCache = clearCacheMock;
      window.veloceAPI.getItems = vi.fn().mockResolvedValue([
        { path: pathsToRebuild[0] },
        { path: pathsToRebuild[1] },
        { path: pathsToRebuild[2] }
      ]);

      const testAppState = {
        currentDirectory: 'C:/photos',
        totalCount: 3,
        thumbnailUrls: new Map([
          ['C:/photos/img1.png', 'blob:old1'],
          ['C:/photos/img2.webp', 'blob:old2']
        ]),
        thumbnailTotalRequested: 0,
        thumbnailCompleted: 0,
        thumbnailCounted: new Set(['C:/photos/img1.png']),
        rebuiltPaths: null
      };
      window.appState = testAppState;

      // menuRebuildFolderCache の処理フローをシミュレート
      const collectedPaths = [];
      const total = testAppState.totalCount;
      const batchSize = 1000;
      for (let i = 0; i < total; i += batchSize) {
        const size = Math.min(batchSize, total - i);
        const files = await window.veloceAPI.getItems(i, size);
        for (const file of files) {
          collectedPaths.push(file.path);
          if (testAppState.thumbnailUrls.has(file.path)) {
            const oldUrl = testAppState.thumbnailUrls.get(file.path);
            if (oldUrl && oldUrl.startsWith('blob:')) window.URL.revokeObjectURL(oldUrl);
            testAppState.thumbnailUrls.delete(file.path);
          }
        }
      }

      await window.veloceAPI.clearMetadataCache(collectedPaths);
      testAppState.thumbnailTotalRequested = collectedPaths.length;
      testAppState.thumbnailCompleted = 0;
      if (!testAppState.rebuiltPaths) testAppState.rebuiltPaths = new Set();
      collectedPaths.forEach(p => {
        testAppState.thumbnailCounted.delete(p);
        testAppState.rebuiltPaths.add(p);
      });
      window.thumbnailManager.unshiftPreload(collectedPaths);

      // 検証
      expect(clearCacheMock).toHaveBeenCalledWith(pathsToRebuild);
      expect(testAppState.thumbnailUrls.size).toBe(0);
      expect(testAppState.thumbnailTotalRequested).toBe(3);
      expect(testAppState.thumbnailCompleted).toBe(0);
      expect(testAppState.thumbnailCounted.size).toBe(0);
      expect(testAppState.rebuiltPaths.size).toBe(3);
      expect(unshiftPreloadMock).toHaveBeenCalledWith(pathsToRebuild);
    });
  });

  describe('Thumbnail Flickering and Stale Image Elimination', () => {
    it('should immediately set loading class on wrapper and img when slot is recycled for a new file', async () => {
      if (!window.thumbnailManager) {
        window.thumbnailManager = { enqueuePriorityBatch: vi.fn(), enqueuePriority: vi.fn(), processNext: vi.fn() };
      } else if (!window.thumbnailManager.processNext) {
        window.thumbnailManager.processNext = vi.fn();
      }
      const { appState: sharedAppState } = await import('../src/renderer/renderer-state.js');
      const { UIManager } = await import('../src/renderer/renderer-ui.js');

      const fileA = { path: 'C:/media/a.png', name: 'a.png', mtime: 1000, hasThumbnailCache: true };
      const fileB = { path: 'C:/media/b.png', name: 'b.png', mtime: 2000, hasThumbnailCache: true };

      sharedAppState.totalCount = 1;
      sharedAppState.initialChunk = [fileA];
      sharedAppState.thumbnailUrls.clear();
      sharedAppState.selection.clear();
      sharedAppState.ratings = {};
      sharedAppState.dragState = { isAppDragging: false };
      window.appState = sharedAppState;

      const gridContainer = document.createElement('div');
      gridContainer.id = 'grid-view';
      Object.defineProperty(gridContainer, 'clientWidth', { value: 800, configurable: true });
      Object.defineProperty(gridContainer, 'clientHeight', { value: 600, configurable: true });
      Object.defineProperty(gridContainer, 'scrollTop', { value: 0, writable: true, configurable: true });

      const gridSpacer = document.createElement('div');
      gridSpacer.className = 'virtual-spacer';
      const gridContent = document.createElement('div');
      gridContent.className = 'virtual-content';
      gridContainer.appendChild(gridSpacer);
      gridContainer.appendChild(gridContent);

      const ui = new UIManager(sharedAppState);
      ui.elements.thumbnailGrid = gridContainer;
      ui.elements.thumbnailSizeSlider = { value: '180' };

      // 初期描画（fileA）
      await ui.updateVirtualGrid(true);
      const wrapper = gridContent.children[0];
      const img = wrapper.querySelector('.thumbnail-img');

      expect(wrapper.dataset.filepath).toBe('C:/media/a.png');
      expect(wrapper.classList.contains('loading')).toBe(true);
      expect(img.classList.contains('loading')).toBe(true);

      // fileA のロードが完了
      img.onload();
      expect(wrapper.classList.contains('loading')).toBe(false);
      expect(img.classList.contains('loading')).toBe(false);

      // 次に別のファイル fileB で同一スロットを再利用
      sharedAppState.initialChunk = [fileB];
      await ui.updateVirtualGrid(true);

      // スロット再利用直後：前の画像が露出しないよう、即座に loading クラスが付与されること
      expect(wrapper.dataset.filepath).toBe('C:/media/b.png');
      expect(wrapper.classList.contains('loading')).toBe(true);
      expect(img.classList.contains('loading')).toBe(true);

      // fileB のロードが完了
      img.onload();
      expect(wrapper.classList.contains('loading')).toBe(false);
      expect(img.classList.contains('loading')).toBe(false);
    });

    it('should drop stale async render if scroll position advances during getItems', async () => {
      if (!window.thumbnailManager) {
        window.thumbnailManager = { enqueuePriorityBatch: vi.fn(), enqueuePriority: vi.fn(), processNext: vi.fn() };
      } else if (!window.thumbnailManager.processNext) {
        window.thumbnailManager.processNext = vi.fn();
      }
      const { appState: sharedAppState } = await import('../src/renderer/renderer-state.js');
      const { UIManager } = await import('../src/renderer/renderer-ui.js');

      sharedAppState.totalCount = 100;
      sharedAppState.initialChunk = null; // force veloceAPI.getItems
      sharedAppState.thumbnailUrls.clear();
      sharedAppState.selection.clear();
      sharedAppState.ratings = {};
      sharedAppState.dragState = { isAppDragging: false };
      window.appState = sharedAppState;

      const gridContainer = document.createElement('div');
      gridContainer.id = 'grid-view';
      Object.defineProperty(gridContainer, 'clientWidth', { value: 800, configurable: true });
      Object.defineProperty(gridContainer, 'clientHeight', { value: 600, configurable: true });
      gridContainer.scrollTop = 0;

      const gridSpacer = document.createElement('div');
      gridSpacer.className = 'virtual-spacer';
      const gridContent = document.createElement('div');
      gridContent.className = 'virtual-content';
      gridContainer.appendChild(gridSpacer);
      gridContainer.appendChild(gridContent);

      const ui = new UIManager(sharedAppState);
      ui.elements.thumbnailGrid = gridContainer;
      ui.elements.thumbnailSizeSlider = { value: '180' };

      // getItems 実行中に scrollTop が急激に進んだ状況をシミュレート
      window.veloceAPI.getItems = vi.fn(async (start, count) => {
        gridContainer.scrollTop = 2000; // スクロールが大きく進む
        return Array.from({ length: count }, (_, i) => ({
          path: `C:/media/img_${start + i}.png`,
          name: `img_${start + i}.png`,
          mtime: 1000,
          hasThumbnailCache: true
        }));
      });

      await ui.updateVirtualGrid(false);

      // 古い位置（scrollTop: 0 付近）の描画が破棄され、コンテンツが空のまま維持されること
      expect(gridContent.children.length).toBe(0);
    });
  });

  describe('Phase 3: Binary Thumbnail Stream & Direct Save Pipeline', () => {
    let originalFetch;
    let originalVideoServerPort;

    beforeEach(() => {
      originalFetch = global.fetch;
      originalVideoServerPort = window.videoServerPort;
    });

    afterEach(() => {
      global.fetch = originalFetch;
      window.videoServerPort = originalVideoServerPort;
      delete window.videoServerToken;
    });

    it('saveThumbnailBinary should POST raw Blob directly to local video server when videoServerPort is available', async () => {
      const { saveThumbnailBinary } = await import('../src/renderer/renderer-thumbnails.js');
      window.videoServerPort = 54321;

      const mockFetch = vi.fn().mockResolvedValue({
        ok: true,
        text: async () => 'http://127.0.0.1:54321/?path=C%3A%2Fimages%2Fpic.png&thumb=1'
      });
      global.fetch = mockFetch;

      const dummyBlob = new Blob(['mock-binary-jpeg-data'], { type: 'image/jpeg' });
      const savedUrl = await saveThumbnailBinary('C:/images/pic.png', dummyBlob, null);

      expect(mockFetch).toHaveBeenCalledTimes(1);
      const [url, options] = mockFetch.mock.calls[0];
      expect(url).toContain('http://127.0.0.1:54321/save-thumbnail?path=');
      expect(url).toContain(encodeURIComponent('C:/images/pic.png'));
      expect(options.method).toBe('POST');
      expect(options.body).toBe(dummyBlob);
      expect(savedUrl).toBe('http://127.0.0.1:54321/?path=C%3A%2Fimages%2Fpic.png&thumb=1');
    });

    it('saveThumbnailBinary should include token in query parameters when videoServerToken is set', async () => {
      const { saveThumbnailBinary } = await import('../src/renderer/renderer-thumbnails.js');
      window.videoServerPort = 54321;
      window.videoServerToken = 'test_token_abc';

      const mockFetch = vi.fn().mockResolvedValue({
        ok: true,
        text: async () => 'http://127.0.0.1:54321/?path=C%3A%2Fimages%2Fpic.png&thumb=1&token=test_token_abc'
      });
      global.fetch = mockFetch;

      const dummyBlob = new Blob(['mock-binary-jpeg-data'], { type: 'image/jpeg' });
      const savedUrl = await saveThumbnailBinary('C:/images/pic.png', dummyBlob, null);

      expect(mockFetch).toHaveBeenCalledTimes(1);
      const [url] = mockFetch.mock.calls[0];
      expect(url).toContain('token=test_token_abc');
      delete window.videoServerToken;
    });

    it('saveThumbnailBinary should not instantiate FileReader when HTTP POST succeeds even if base64Promise is null', async () => {
      const { saveThumbnailBinary } = await import('../src/renderer/renderer-thumbnails.js');
      window.videoServerPort = 54321;
      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        text: async () => 'http://127.0.0.1:54321/?path=C%3A%2Fimages%2Fno_b64.png&thumb=1'
      });

      let fileReaderConstructed = false;
      const originalFileReader = global.FileReader;
      global.FileReader = class MockFileReader {
        constructor() {
          fileReaderConstructed = true;
        }
        readAsDataURL() {}
      };

      try {
        const dummyBlob = new Blob(['raw-bytes'], { type: 'image/jpeg' });
        const savedUrl = await saveThumbnailBinary('C:/images/no_b64.png', dummyBlob, null);
        expect(savedUrl).toBe('http://127.0.0.1:54321/?path=C%3A%2Fimages%2Fno_b64.png&thumb=1');
        expect(fileReaderConstructed).toBe(false);
      } finally {
        global.FileReader = originalFileReader;
      }
    });

    it('runTask should revoke temporary blobUrl once savedUrl replaces it in appState.thumbnailUrls or on abort', async () => {
      const { appState } = await import('../src/renderer/renderer-state.js');
      const { ThumbnailQueueManager, thumbnailWorkerPool } = await import('../src/renderer/renderer-thumbnails.js');
      const manager = new ThumbnailQueueManager(2);
      const filePath = 'C:/test/video_leak_check.mp4';
      const tempBlobUrl = 'blob:http://localhost/temp-video-thumb-1';
      const savedHttpUrl = 'http://127.0.0.1:54321/?path=C%3A%2Ftest%2Fvideo_leak_check.mp4&thumb=1';

      window.videoServerPort = 54321;
      window.veloceAPI.getThumbnail = vi.fn().mockResolvedValue(null);
      window.veloceAPI.convertFileSrc = vi.fn((p) => `asset://${p}`);
      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        text: async () => savedHttpUrl
      });

      const revokeSpy = vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => {});
      vi.spyOn(thumbnailWorkerPool, 'generate').mockResolvedValueOnce({
        url: tempBlobUrl,
        blob: new Blob(['thumb'], { type: 'image/jpeg' }),
        base64Promise: null,
        width: 320,
        height: 180
      });

      const wrapper = document.createElement('div');
      wrapper.dataset.filepath = filePath;
      const img = document.createElement('img');
      Object.defineProperty(img, 'complete', { value: true, configurable: true });
      wrapper.appendChild(img);
      window.uiManager = { _domByPath: new Map([[filePath, wrapper]]), updateFileDimensions: vi.fn() };

      await manager.runTask(filePath, true);
      for (let i = 0; i < 10; i++) {
        await Promise.resolve();
      }

      expect(appState.thumbnailUrls.get(filePath)).toBe(savedHttpUrl);
      expect(revokeSpy).toHaveBeenCalledWith(tempBlobUrl);
      revokeSpy.mockRestore();
    });

    it('saveThumbnailBinary should fallback to base64Promise and window.veloceAPI.saveThumbnail when videoServerPort is absent', async () => {
      const { saveThumbnailBinary } = await import('../src/renderer/renderer-thumbnails.js');
      delete window.videoServerPort;

      const mockSaveThumbnail = vi.fn().mockResolvedValue('http://fallback-saved-url');
      window.veloceAPI = {
        saveThumbnail: mockSaveThumbnail
      };

      const base64Promise = Promise.resolve('data:image/jpeg;base64,QUJDREVGR0g=');
      const savedUrl = await saveThumbnailBinary('C:/images/fallback.png', null, base64Promise);

      expect(mockSaveThumbnail).toHaveBeenCalledWith('C:/images/fallback.png', 'data:image/jpeg;base64,QUJDREVGR0g=');
      expect(savedUrl).toBe('http://fallback-saved-url');
    });

    it('ThumbnailWorkerPool.generate base64Promise should be lazy and not construct FileReader if unread', async () => {
      let readerCalled = false;
      const originalFileReader = global.FileReader;
      global.FileReader = class MockFileReader {
        constructor() {
          readerCalled = true;
        }
        readAsDataURL() {}
      };

      try {
        let cached = null;
        const lazyPromise = {
          then(fn) {
            if (!cached) {
              cached = new Promise(r => {
                new global.FileReader();
                r('data:mock');
              });
            }
            return cached.then(fn);
          }
        };

        // .then を呼ばない限り FileReader は生成されない
        expect(readerCalled).toBe(false);

        // .then を呼ぶと初めて FileReader が生成される
        await lazyPromise.then(() => {});
        expect(readerCalled).toBe(true);
      } finally {
        global.FileReader = originalFileReader;
      }
    });

    it('updateVirtualGrid should use local HTTP URL with thumb=1 when window.videoServerPort is available', async () => {
      window.videoServerPort = 12345;
      const { appState: sharedAppState } = await import('../src/renderer/renderer-state.js');
      const testFiles = [{ path: 'C:/images/cached.png', name: 'cached.png', mtime: 55555, hasThumbnailCache: true }];
      sharedAppState.totalCount = testFiles.length;
      sharedAppState.initialChunk = testFiles;
      sharedAppState.thumbnailUrls.clear();
      sharedAppState.selection.clear();
      sharedAppState.ratings = {};
      sharedAppState.dragState = { isAppDragging: false };
      window.appState = sharedAppState;

      const gridContainer = document.createElement('div');
      gridContainer.id = 'grid-view';
      gridContainer.getBoundingClientRect = () => ({ width: 800, height: 600 });
      Object.defineProperty(gridContainer, 'clientWidth', { value: 800, configurable: true });
      Object.defineProperty(gridContainer, 'clientHeight', { value: 600, configurable: true });
      Object.defineProperty(gridContainer, 'scrollTop', { value: 0, writable: true, configurable: true });

      const gridSpacer = document.createElement('div');
      gridSpacer.className = 'virtual-spacer';
      const gridContent = document.createElement('div');
      gridContent.className = 'virtual-content';
      gridContainer.appendChild(gridSpacer);
      gridContainer.appendChild(gridContent);

      const { UIManager } = await import('../src/renderer/renderer-ui.js');
      const ui = new UIManager(sharedAppState);
      ui.elements.thumbnailGrid = gridContainer;
      ui.elements.thumbnailSizeSlider = { value: '180' };

      try {
        await ui.updateVirtualGrid(true);

        const cachedImg = gridContent.children[0].querySelector('.thumbnail-img');
        expect(cachedImg.src).toContain('http://127.0.0.1:12345/?path=C%3A%2Fimages%2Fcached.png&mtime=55555&thumb=1');
        expect(sharedAppState.thumbnailUrls.get('C:/images/cached.png')).toContain('http://127.0.0.1:12345/?path=');
      } finally {
        delete window.videoServerPort;
      }
    });

    it('updateDOM should normalize path slashes and immediately remove loading class if img.complete is true', async () => {
      const { ThumbnailQueueManager } = await import('../src/renderer/renderer-thumbnails.js');
      const manager = new ThumbnailQueueManager(2);
      const wrapper = document.createElement('div');
      wrapper.dataset.filepath = 'C:\\images\\photo.png';
      wrapper.classList.add('loading');
      const img = document.createElement('img');
      img.classList.add('loading');
      wrapper.appendChild(img);

      // DOM map にバックスラッシュで登録
      window.uiManager = {
        _domByPath: new Map([['C:\\images\\photo.png', wrapper]])
      };

      // スラッシュ区切りで updateDOM を呼び出し、img.complete = true の状況
      Object.defineProperty(img, 'complete', { value: true, writable: true });
      Object.defineProperty(img, 'naturalWidth', { value: 200, writable: true });

      manager.updateDOM('C:/images/photo.png', 'blob:http://localhost/mock-blob');

      expect(img.src).toBe('blob:http://localhost/mock-blob');
      expect(img.classList.contains('loading')).toBe(false);
      expect(wrapper.classList.contains('loading')).toBe(false);
    });

    it('saveThumbnailBinary should fallback to base64 and save via IPC if videoServerPort is unset', async () => {
      delete window.videoServerPort;
      const { saveThumbnailBinary } = await import('../src/renderer/renderer-thumbnails.js');
      const mockSave = vi.fn().mockResolvedValue('http://127.0.0.1:9999/?saved=1');
      window.veloceAPI.saveThumbnail = mockSave;

      const base64Promise = Promise.resolve('data:image/jpeg;base64,QUJDREVGR0g=');
      const result = await saveThumbnailBinary('C:/test/file.jpg', null, base64Promise);

      expect(mockSave).toHaveBeenCalledWith('C:/test/file.jpg', 'data:image/jpeg;base64,QUJDREVGR0g=');
      expect(result).toBe('http://127.0.0.1:9999/?saved=1');
    });

    it('runTask should immediately recover via Rust getThumbnail when worker generate throws', async () => {
      const { appState } = await import('../src/renderer/renderer-state.js');
      const { ThumbnailQueueManager, thumbnailWorkerPool } = await import('../src/renderer/renderer-thumbnails.js');
      const manager = new ThumbnailQueueManager(2);
      const filePath = 'C:/test/rebuild_target.png';

      // 再構築対象としてセット
      appState.rebuiltPaths = new Set([filePath]);

      // Worker generate を強制失敗させる
      vi.spyOn(thumbnailWorkerPool, 'generate').mockRejectedValueOnce(new Error('Fetch failed: 403 CSP block'));

      // Rust 側救済モック
      const rustRecoveredUrl = 'http://127.0.0.1:12345/?path=C%3A%2Ftest%2Frebuild_target.png&thumb=1';
      window.veloceAPI.getThumbnail = vi.fn().mockResolvedValue(rustRecoveredUrl);

      // DOM 要素準備
      const wrapper = document.createElement('div');
      wrapper.dataset.filepath = filePath;
      const img = document.createElement('img');
      img.classList.add('loading');
      wrapper.appendChild(img);
      window.uiManager = { _domByPath: new Map([[filePath, wrapper]]) };

      await manager.runTask(filePath);

      // Rust バックエンド救済が呼ばれ、SVGアイコンにならず正規のURLが設定されること
      expect(window.veloceAPI.getThumbnail).toHaveBeenCalledWith(filePath);
      expect(appState.thumbnailUrls.get(filePath)).toBe(rustRecoveredUrl);
      expect(img.src).toBe(rustRecoveredUrl);
    });

    it('thumbnailWorkerPool.generate should fallback to readBinaryFile when fetch fails', async () => {
      vi.useRealTimers();
      const { thumbnailWorkerPool } = await import('../src/renderer/renderer-thumbnails.js');
      const filePath = 'C:/test/binary_fallback.png';

      // fetch を拒否モック
      const originalFetch = global.fetch;
      global.fetch = vi.fn().mockRejectedValue(new TypeError('Failed to fetch'));

      // readBinaryFile をモック (PNGヘッダー風バイナリ)
      const mockBytes = new Uint8Array([
        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
        0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, // 256x256
        0x08, 0x06, 0x00, 0x00, 0x00
      ]);
      window.veloceAPI.readBinaryFile = vi.fn().mockResolvedValue(mockBytes);

      try {
        const controller = new AbortController();
        const promise = thumbnailWorkerPool.generate(filePath, 'https://asset.localhost/test.png', controller.signal);
        // readBinaryFile が呼ばれたことを確認
        await new Promise((r) => setTimeout(r, 50));
        expect(window.veloceAPI.readBinaryFile).toHaveBeenCalledWith(filePath);
        controller.abort();
        await promise.catch(() => {});
      } finally {
        global.fetch = originalFetch;
        vi.useFakeTimers();
      }
    });
  });

  describe('Phase 4: Rust Native Parallel Batch Generation (ThumbnailQueueManager)', () => {
    let manager;
    let testAppState;

    beforeEach(async () => {
      vi.useRealTimers();
      const { appState } = await import('../src/renderer/renderer-state.js');
      testAppState = appState;
      testAppState.thumbnailUrls.clear();
      testAppState.viewportPathSet = new Set();
      testAppState.visiblePathSet = new Set();

      const { ThumbnailQueueManager } = await import('../src/renderer/renderer-thumbnails.js');
      manager = new ThumbnailQueueManager(4);

      window.veloceAPI = {
        convertFileSrc: vi.fn(path => `asset://${path}`),
        getThumbnail: vi.fn(async (path) => `http://127.0.0.1:12345/?path=${encodeURIComponent(path)}&thumb=1`),
        generateThumbnailBatch: vi.fn(async (paths) => {
          return paths.map(p => ({
            path: p,
            url: `http://127.0.0.1:12345/?path=${encodeURIComponent(p)}&thumb=1`
          }));
        })
      };
      document.body.innerHTML = `
        <div id="thumbnail-progress-bar" style="width: 0%; opacity: 0;"></div>
        <div class="virtual-content">
          <div data-filepath="C:/test/batch1.jpg"><img class="thumbnail-img loading" /></div>
          <div data-filepath="C:/test/batch2.png"><img class="thumbnail-img loading" /></div>
          <div data-filepath="C:/test/batch3.webp"><img class="thumbnail-img loading" /></div>
          <div data-filepath="C:/test/video.mp4"><img class="thumbnail-img loading" /></div>
        </div>
      `;
    });

    afterEach(() => {
      if (manager) manager.clear();
      vi.restoreAllMocks();
      vi.useFakeTimers();
    });

    it('should batch static image requests and delegate to generateThumbnailBatch', async () => {
      const paths = ['C:/test/batch1.jpg', 'C:/test/batch2.png', 'C:/test/batch3.webp'];
      manager.enqueuePriorityBatch(paths, true);

      // processNext がバッチを起動し完了するのを待つ
      await new Promise(r => setTimeout(r, 50));

      expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenCalledWith(paths);
      for (const p of paths) {
        expect(testAppState.thumbnailUrls.has(p)).toBe(true);
        expect(testAppState.thumbnailUrls.get(p)).toContain('thumb=1');
      }
      expect(manager.completedCount).toBe(paths.length);
    });

    it('should exclude video files from batch and process them via individual tasks', async () => {
      const items = ['C:/test/batch1.jpg', 'C:/test/video.mp4'];
      const runTaskSpy = vi.spyOn(manager, 'runTask');

      manager.enqueuePriorityBatch(items, true);
      await new Promise(r => setTimeout(r, 50));

      // バッチには静止画像のみが含まれる
      expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenCalledWith(['C:/test/batch1.jpg']);
      // 動画ファイルは個別の runTask に回される
      expect(runTaskSpy).toHaveBeenCalledWith('C:/test/video.mp4', true);
    });

    it('should fallback failed items from batch to individual runTask', async () => {
      window.veloceAPI.generateThumbnailBatch = vi.fn().mockResolvedValue([
        { path: 'C:/test/batch1.jpg', url: 'http://127.0.0.1:12345/batch1.jpg' },
        { path: 'C:/test/batch2.png', url: '' } // 失敗
      ]);
      const runTaskSpy = vi.spyOn(manager, 'runTask');

      manager.enqueuePriorityBatch(['C:/test/batch1.jpg', 'C:/test/batch2.png'], true);
      await new Promise(r => setTimeout(r, 50));

      expect(testAppState.thumbnailUrls.get('C:/test/batch1.jpg')).toBe('http://127.0.0.1:12345/batch1.jpg');
      // 失敗した batch2.png のみ runTask にフォールバック
      expect(runTaskSpy).toHaveBeenCalledWith('C:/test/batch2.png', false);
    });

    it('should fallback all items if generateThumbnailBatch rejects', async () => {
      window.veloceAPI.generateThumbnailBatch = vi.fn().mockRejectedValue(new Error('IPC batch error'));
      const runTaskSpy = vi.spyOn(manager, 'runTask');

      manager.enqueuePriorityBatch(['C:/test/batch1.jpg', 'C:/test/batch2.png'], true);
      await new Promise(r => setTimeout(r, 50));

      expect(runTaskSpy).toHaveBeenCalledWith('C:/test/batch1.jpg', false);
      expect(runTaskSpy).toHaveBeenCalledWith('C:/test/batch2.png', false);
    });

    it('processNext should delegate un-cached items (skipDbCheck=true) to generateThumbnailBatch instead of Canvas Worker', async () => {
      const paths = ['C:/test/batch1.jpg', 'C:/test/batch2.png'];
      // skipDbCheck: true で渡されても、Worker ではなく Rust 側の generateThumbnailBatch へ一括委譲されること
      manager.enqueuePriorityBatch(paths, true);
      await new Promise(r => setTimeout(r, 50));

      expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenCalledWith(paths);
      expect(testAppState.thumbnailUrls.get('C:/test/batch1.jpg')).toContain('thumb=1');
      expect(testAppState.thumbnailUrls.get('C:/test/batch2.png')).toContain('thumb=1');
    });

    it('should sort viewport items to the front when enqueuing priority batch', () => {
      testAppState.viewportPathSet = new Set(['C:/test/view1.jpg', 'C:/test/view2.jpg']);
      testAppState.visiblePathSet = new Set(['C:/test/buf1.jpg', 'C:/test/buf2.jpg', 'C:/test/view1.jpg', 'C:/test/view2.jpg']);

      // processNext をスパイしてキューの整列状態を検証
      vi.spyOn(manager, 'processNext').mockImplementation(() => {});

      // 画面外バッファが先、画面内が後の順序で渡された場合でもキュー内では画面内が先頭に整列すること
      const inputItems = [
        'C:/test/buf1.jpg',
        'C:/test/view1.jpg',
        'C:/test/buf2.jpg',
        'C:/test/view2.jpg'
      ];
      manager.enqueuePriorityBatch(inputItems, true);

      expect(manager.priorityQueue[0].filePath).toBe('C:/test/view1.jpg');
      expect(manager.priorityQueue[1].filePath).toBe('C:/test/view2.jpg');
      expect(manager.priorityQueue[2].filePath).toBe('C:/test/buf1.jpg');
      expect(manager.priorityQueue[3].filePath).toBe('C:/test/buf2.jpg');
    });

    it('should not mix preloadQueue items into batch when viewport items exist in queue', async () => {
      testAppState.viewportPathSet = new Set(['C:/test/view1.jpg', 'C:/test/view2.jpg']);
      testAppState.visiblePathSet = new Set(['C:/test/view1.jpg', 'C:/test/view2.jpg']);

      // プリロードキューに画面外アイテムが存在する状態
      manager.preloadQueue = [
        { filePath: 'C:/test/preload1.jpg', skipDbCheck: false },
        { filePath: 'C:/test/preload2.jpg', skipDbCheck: false }
      ];

      // 画面内アイテムを優先キューに追加
      manager.enqueuePriorityBatch(['C:/test/view1.jpg', 'C:/test/view2.jpg'], true);
      await new Promise(r => setTimeout(r, 50));

      // 画面内アイテムが存在するため、初回のバッチには画面内アイテムのみが含まれ、preloadQueue のアイテムは巻き込まれないこと
      expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenNthCalledWith(1, ['C:/test/view1.jpg', 'C:/test/view2.jpg']);
    });

    it('should reserve worker slots for viewport items and not dispatch buffer items while viewport items are pending', () => {
      testAppState.viewportPathSet = new Set(['C:/test/viewport.mp4']);
      testAppState.visiblePathSet = new Set(['C:/test/viewport.mp4', 'C:/test/buffer.mp4']);

      // 動画ファイル（Worker/個別タスクで処理）を投入
      manager.priorityQueue = [
        { filePath: 'C:/test/viewport.mp4', skipDbCheck: true },
        { filePath: 'C:/test/buffer.mp4', skipDbCheck: true }
      ];
      manager.priorityQueueSet = new Set(['C:/test/viewport.mp4', 'C:/test/buffer.mp4']);

      // 動画スロット上限を1にして1枠のみ実行できるようにする
      manager.maxVideoConcurrency = 1;
      const runTaskSpy = vi.spyOn(manager, 'runTask').mockImplementation(() => {});

      manager.processNext();

      // 画面内（viewport.mp4）のみが実行され、未着手画面内がある間は画面外バッファ（buffer.mp4）は実行されないこと
      expect(runTaskSpy).toHaveBeenCalledWith('C:/test/viewport.mp4', true);
      expect(runTaskSpy).not.toHaveBeenCalledWith('C:/test/buffer.mp4', true);
      expect(manager.priorityQueue.length).toBe(1);
      expect(manager.priorityQueue[0].filePath).toBe('C:/test/buffer.mp4');
    });

    describe('Viewport chunked batching and generation cancellation', () => {
      let resolvers;

      const makeResults = (paths) => paths.map(p => ({
        path: p,
        url: `http://127.0.0.1:12345/?path=${encodeURIComponent(p)}&thumb=1`,
        cancelled: false
      }));

      beforeEach(() => {
        resolvers = [];
        // 応答を手動で解決できる保留型モック（バッチ処理中の状態を検証するため）
        window.veloceAPI.generateThumbnailBatch = vi.fn((paths) => new Promise(resolve => {
          resolvers.push({ paths, resolve });
        }));
      });

      const flush = () => new Promise(r => setTimeout(r, 0));

      it('should split viewport items into small chunks in screen order and dispatch them concurrently', () => {
        const viewport = [];
        for (let i = 0; i < 10; i++) viewport.push(`C:/test/v${i}.jpg`);
        testAppState.viewportPathSet = new Set(viewport);
        testAppState.visiblePathSet = new Set(viewport);
        vi.spyOn(manager, 'runTask').mockImplementation(() => {});

        manager.enqueuePriorityBatch(viewport, true);

        // 10件の画面内アイテムが 4/4/2 件のチャンクに分割され、画面上の並び順のまま並行投入されること
        const api = window.veloceAPI.generateThumbnailBatch;
        expect(api).toHaveBeenCalledTimes(3);
        expect(api).toHaveBeenNthCalledWith(1, ['C:/test/v0.jpg', 'C:/test/v1.jpg', 'C:/test/v2.jpg', 'C:/test/v3.jpg']);
        expect(api).toHaveBeenNthCalledWith(2, ['C:/test/v4.jpg', 'C:/test/v5.jpg', 'C:/test/v6.jpg', 'C:/test/v7.jpg']);
        expect(api).toHaveBeenNthCalledWith(3, ['C:/test/v8.jpg', 'C:/test/v9.jpg']);
        expect(manager.activeBatchCount).toBe(3);
        expect(manager.activeViewportBatchCount).toBe(3);
      });

      it('should display the first chunk as soon as it completes without waiting for other chunks', async () => {
        const viewport = [];
        for (let i = 0; i < 8; i++) viewport.push(`C:/test/v${i}.jpg`);
        testAppState.viewportPathSet = new Set(viewport);
        testAppState.visiblePathSet = new Set(viewport);
        vi.spyOn(manager, 'runTask').mockImplementation(() => {});

        manager.enqueuePriorityBatch(viewport, true);
        expect(resolvers.length).toBe(2);

        // 先頭チャンクのみ完了
        resolvers[0].resolve(makeResults(resolvers[0].paths));
        await flush();

        expect(testAppState.thumbnailUrls.has('C:/test/v0.jpg')).toBe(true);
        expect(testAppState.thumbnailUrls.has('C:/test/v3.jpg')).toBe(true);
        // 2番目のチャンクは未完了のため未反映であること
        expect(testAppState.thumbnailUrls.has('C:/test/v4.jpg')).toBe(false);
      });

      it('should not dispatch off-screen batch while viewport batches are pending, then dispatch it afterwards', async () => {
        testAppState.viewportPathSet = new Set(['C:/test/view1.jpg', 'C:/test/view2.jpg']);
        testAppState.visiblePathSet = new Set(['C:/test/view1.jpg', 'C:/test/view2.jpg', 'C:/test/buf1.jpg', 'C:/test/buf2.jpg']);
        vi.spyOn(manager, 'runTask').mockImplementation(() => {});

        manager.enqueuePriorityBatch(['C:/test/view1.jpg', 'C:/test/view2.jpg', 'C:/test/buf1.jpg', 'C:/test/buf2.jpg'], true);

        // 画面内バッチの処理中は画面外バッチを投入しないこと
        expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenCalledTimes(1);
        expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenNthCalledWith(1, ['C:/test/view1.jpg', 'C:/test/view2.jpg']);
        expect(manager.activeBackgroundBatchCount).toBe(0);

        resolvers[0].resolve(makeResults(resolvers[0].paths));
        await flush();

        // 画面内バッチ完了後に画面外バッチが投入されること
        expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenCalledTimes(2);
        expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenNthCalledWith(2, ['C:/test/buf1.jpg', 'C:/test/buf2.jpg']);
        expect(manager.activeBackgroundBatchCount).toBe(1);
      });

      it('should re-queue items cancelled by Rust generation epoch instead of falling back to Worker', async () => {
        testAppState.viewportPathSet = new Set(['C:/test/a.jpg', 'C:/test/b.jpg']);
        testAppState.visiblePathSet = new Set(['C:/test/a.jpg', 'C:/test/b.jpg']);
        const runTaskSpy = vi.spyOn(manager, 'runTask').mockImplementation(() => {});

        manager.enqueuePriorityBatch(['C:/test/a.jpg', 'C:/test/b.jpg'], true);
        expect(resolvers.length).toBe(1);

        resolvers[0].resolve([
          { path: 'C:/test/a.jpg', url: 'http://127.0.0.1:12345/a.jpg', cancelled: false },
          { path: 'C:/test/b.jpg', url: '', cancelled: true }
        ]);
        await flush();

        expect(testAppState.thumbnailUrls.get('C:/test/a.jpg')).toBe('http://127.0.0.1:12345/a.jpg');
        // 打ち切られた b.jpg は Worker（runTask）にフォールバックせず、再度バッチに投入されること
        expect(runTaskSpy).not.toHaveBeenCalledWith('C:/test/b.jpg', expect.anything());
        expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenCalledTimes(2);
        expect(window.veloceAPI.generateThumbnailBatch).toHaveBeenNthCalledWith(2, ['C:/test/b.jpg']);
      });

      it('should not decrement batch counters of the new context when a stale batch completes after clear()', async () => {
        testAppState.viewportPathSet = new Set(['C:/test/old.jpg']);
        testAppState.visiblePathSet = new Set(['C:/test/old.jpg']);
        vi.spyOn(manager, 'runTask').mockImplementation(() => {});

        manager.enqueuePriorityBatch(['C:/test/old.jpg'], true);
        expect(resolvers.length).toBe(1);

        // フォルダ切り替え相当
        manager.clear();
        testAppState.viewportPathSet = new Set(['C:/test/new.jpg']);
        testAppState.visiblePathSet = new Set(['C:/test/new.jpg']);
        manager.enqueuePriorityBatch(['C:/test/new.jpg'], true);
        expect(manager.activeBatchCount).toBe(1);
        expect(manager.activeViewportBatchCount).toBe(1);

        // 旧コンテキストのバッチが遅れて完了しても、新コンテキストのカウンタは減算されず、結果も反映されないこと
        resolvers[0].resolve(makeResults(['C:/test/old.jpg']));
        await flush();

        expect(manager.activeBatchCount).toBe(1);
        expect(manager.activeViewportBatchCount).toBe(1);
        expect(testAppState.thumbnailUrls.has('C:/test/old.jpg')).toBe(false);
      });

      it('should abort all running worker generation tasks and clear activeControllers on clear()', async () => {
        const { thumbnailWorkerPool } = await import('../src/renderer/renderer-thumbnails.js');
        const abortSpy = vi.spyOn(thumbnailWorkerPool, 'abortAll');

        manager.clear();

        expect(abortSpy).toHaveBeenCalled();
      });
    });

    describe('Phase 9-3: Blob URL Cache LRU & Byte-Based Eviction', () => {
      it('touchThumbnailUrl refreshes Map order so evictThumbnailCacheNow evicts LRU entries first while preserving visible items', async () => {
        const { touchThumbnailUrl, evictThumbnailCacheNow } = await import('../src/renderer/renderer-thumbnails.js');
        const { thumbnailState } = await import('../src/renderer/renderer-state.js');

        thumbnailState.urls.clear();
        thumbnailState.clearBlobBytes();
        thumbnailState.visiblePathSet = new Set(['C:/test/visible.png']);
        thumbnailState.viewportPathSet = new Set();

        thumbnailState.urls.set('C:/test/visible.png', 'blob:visible');
        thumbnailState.urls.set('C:/test/old1.png', 'blob:old1');
        thumbnailState.urls.set('C:/test/old2.png', 'blob:old2');
        thumbnailState.urls.set('C:/test/recent.png', 'blob:recent');

        // old1 を参照して MRU（末尾）へ移動させる -> 非表示の最古エントリは old2 になる
        expect(touchThumbnailUrl('C:/test/old1.png')).toBe('blob:old1');

        // 上限 3 件で Evict 実行: visible は保護され、LRU 先頭の old2 が破棄されること
        evictThumbnailCacheNow(3, 64 * 1024 * 1024);

        expect(thumbnailState.urls.size).toBe(3);
        expect(thumbnailState.urls.has('C:/test/visible.png')).toBe(true);
        expect(thumbnailState.urls.has('C:/test/old1.png')).toBe(true);
        expect(thumbnailState.urls.has('C:/test/recent.png')).toBe(true);
        expect(thumbnailState.urls.has('C:/test/old2.png')).toBe(false);
      });

      it('evictThumbnailCacheNow evicts blob URLs when totalBlobBytes exceeds maxBlobBytes while retaining lightweight HTTP URLs', async () => {
        const { evictThumbnailCacheNow } = await import('../src/renderer/renderer-thumbnails.js');
        const { thumbnailState } = await import('../src/renderer/renderer-state.js');

        thumbnailState.urls.clear();
        thumbnailState.clearBlobBytes();
        thumbnailState.visiblePathSet = new Set();
        thumbnailState.viewportPathSet = new Set();

        // 先頭に軽量な HTTP URL、その後に 2 件の大容量 Blob URL（各 600KB、合計 1.2MB）を登録
        thumbnailState.urls.set('C:/test/http_cached.png', 'http://127.0.0.1:9999/?thumb=1');
        thumbnailState.urls.set('C:/test/blob_a.png', 'blob:blob_a');
        thumbnailState.recordBlobBytes('C:/test/blob_a.png', 600 * 1024);
        thumbnailState.urls.set('C:/test/blob_b.png', 'blob:blob_b');
        thumbnailState.recordBlobBytes('C:/test/blob_b.png', 600 * 1024);

        expect(thumbnailState.totalBlobBytes).toBe(1200 * 1024);

        // 件数上限（2000件）は十分余裕があるが、Blob バイト上限（800KB）を超過している状態で Evict
        evictThumbnailCacheNow(2000, 800 * 1024);

        // 軽量な HTTP URL は破棄されず、古い方の blob_a のみが解放されて 600KB に収まること
        expect(thumbnailState.urls.has('C:/test/http_cached.png')).toBe(true);
        expect(thumbnailState.urls.has('C:/test/blob_a.png')).toBe(false);
        expect(thumbnailState.urls.has('C:/test/blob_b.png')).toBe(true);
        expect(thumbnailState.totalBlobBytes).toBe(600 * 1024);
      });
    });
  });
});


