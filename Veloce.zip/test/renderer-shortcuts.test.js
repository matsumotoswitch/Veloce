import { describe, it, expect, beforeEach, afterEach, beforeAll, vi } from 'vitest';
import { appState } from '../src/renderer/renderer-state.js';
import { uiManager } from '../src/renderer/renderer-ui.js';

describe('Renderer Global Shortcuts & Focus Management', () => {
  let globalKeydownHandler;
  let selectImage;
  let renderMultipleSelectionSummary;
  let openDiffModal;
  let isModalOrOverlayOpen;
  let getSelectionRemoveAllRangesSpy;

  beforeAll(async () => {
    document.body.innerHTML = `
      <input type="text" id="search-input" />
      <div id="center-top"></div>
      <div id="center-bottom">
        <div class="thumbnail-item" data-index="0"></div>
        <div class="thumbnail-item" data-index="1"></div>
      </div>
      <div id="file-list-body"></div>
      <div id="file-list-top-spacer"></div>
      <div id="file-list-bottom-spacer"></div>
      <div id="dir-tree"></div>
      <input type="range" id="thumbnail-size-slider" />
      <div id="inspector-header-path"></div>
      <div id="inspector-content"></div>
      <div id="inspector-empty"></div>
      <div id="static-file-info-table"></div>
      <div id="file-info-empty"></div>
    `;

    // Populate uiManager.elements so renderer.js won't crash on load
    uiManager.elements.thumbnailGrid = document.getElementById('center-bottom');
    uiManager.elements.searchBar = document.getElementById('search-input');
    uiManager.elements.fileListBody = document.getElementById('file-list-body');
    uiManager.elements.dirTree = document.getElementById('dir-tree');
    uiManager.elements.thumbnailSizeSlider = document.getElementById('thumbnail-size-slider');

    // Dynamic import to ensure DOM is ready
    const renderer = await import('../src/renderer/renderer.js');
    globalKeydownHandler = renderer.globalKeydownHandler;
    selectImage = renderer.selectImage;
    renderMultipleSelectionSummary = renderer.renderMultipleSelectionSummary;
    openDiffModal = renderer.openDiffModal;
    isModalOrOverlayOpen = renderer.isModalOrOverlayOpen;
  });

  beforeEach(() => {
    getSelectionRemoveAllRangesSpy = vi.fn();

    // reset appState
    appState.totalCount = 2;
    appState.selectedIndex = -1;
    appState.selection = new Set();
    appState.ratings = {};

    // Mock API (merge with setup.js mocks)
    window.veloceAPI = {
      getItems: vi.fn().mockResolvedValue([]),
      loadDirectory: vi.fn().mockResolvedValue({ files: [], current_dir: '' }),
      renameFile: vi.fn().mockResolvedValue({ success: true }),
      getFileByIndex: vi.fn().mockImplementation(async (idx) => {
        if (idx === 0) return { path: '/path/to/0.jpg', name: '0.jpg' };
        if (idx === 1) return { path: '/path/to/1.jpg', name: '1.jpg' };
        return null;
      }),
      getFilesByIndices: vi.fn().mockImplementation(async (indices) => {
        return indices.map(idx => {
          if (idx === 0) return { path: '/path/to/0.jpg', name: '0.jpg' };
          if (idx === 1) return { path: '/path/to/1.jpg', name: '1.jpg' };
          return null;
        }).filter(Boolean);
      }),
      copyImageToClipboard: vi.fn(),
      setRating: vi.fn().mockResolvedValue(1),
      setRatingsBatch: vi.fn().mockResolvedValue(1),
      arrangeViewers: vi.fn(),
      trashFile: vi.fn().mockResolvedValue(true),
      notifyFileRemoved: vi.fn(),
      notifyFileChanged: vi.fn()
    };

    uiManager.showToast = vi.fn();
    uiManager.updateSelectionUI = vi.fn();
    uiManager._domByPath = new Map([
      ['/path/to/0.jpg', document.querySelector('.thumbnail-item[data-index="0"]')],
      ['/path/to/1.jpg', document.querySelector('.thumbnail-item[data-index="1"]')]
    ]);

    // Mock notification and other globals
    window.showNotification = vi.fn();
    window.renameSelectedFile = vi.fn();
    window.renameSelectedFolder = vi.fn();
    window.deleteSelectedFiles = vi.fn();
    window.deleteSelectedFolder = vi.fn();
    window.onTabClick = vi.fn();
    window.veloceAPI.parseMetadata = vi.fn().mockResolvedValue({});
    uiManager.showDiffModal = vi.fn();
    uiManager.hideCustomTooltip = vi.fn();
    uiManager.updateVirtualList = vi.fn();
    uiManager.updateVirtualGrid = vi.fn();

    // Mock CSS for JSDOM
    global.CSS = { escape: vi.fn(s => s) };

    // Mock removeAllRanges since jsdom doesn't fully implement it
    window.getSelection = vi.fn(() => ({
      removeAllRanges: getSelectionRemoveAllRangesSpy,
      toString: vi.fn(() => '')
    }));

    window.__TAURI__ = {
      path: {
        basename: vi.fn().mockResolvedValue('oldname.jpg')
      }
    };

    // Reset element functions if needed, though JSDOM handles focus natively
  });

  afterEach(() => {
    vi.clearAllMocks();
    document.getElementById('search-input').blur();
  });

  describe('Focus Management', () => {
    it('should clear selection and blur input when selectImage is called', async () => {
      const input = document.getElementById('search-input');
      input.focus();

      await selectImage(0);

      expect(getSelectionRemoveAllRangesSpy).toHaveBeenCalled();
      // JSDOM blur changes activeElement back to body
      expect(document.activeElement).not.toBe(input);
      expect(appState.selectedIndex).toBe(0);
    });
  });

  describe('Ctrl+C - Copy Image', () => {
    it('should copy image to clipboard and apply flash effect', async () => {
      appState.selectedIndex = 1;
      appState.selection.add(1);

      const event = new window.KeyboardEvent('keydown', { key: 'c', ctrlKey: true, cancelable: true });
      await globalKeydownHandler(event);
      
      // Wait for promises in the handler
      await new Promise(resolve => setTimeout(resolve, 0));

      expect(window.veloceAPI.getFileByIndex).toHaveBeenCalledWith(1);
      expect(window.veloceAPI.copyImageToClipboard).toHaveBeenCalledWith('/path/to/1.jpg');
    });

    it('should skip image copy if text is selected in the window', async () => {
      window.getSelection = vi.fn(() => ({
        toString: () => 'selected text'
      }));

      const event = new window.KeyboardEvent('keydown', { key: 'c', ctrlKey: true, cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.copyImageToClipboard).not.toHaveBeenCalled();
    });

    it('should do nothing if focus is in an input field', async () => {
      const input = document.getElementById('search-input');
      input.focus();

      const event = new window.KeyboardEvent('keydown', { key: 'c', ctrlKey: true, cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.getFileByIndex).not.toHaveBeenCalled();
      expect(window.veloceAPI.copyImageToClipboard).not.toHaveBeenCalled();
    });
  });

  describe('Other Global Shortcuts', () => {
    it('should focus search bar on Ctrl+F', async () => {
      const event = new window.KeyboardEvent('keydown', { key: 'f', ctrlKey: true, cancelable: true });
      const preventDefaultSpy = vi.spyOn(event, 'preventDefault');
      const focusSpy = vi.spyOn(uiManager.elements.searchBar, 'focus');
      const selectSpy = vi.spyOn(uiManager.elements.searchBar, 'select');
      
      await globalKeydownHandler(event);
      
      expect(preventDefaultSpy).toHaveBeenCalled();
      expect(focusSpy).toHaveBeenCalled();
      expect(selectSpy).toHaveBeenCalled();
    });

    it('should open viewer on Enter with filePath', async () => {
      appState.selectedIndex = 0;
      appState.selection.add(0);
      const sel = document.createElement('div');
      sel.className = 'thumbnail-item selected';
      sel.dataset.filepath = '/test.jpg';
      document.body.appendChild(sel);

      window.veloceAPI.getFileByIndex = vi.fn().mockResolvedValue({ path: '/test.jpg', width: 100, height: 100 });
      window.veloceAPI.openViewer = vi.fn();
      
      const event = new window.KeyboardEvent('keydown', { key: 'Enter', cancelable: true });
      await globalKeydownHandler(event);
      
      // wait for promises (openViewer is async)
      await new Promise(resolve => setTimeout(resolve, 0));

      expect(window.veloceAPI.openViewer).toHaveBeenCalledWith(expect.objectContaining({ currentIndex: 0, filePath: '/test.jpg' }));
      sel.remove();
    });

    it('should call renameSelectedFile on F2', async () => {
      appState.selectedIndex = 0;
      appState.selection.add(0);
      uiManager.showPrompt = vi.fn().mockResolvedValue('newname.jpg');
      
      const event = new window.KeyboardEvent('keydown', { key: 'F2', cancelable: true });
      
      await globalKeydownHandler(event);
      
      // wait for promises
      await new Promise(resolve => setTimeout(resolve, 0));
      
      expect(uiManager.showPrompt).toHaveBeenCalled();
    });

    it('should call deleteSelectedFiles on Delete', async () => {
      appState.selectedIndex = 0;
      appState.selection.add(0);
      window.veloceAPI.getFilesByIndices = vi.fn().mockResolvedValue([{ path: '/path/to/0.jpg' }]);
      
      const event = new window.KeyboardEvent('keydown', { key: 'Delete', cancelable: true });
      
      await globalKeydownHandler(event);
      
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(window.veloceAPI.trashFile).toHaveBeenCalled();
    });

    it('should call performUndo on Ctrl+Z', async () => {
      appState.undoStack = [{ type: 'RENAME_FILE', oldPath: 'a', newPath: 'b' }];
      window.veloceAPI.renameFile = vi.fn().mockResolvedValue({ success: true });
      const event = new window.KeyboardEvent('keydown', { key: 'z', ctrlKey: true, cancelable: true });
      
      await globalKeydownHandler(event);
      
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(window.veloceAPI.renameFile).toHaveBeenCalled();
    });

    it('should set rating on 0-5 keys using getFilesByIndices and setRatingsBatch', async () => {
      appState.selectedIndex = 0;
      appState.selection.add(0);

      const event = new window.KeyboardEvent('keydown', { key: '5', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.getFilesByIndices).toHaveBeenCalledWith([0]);
      expect(window.veloceAPI.setRatingsBatch).toHaveBeenCalledWith([
        { path: '/path/to/0.jpg', rating: 5 }
      ]);
    });

    it('should batch update rating for multiple selected items on 0-5 keys', async () => {
      appState.selection.add(0);
      appState.selection.add(1);

      const event = new window.KeyboardEvent('keydown', { key: '4', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.getFilesByIndices).toHaveBeenCalledWith([0, 1]);
      expect(window.veloceAPI.setRatingsBatch).toHaveBeenCalledWith([
        { path: '/path/to/0.jpg', rating: 4 },
        { path: '/path/to/1.jpg', rating: 4 }
      ]);
    });

    it('should toggle rating back to 0 when all selected items have the same rating', async () => {
      appState.selection.add(0);
      appState.selection.add(1);
      appState.ratings['/path/to/0.jpg'] = 3;
      appState.ratings['/path/to/1.jpg'] = 3;

      const event = new window.KeyboardEvent('keydown', { key: '3', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.setRatingsBatch).toHaveBeenCalledWith([
        { path: '/path/to/0.jpg', rating: 0 },
        { path: '/path/to/1.jpg', rating: 0 }
      ]);
    });

    it('should fallback to getFileByIndex and setRating if batch APIs are missing', async () => {
      delete window.veloceAPI.getFilesByIndices;
      delete window.veloceAPI.setRatingsBatch;

      appState.selectedIndex = 0;
      appState.selection.add(0);

      const event = new window.KeyboardEvent('keydown', { key: '2', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.getFileByIndex).toHaveBeenCalledWith(0);
      expect(window.veloceAPI.setRating).toHaveBeenCalledWith('/path/to/0.jpg', 2);
    });

    it('should call hideCustomTooltip (via refreshFileList) on F5', async () => {
      appState.currentDirectory = '/some/dir';
      const event = new window.KeyboardEvent('keydown', { key: 'F5', cancelable: true });
      await globalKeydownHandler(event);
      expect(uiManager.hideCustomTooltip).toHaveBeenCalled();
    });

    it('should select all on Ctrl+A', async () => {
      appState.totalCount = 2;
      const event = new window.KeyboardEvent('keydown', { key: 'a', ctrlKey: true, cancelable: true });
      Object.defineProperty(event, 'target', { value: document.body });
      await globalKeydownHandler(event);
      expect(appState.selection.size).toBe(2);
      expect(appState.selectedIndex).toBe(1);
      expect(uiManager.updateSelectionUI).toHaveBeenCalled();
    });

    it('should call arrangeViewers on L', async () => {
      const event = new window.KeyboardEvent('keydown', { key: 'l', cancelable: true });
      await globalKeydownHandler(event);
      expect(window.veloceAPI.arrangeViewers).toHaveBeenCalled();
    });

    it('should show diff modal on D when 2 items are selected', async () => {
      appState.selection.add(0);
      appState.selection.add(1);
      const event = new window.KeyboardEvent('keydown', { key: 'd', cancelable: true });
      await globalKeydownHandler(event);
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(uiManager.showDiffModal).toHaveBeenCalled();
    });

    it('should show warning toast on D when selection size is not 2', async () => {
      appState.selection.clear();
      appState.selection.add(0);
      const event = new window.KeyboardEvent('keydown', { key: 'd', cancelable: true });
      await globalKeydownHandler(event);
      expect(uiManager.showToast).toHaveBeenCalledWith(
        'Diff機能を使用するには、Ctrlキーを押しながら画像を2つ選択してください。',
        3000,
        null,
        'warning'
      );
    });

    it('should openDiffModal directly and call showDiffModal', async () => {
      expect(openDiffModal).toBeDefined();
      await openDiffModal([0, 1]);
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(uiManager.showDiffModal).toHaveBeenCalled();
    });

    it('should not proceed in openDiffModal if indices length is not 2', async () => {
      uiManager.showDiffModal.mockClear();
      await openDiffModal([0]);
      expect(uiManager.showDiffModal).not.toHaveBeenCalled();
      await openDiffModal(null);
      expect(uiManager.showDiffModal).not.toHaveBeenCalled();
    });

    it('should call navigateHistory on Alt+ArrowLeft/Right', async () => {
      appState.tabs = [{ history: ['/a', '/b', '/c'], historyIndex: 1 }];
      appState.activeTabIndex = 0;

      const eventLeft = new window.KeyboardEvent('keydown', { key: 'ArrowLeft', altKey: true, cancelable: true });
      await globalKeydownHandler(eventLeft);
      // Let promises resolve
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(window.veloceAPI.loadDirectory).toHaveBeenCalledWith('/a');

      // Reset historyIndex to 1 before testing ArrowRight
      appState.tabs[0].historyIndex = 1;

      const eventRight = new window.KeyboardEvent('keydown', { key: 'ArrowRight', altKey: true, cancelable: true });
      await globalKeydownHandler(eventRight);
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(window.veloceAPI.loadDirectory).toHaveBeenCalledWith('/c');
    });

    it('should toggle help overlay on F1 or H', async () => {
      const eventF1 = new window.KeyboardEvent('keydown', { key: 'F1', cancelable: true });
      await globalKeydownHandler(eventF1);
      
      const overlay = document.getElementById('help-overlay');
      expect(overlay).not.toBeNull();
      
      // Cleanup
      if (overlay) overlay.remove();
    });

    it('should close overlays on Escape', async () => {
      const diffModal = document.createElement('div');
      diffModal.id = 'diff-modal';
      diffModal.classList.add('show');
      document.body.appendChild(diffModal);

      const event = new window.KeyboardEvent('keydown', { key: 'Escape', cancelable: true });
      await globalKeydownHandler(event);
      
      expect(diffModal.classList.contains('show')).toBe(false);
      diffModal.remove();
    });

    it('should switch tabs on Ctrl+Tab', async () => {
      appState.tabs = [{}, {}]; // 2 tabs
      appState.activeTabIndex = 0;
      
      const event = new window.KeyboardEvent('keydown', { key: 'Tab', ctrlKey: true, cancelable: true });
      await globalKeydownHandler(event);
      
      expect(window.onTabClick).toHaveBeenCalledWith(1);
    });

    it('should navigate by 1 row on ArrowDown and ArrowUp when table is active', async () => {
      appState.totalCount = 10;
      appState.selectedIndex = 2;
      appState.activeCenterPane = 'table';

      // ArrowDown should move index by +1
      const downEvent = new window.KeyboardEvent('keydown', { key: 'ArrowDown', cancelable: true });
      await globalKeydownHandler(downEvent);
      expect(appState.selectedIndex).toBe(3);

      // ArrowUp should move index by -1
      const upEvent = new window.KeyboardEvent('keydown', { key: 'ArrowUp', cancelable: true });
      await globalKeydownHandler(upEvent);
      expect(appState.selectedIndex).toBe(2);
    });

    it('should navigate by columns on ArrowDown when grid is active', async () => {
      appState.totalCount = 20;
      appState.selectedIndex = 0;
      appState.activeCenterPane = 'grid';

      // Mock thumbnail grid dimensions for column calculation (e.g. 5 columns)
      Object.defineProperty(uiManager.elements.thumbnailGrid, 'clientWidth', { value: 650, configurable: true });
      uiManager.elements.thumbnailSizeSlider.value = '120';

      const downEvent = new window.KeyboardEvent('keydown', { key: 'ArrowDown', cancelable: true });
      await globalKeydownHandler(downEvent);

      // Should move by columns (>= 2)
      expect(appState.selectedIndex).toBeGreaterThan(1);
    });
  });

  describe('renderMultipleSelectionSummary', () => {
    it('should format headerPath with bdi and without redundant inline opacity', async () => {
      appState.selection = new Set([0, 1]);
      appState.totalCount = 5;

      const headerPath = document.getElementById('inspector-header-path');
      headerPath.setAttribute('data-path', '/dummy/path.png');
      headerPath.style.display = 'none';

      await renderMultipleSelectionSummary();

      expect(headerPath.innerHTML).toBe('<bdi dir="ltr">2 / 5 件選択中 (40.0%)</bdi>');
      expect(headerPath.innerHTML).not.toContain('opacity');
      expect(headerPath.hasAttribute('data-path')).toBe(false);
      expect(headerPath.style.display).toBe('block');
    });
  });

  describe('Help Modal Shortcut Table', () => {
    it('should include I key and text copy descriptions in help table', () => {
      const fs = require('fs');
      const path = require('path');
      const helpJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-help.js'), 'utf-8');

      // ビューアー画面のショートカットに I キーが含まれていること
      expect(helpJs).toContain('<tr><td><kbd>I</kbd></td><td>メタデータオーバーレイの表示 / 非表示</td></tr>');

      // メイン画面およびビューアー画面の Ctrl+C にテキストコピーが含まれていること
      expect(helpJs).toContain('<tr><td><kbd>Ctrl</kbd> + <kbd>C</kbd></td><td>選択中の画像をクリップボードにコピー（テキスト選択中はテキストコピー）</td></tr>');
      expect(helpJs).toContain('<tr><td><kbd>Ctrl</kbd> + <kbd>C</kbd></td><td>表示中の画像をクリップボードにコピー（テキスト選択中はテキストコピー）</td></tr>');

      // ビューアー画面の Esc がビューワーウィンドウを閉じること
      expect(helpJs).toContain('<tr><td><kbd>Esc</kbd></td><td>ビューワーウィンドウを閉じる</td></tr>');
    });
  });

  describe('Modal & Dialog Shortcut Guard (Section 5)', () => {
    let dummyDialog;

    afterEach(() => {
      if (dummyDialog && dummyDialog.parentNode) {
        dummyDialog.remove();
        dummyDialog = null;
      }
    });

    it('isModalOrOverlayOpen correctly detects open modals and overlays', () => {
      expect(isModalOrOverlayOpen()).toBe(false);

      dummyDialog = document.createElement('div');
      dummyDialog.className = 'dialog-overlay show';
      document.body.appendChild(dummyDialog);
      expect(isModalOrOverlayOpen()).toBe(true);

      dummyDialog.className = 'dialog-overlay';
      expect(isModalOrOverlayOpen()).toBe(false);
    });

    it('guards against 0-5 rating shortcuts when dialog-overlay is open', async () => {
      dummyDialog = document.createElement('div');
      dummyDialog.className = 'dialog-overlay show';
      document.body.appendChild(dummyDialog);

      appState.selectedIndex = 0;
      appState.selection.add(0);

      const event = new window.KeyboardEvent('keydown', { key: '5', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.getFileByIndex).not.toHaveBeenCalled();
      expect(window.veloceAPI.getFilesByIndices).not.toHaveBeenCalled();
      expect(window.veloceAPI.setRating).not.toHaveBeenCalled();
      expect(window.veloceAPI.setRatingsBatch).not.toHaveBeenCalled();
    });

    it('guards against Delete key when dialog-overlay is open', async () => {
      dummyDialog = document.createElement('div');
      dummyDialog.className = 'dialog-overlay show';
      document.body.appendChild(dummyDialog);

      appState.selectedIndex = 0;
      appState.selection.add(0);

      const event = new window.KeyboardEvent('keydown', { key: 'Delete', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.veloceAPI.trashFile).not.toHaveBeenCalled();
      expect(window.deleteSelectedFiles).not.toHaveBeenCalled();
    });

    it('guards against F2 rename when modal is open', async () => {
      dummyDialog = document.createElement('div');
      dummyDialog.id = 'diff-modal';
      dummyDialog.className = 'modal show';
      document.body.appendChild(dummyDialog);

      appState.selectedIndex = 0;
      appState.selection.add(0);

      const event = new window.KeyboardEvent('keydown', { key: 'F2', cancelable: true });
      await globalKeydownHandler(event);

      expect(window.renameSelectedFile).not.toHaveBeenCalled();
    });

    it('guards against viewer launch (Enter) and arrange (L) when help-overlay is open', async () => {
      dummyDialog = document.createElement('div');
      dummyDialog.id = 'help-overlay';
      document.body.appendChild(dummyDialog);

      appState.selectedIndex = 0;

      const enterEvent = new window.KeyboardEvent('keydown', { key: 'Enter', cancelable: true });
      await globalKeydownHandler(enterEvent);

      const lEvent = new window.KeyboardEvent('keydown', { key: 'l', cancelable: true });
      await globalKeydownHandler(lEvent);

      expect(window.veloceAPI.arrangeViewers).not.toHaveBeenCalled();
    });

    it('guards against Diff modal (D) and refresh (F5) when edit-smart-folder-modal is open', async () => {
      dummyDialog = document.createElement('div');
      dummyDialog.id = 'edit-smart-folder-modal';
      dummyDialog.className = 'dialog-overlay show';
      document.body.appendChild(dummyDialog);

      appState.selection.add(0);
      appState.selection.add(1);

      const dEvent = new window.KeyboardEvent('keydown', { key: 'd', cancelable: true });
      await globalKeydownHandler(dEvent);

      expect(uiManager.showDiffModal).not.toHaveBeenCalled();
      expect(uiManager.showToast).not.toHaveBeenCalled();
    });
  });
});
