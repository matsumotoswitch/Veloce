import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { getFullCssContent } from './helpers/css-helper.js';

describe('Design Token and Color Consistency (AGENTS.md Sec 2)', () => {
  const cssContent = getFullCssContent();

  it('should define essential color tokens in :root', () => {
    expect(cssContent).toContain('--glow-gold:');
    expect(cssContent).toContain('--danger-red:');
    expect(cssContent).toContain('--border-color:');
    expect(cssContent).toContain('--border-color-light:');
    expect(cssContent).toContain('--text-color:');
    expect(cssContent).toContain('--bg-color:');
  });

  it('should use var(--border-color) for scrollbar thumb instead of hardcoded hex', () => {
    expect(cssContent).toMatch(/::-webkit-scrollbar-thumb\s*\{[^}]*background-color:\s*var\(--border-color\);/);
    expect(cssContent).not.toContain('background-color: #3a454a;');
  });

  it('should use var(--text-color) with opacity for tree toggle icon instead of #888', () => {
    expect(cssContent).toMatch(/\.toggle-icon\s*\{[^}]*color:\s*var\(--text-color\);/);
    expect(cssContent).toMatch(/\.toggle-icon\s*\{[^}]*opacity:\s*0\.5;/);
    expect(cssContent).not.toMatch(/\.toggle-icon\s*\{[^}]*color:\s*#888;/);
  });

  it('should use var(--danger-red) for viewer close button hover', () => {
    expect(cssContent).toMatch(/\.viewer-body #window-controls:not\(\.has-gradient\)\s+\.window-ctrl-btn--close:hover\s*\{[^}]*background-color:\s*var\(--danger-red\);/);
  });

  it('should use var(--glow-gold) for thumbnail rating badge instead of #ffd700', () => {
    expect(cssContent).toMatch(/\.rating-badge svg\s*\{[^}]*fill:\s*var\(--glow-gold\);/);
    expect(cssContent).not.toMatch(/\.rating-badge svg\s*\{[^}]*fill:\s*#ffd700;/);
  });

  it('should style thumbnail rating badge with lightweight translucency without backdrop-filter', () => {
    expect(cssContent).toMatch(/\.rating-badge\s*\{[^}]*background-color:\s*rgba\(0,\s*0,\s*0,\s*0\.45\);/);
    expect(cssContent).toMatch(/\.rating-badge\s*\{[^}]*border:\s*1px solid rgba\(255,\s*255,\s*255,\s*0\.18\);/);
    expect(cssContent).toMatch(/\.rating-badge\s*\{[^}]*box-shadow:\s*0 2px 6px rgba\(0,\s*0,\s*0,\s*0\.35\);/);
    expect(cssContent).not.toMatch(/\.rating-badge\s*\{[^}]*backdrop-filter:\s*blur/);
  });

  it('should style thumbnail-label with lightweight translucency consistent with rating-badge', () => {
    expect(cssContent).toMatch(/\.thumbnail-label\s*\{[^}]*background-color:\s*rgba\(0,\s*0,\s*0,\s*0\.45\);/);
    expect(cssContent).toMatch(/\.thumbnail-label\s*\{[^}]*border:\s*1px solid rgba\(255,\s*255,\s*255,\s*0\.18\);/);
    expect(cssContent).toMatch(/\.thumbnail-label\s*\{[^}]*text-shadow:\s*0 1px 2px rgba\(0,\s*0,\s*0,\s*0\.8\);/);
    expect(cssContent).not.toMatch(/\.thumbnail-label\s*\{[^}]*opacity:\s*0\.75;/);
  });

  it('should unify rating-badge and thumbnail-label hover styles and remove drop-shadow on svg', () => {
    expect(cssContent).toMatch(/\.thumbnail-item:hover \.rating-badge\s*\{[^}]*background-color:\s*rgba\(0,\s*0,\s*0,\s*0\.75\);/);
    expect(cssContent).toMatch(/\.thumbnail-item:hover \.thumbnail-label\s*\{[^}]*background-color:\s*rgba\(0,\s*0,\s*0,\s*0\.75\);/);
    expect(cssContent).not.toMatch(/\.rating-badge svg\s*\{[^}]*filter:\s*drop-shadow/);
  });

  it('should define common .rating-star-icon using var(--glow-gold)', () => {
    expect(cssContent).toMatch(/\.rating-star-icon\s*\{[^}]*fill:\s*var\(--glow-gold\);/);
  });

  it('should use var(--text-light) for titlebar and window control buttons instead of #ffffff', () => {
    expect(cssContent).toMatch(/\.titlebar-button:hover\s*\{[^}]*color:\s*var\(--text-light\);/);
    expect(cssContent).toMatch(/\.titlebar-button\.titlebar-close:hover\s*\{[^}]*color:\s*var\(--text-light\);/);
    expect(cssContent).toMatch(/\.window-ctrl-btn--close:hover\s*\{[^}]*color:\s*var\(--text-light\);/);
  });

  it('should not contain raw unaliased #ffd700 outside variable definitions or fallback declarations in CSS', () => {
    // :root の定義行と var(--..., #ffd700) 以外の直接指定（例: fill: #ffd700; color: #ffd700;）を排除
    const lines = cssContent.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.includes('#ffd700')) {
        const isRootDef = line.includes('--glow-gold:');
        const isVarFallback = line.includes('var(');
        expect(isRootDef || isVarFallback, `Raw #ffd700 found at line ${i + 1}: "${line}"`).toBe(true);
      }
    }
  });

  it('should use var(--accent-hover) for .diff-tag.added instead of hardcoded #61c7d6', () => {
    expect(cssContent).toMatch(/\.diff-tag\.added\s*\{[^}]*color:\s*var\(--accent-hover\);/);
    expect(cssContent).not.toMatch(/\.diff-tag\.added\s*\{[^}]*color:\s*#61c7d6;/);
  });

  it('should define .diff-tag.search-match using var(--glow-gold)', () => {
    expect(cssContent).toMatch(/\.diff-tag\.search-match\s*\{[^}]*color:\s*var\(--glow-gold\)/);
    expect(cssContent).toMatch(/\.diff-tag\.search-match\s*\{[^}]*border-color:\s*var\(--glow-gold\)/);
  });

  it('should define help and license modal classes in style.css', () => {
    expect(cssContent).toContain('.license-modal-content');
    expect(cssContent).toContain('.modal-header-row');
    expect(cssContent).toContain('.modal-header-title');
    expect(cssContent).toContain('.license-link-btn');
    expect(cssContent).toContain('#license-text');
  });

  it('should use var(--accent-hover) in layout.css for folder tree icons instead of hardcoded colors or inline styles in renderer.js', () => {
    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    expect(cssContent).toMatch(/#dir-tree \.tree-icon\s*\{[^}]*color:\s*var\(--accent-hover\);/);
    expect(rendererJs).not.toContain("icon.style.color = '#4da8da';");
    expect(rendererJs).not.toContain("icon.style.color = 'var(--accent-hover)';");
  });

  it('should use classList.toggle for inspector search match in renderer-inspector.js instead of inline #ffcc00 styling', () => {
    const inspectorJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-inspector.js'), 'utf-8');
    expect(inspectorJs).toContain("tagEl.classList.toggle('search-match', isMatch);");
    expect(inspectorJs).not.toContain("tagEl.style.color = '#ffcc00';");
    expect(inspectorJs).not.toContain("tagEl.style.border = '1px solid #ffcc00';");
  });

  it('should use shared BROKEN_MP4_FALLBACK_URL constant in renderer-thumbnails.js instead of inline btoa', () => {
    const thumbnailsJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-thumbnails.js'), 'utf-8');
    expect(thumbnailsJs).toContain('const fallbackUrl = BROKEN_MP4_FALLBACK_URL;');
    expect(thumbnailsJs).not.toContain("btoa(BROKEN_SVG)");
  });

  it('should maintain outer accent border and box-shadow on search container while suppressing inner focus line on search bar', () => {
    expect(cssContent).toMatch(/#search-container:focus-within\s*\{[^}]*border-color:\s*var\(--accent-color\);/);
    expect(cssContent).toMatch(/#search-container:focus-within\s*\{[^}]*box-shadow:\s*0 0 0 2px var\(--accent-hover-tint\);/);
    expect(cssContent).toMatch(/#search-bar:focus-visible\s*\{[^}]*box-shadow:\s*none;/);
  });

  it('should define generation technique color tokens in :root', () => {
    expect(cssContent).toContain('--color-tag-inpainting: #4a9eff;');
    expect(cssContent).toContain('--color-tag-vibe: #d27aff;');
    expect(cssContent).toContain('--color-tag-char-ref: #ff9a4a;');
    expect(cssContent).toContain('--color-tag-img2img: #4ade80;');
  });

  it('should define unified classes for sublabel tags, raw-box, flash-effect, drag-ghost, and virtual containers', () => {
    expect(cssContent).toContain('.sublabel-tags-wrapper');
    expect(cssContent).toContain('.sublabel-tag--inpainting');
    expect(cssContent).toContain('.prompt-look.raw-box');
    expect(cssContent).toContain('#viewer-flash-effect');
    expect(cssContent).toContain('.bookmark-drag-ghost');
    expect(cssContent).toContain('.virtual-content');
  });

  it('should not contain hardcoded technique hex colors in renderer.js or renderer-ui.js', () => {
    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    const rendererUiJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-ui.js'), 'utf-8');

    for (const code of [rendererJs, rendererUiJs]) {
      expect(code).not.toContain("color = '#4a9eff'");
      expect(code).not.toContain("color = '#d27aff'");
      expect(code).not.toContain("color = '#ff9a4a'");
      expect(code).not.toContain("color = '#4ade80'");
    }
  });

  it('should define table cell right alignments in style.css and avoid inline textAlign in renderer-ui.js', () => {
    expect(cssContent).toMatch(/#file-table td:nth-child\(3\)[^}]*text-align:\s*right;/);
    const rendererUiJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-ui.js'), 'utf-8');
    expect(rendererUiJs).not.toContain("tds[2].style.textAlign = 'right'");
  });

  it('should define .thumbnail-flash-effect in style.css and eliminate forced reflow getComputedStyle in renderer.js', () => {
    expect(cssContent).toMatch(/\.thumbnail-flash-effect\s*\{[^}]*position:\s*fixed;/);
    expect(cssContent).toMatch(/\.thumbnail-flash-effect\s*\{[^}]*border-radius:\s*var\(--radius-xs\);/);
    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    expect(rendererJs).not.toContain('window.getComputedStyle(el).borderRadius');
    expect(rendererJs).toContain("flash.className = 'thumbnail-flash-effect'");
  });

  it('should define tab-list-item sub-elements in style.css and eliminate inline styles in tabListMenu', () => {
    expect(cssContent).toMatch(/\.tab-list-item \.tab-list-icon\s*\{/);
    expect(cssContent).toMatch(/\.tab-list-item \.tab-menu-item-text\s*\{/);
    expect(cssContent).toMatch(/\.tab-list-item \.tab-menu-item-name\s*\{/);
    expect(cssContent).toMatch(/\.tab-list-item \.tab-close-btn\s*\{/);

    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    expect(rendererJs).not.toContain("textContainer.style.display = 'flex'");
    expect(rendererJs).not.toContain("nameLabel.style.fontWeight =");
    expect(rendererJs).not.toContain("closeBtn.style.flexShrink = '0'");
  });

  it('should define #tab-container .tab-item .tab-icon in style.css and eliminate inline styles in renderer-ui.js', () => {
    expect(cssContent).toMatch(/#tab-container \.tab-item \.tab-icon\s*\{[^}]*margin-right:\s*6px;/);
    const rendererUiJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-ui.js'), 'utf-8');
    expect(rendererUiJs).not.toContain("iconSpan.style.marginRight = '6px'");
  });

  it('should define .tab-collapsing in style.css and eliminate multi-property inline style assignments in renderer-tabs.js', () => {
    expect(cssContent).toMatch(/#tab-container \.tab-item\.tab-collapsing\s*\{[^}]*transition:\s*min-width/);
    const rendererTabsJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-tabs.js'), 'utf-8');
    expect(rendererTabsJs).toContain("targetTabEl.classList.add('tab-collapsing')");
    expect(rendererTabsJs).not.toContain("targetTabEl.style.minWidth = '0'");
  });

  it('should unify license modal colors with modal tokens and avoid #0d1315 or panel-bg', () => {
    expect(cssContent).toMatch(/\.license-modal-content\s*\{[^}]*background-color:\s*var\(--modal-bg\);/);
    expect(cssContent).toMatch(/\.license-modal-content\s*\{[^}]*border:\s*1px solid var\(--modal-border\);/);
    expect(cssContent).not.toContain('#0d1315');
  });

  it('should use var(--text-light) in help-overlay and license-link-btn:hover instead of #fff', () => {
    expect(cssContent).toMatch(/#help-overlay\s*\{[^}]*color:\s*var\(--text-light\);/);
    expect(cssContent).toMatch(/\.license-link-btn:hover\s*\{[^}]*color:\s*var\(--text-light\);/);
    expect(cssContent).not.toContain('color: #fff;');
  });

  it('should consolidate diff section headers in style.css and eliminate inline styles in renderer-ui.js', () => {
    expect(cssContent).toMatch(/\.diff-section h3\s*\{[^}]*display:\s*flex;/);
    expect(cssContent).toMatch(/\.diff-section h3 > span\s*\{[^}]*display:\s*flex;/);
    const rendererUiJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-ui.js'), 'utf-8');
    expect(rendererUiJs).not.toContain('style="display: flex; justify-content: space-between;');
  });

  it('should define .is-dragging in style.css and avoid inline opacity assignments in renderer.js and renderer-ui.js', () => {
    expect(cssContent).toMatch(/\.tab-item\.is-dragging,\s*\.bookmark-item\.is-dragging\s*\{[^}]*opacity:\s*0\.5/);
    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    const rendererUiJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-ui.js'), 'utf-8');
    expect(rendererJs).not.toContain("itemDiv.style.opacity = '0.5'");
    expect(rendererUiJs).not.toContain("tabEl.style.opacity = '0.5'");
  });

  it('should define unsharp-svg and viewer info-container gradient styles in style.css and eliminate inline styles in viewer.js', () => {
    expect(cssContent).toMatch(/\.unsharp-svg\s*\{[^}]*position:\s*absolute;/);
    expect(cssContent).toMatch(/\.viewer-body #window-controls:not\(\.has-gradient\)\s+\.window-info-container\s*\{[^}]*background-color:\s*var\(--viewer-controls-bg\);/);
    const viewerJs = fs.readFileSync(path.resolve(__dirname, '../src/viewer/viewer.js'), 'utf-8');
    expect(viewerJs).not.toContain("svgElement.style.position = 'absolute'");
    expect(viewerJs).not.toContain("infoContainer.style.backgroundColor = 'rgba(0, 0, 0, 0.4)'");
  });

  it('should eliminate forced reflow querySelector for table thead in scrollToIndex', () => {
    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    expect(rendererJs).not.toContain("document.querySelector('#file-table thead')?.getBoundingClientRect()");
    expect(rendererJs).toContain("const theadHeight = 32;");
  });

  it('should unify bookmark-overflow-menu and history-menu using show class instead of inline display/animation', () => {
    const rendererJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer.js'), 'utf-8');
    const bookmarksJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-bookmarks.js'), 'utf-8');
    expect(bookmarksJs).not.toContain("bookmarkOverflowMenu.style.display = 'block'");
    expect(bookmarksJs).not.toContain("bookmarkOverflowMenu.style.transition =");
    expect(rendererJs).not.toContain("overflowMenu.style.display = 'none'");
    expect(bookmarksJs).toContain("bookmarkOverflowMenu.classList.add('show')");
    expect(bookmarksJs).toContain("bookmarkOverflowMenu.classList.remove('show')");
    expect(rendererJs).toContain("overflowMenu.classList.remove('show')");
  });

  it('should define extended transition and font-family tokens in :root', () => {
    expect(cssContent).toContain('--transition-close:');
    expect(cssContent).toContain('--transition-glow:');
    expect(cssContent).toContain('--font-family-base:');
    expect(cssContent).toContain('--font-family-mono:');
  });

  it('should not contain unaliased font-size: 14px in any stylesheet module', () => {
    expect(cssContent).not.toMatch(/font-size:\s*14px;/);
  });

  it('should use design tokens for border-radius across UI components', () => {
    expect(cssContent).toMatch(/::-webkit-scrollbar-thumb\s*\{[^}]*border-radius:\s*var\(--radius-md\);/);
    expect(cssContent).toMatch(/\.thumbnail-label\s*\{[^}]*border-radius:\s*var\(--radius-sm\);/);
    expect(cssContent).toMatch(/\.rating-badge\s*\{[^}]*border-radius:\s*var\(--radius-sm\);/);
    expect(cssContent).toMatch(/#video-controls-container\s*\{[^}]*border-radius:\s*var\(--radius-md\);/);
    expect(cssContent).toMatch(/#video-play-btn\s*\{[^}]*border-radius:\s*var\(--radius-xs\);/);
  });

  it('should use var(--transition-close) and var(--transition-glow) instead of raw cubic-bezier curves', () => {
    expect(cssContent).toMatch(/\.dialog-overlay,\s*\.modal\s*\{[^}]*transition:[^}]*var\(--transition-close\)/);
    expect(cssContent).toMatch(/\.dialog-box\s*\{[^}]*transition:[^}]*var\(--transition-close\)/);
    expect(cssContent).toMatch(/#context-menu[^}]*transition:[^}]*var\(--transition-close\)/);
    expect(cssContent).toMatch(/\.custom-select-menu\s*\{[^}]*transition:[^}]*var\(--transition-close\)/);
    expect(cssContent).toMatch(/\.rating-badge\.rating-pop\s*\{[^}]*animation:\s*rating-pop\s+0\.35s\s+var\(--transition-bounce\);/);
    expect(cssContent).toMatch(/\.rating-badge\.rating-hide\s*\{[^}]*animation:\s*rating-hide\s+0\.28s\s+var\(--transition-fast\)\s+forwards;/);
    expect(cssContent).toMatch(/#viewer-flash-effect\s*\{[^}]*transition:[^}]*var\(--transition-glow\)/);
  });

  it('should use rgba(var(--accent-rgb), 0.35) for bookmark-item.selected gradient without hardcoded RGB values', () => {
    expect(cssContent).toMatch(/\.bookmark-item\.selected\s*\{[^}]*background:\s*linear-gradient\(135deg,\s*rgba\(var\(--accent-rgb\),\s*0\.25\),\s*rgba\(var\(--accent-rgb\),\s*0\.35\)\);/);
    expect(cssContent).not.toContain('rgba(28, 94, 105');
  });

  it('should dynamically resolve thumbnail canvas background from --bg-darker token instead of hardcoded hex', async () => {
    const thumbnailsJs = fs.readFileSync(path.resolve(__dirname, '../src/renderer/renderer-thumbnails.js'), 'utf-8');
    expect(thumbnailsJs).not.toMatch(/const THUMBNAIL_CANVAS_BG = '#1e1e1e';/);
    expect(thumbnailsJs).toContain('getThumbnailCanvasBg');

    const { getThumbnailCanvasBg, resetThumbnailCanvasBg } = await import('../src/renderer/renderer-thumbnails.js');
    resetThumbnailCanvasBg();

    // Default fallback
    expect(getThumbnailCanvasBg()).toBe('#1e1e1e');

    // Dynamic resolution from getComputedStyle
    resetThumbnailCanvasBg();
    const origGetComputedStyle = window.getComputedStyle;
    window.getComputedStyle = () => ({
      getPropertyValue: (prop) => prop === '--bg-darker' ? '#121212' : ''
    });

    expect(getThumbnailCanvasBg()).toBe('#121212');
    window.getComputedStyle = origGetComputedStyle;
    resetThumbnailCanvasBg();
  });

  it('should differentiate inactive tabs from titlebar using var(--tab-inactive-bg), micro-borders, and tab gap', () => {
    // #tab-bar left offset for sufficient breathing room and drag space
    expect(cssContent).toMatch(/#tab-bar\s*\{[^}]*left:\s*20px;/);

    // #tab-container gap for clear tab separation
    expect(cssContent).toMatch(/#tab-container\s*\{[^}]*gap:\s*2px/);

    // Inactive tab background tone from design system token
    expect(cssContent).toMatch(/#tab-container \.tab-item\s*\{[^}]*background-color:\s*var\(--tab-inactive-bg\)/);

    // Subtle edge lines for inactive tabs to distinguish tab geometry from titlebar
    expect(cssContent).toMatch(/#tab-container \.tab-item\s*\{[^}]*border-top:\s*1px solid rgba\(255,\s*255,\s*255,\s*0\.08\)/);
    expect(cssContent).toMatch(/#tab-container \.tab-item\s*\{[^}]*border-left:\s*1px solid rgba\(255,\s*255,\s*255,\s*0\.05\)/);
    expect(cssContent).toMatch(/#tab-container \.tab-item\s*\{[^}]*border-bottom:\s*1px solid var\(--border-color-light\)/);

    // Smooth horizontal gradient masks on #tab-container when overflowing to connect boundaries seamlessly without clipping
    expect(cssContent).toMatch(/#tab-container\.has-overflow-left[^{]*\{[^}]*-webkit-mask-image:\s*linear-gradient\(/);
    expect(cssContent).toMatch(/#tab-container\.has-overflow-right[^{]*\{[^}]*-webkit-mask-image:\s*linear-gradient\(/);
  });

  it('should strictly comply with user design requirements across all surface hierarchies', () => {
    // 1. Darkest surface is titlebar background (#000000)
    expect(cssContent).toContain('--titlebar-bg: #000000;');

    // 2. Active tab uses --top-bar-bg and stands out
    expect(cssContent).toMatch(/#tab-container \.tab-item\.active\s*\{[^}]*background-color:\s*var\(--top-bar-bg\)/);

    // 3. Active tab and nav/toolbar share the exact same background
    expect(cssContent).toMatch(/\.toolbar\s*\{[^}]*background-color:\s*var\(--top-bar-bg\);/);

    // 4. Inactive tab background integrated to #080d0f
    expect(cssContent).toContain('--tab-inactive-bg: #080d0f;');
    expect(cssContent).toContain('--top-bar-bg: #22343a;');
    expect(cssContent).toMatch(/#tab-container \.tab-item\s*\{[^}]*background-color:\s*var\(--tab-inactive-bg\)/);

    // Consolidated dark surface tokens (Proposal 1, 2, 3)
    expect(cssContent).toContain('--viewer-bg: #141a1d;');
    expect(cssContent).toContain('--modal-bg: #22343a;');
    expect(cssContent).toContain('--dialog-bg: #22343a;');
    expect(cssContent).toContain('--input-bg: #182529;');
    expect(cssContent).toContain('--checkerboard-light: #22343a;');

    // 5. Pane headers and resize handles share the exact same color (--panel-bg)
    expect(cssContent).toContain('--panel-bg: #182529;');
    expect(cssContent).toMatch(/\.pane-header\s*\{[^}]*background:\s*var\(--panel-bg\);/);
    expect(cssContent).toMatch(/#left-pane\s*\{[^}]*background:\s*var\(--bg-color\);/);
    expect(cssContent).toMatch(/#right-pane\s*\{[^}]*background:\s*var\(--bg-color\);/);
    expect(cssContent).toMatch(/#file-table th\s*\{[^}]*background:\s*var\(--panel-bg\);/);
    expect(cssContent).toMatch(/#thumbnail-controls\s*\{[^}]*background:\s*var\(--panel-bg\);/);
    expect(cssContent).toMatch(/\.resizer\s*\{[^}]*background-color:\s*var\(--panel-bg\);/);
    expect(cssContent).toMatch(/\.resizer-h\s*\{[^}]*background-color:\s*var\(--panel-bg\);/);

    // 6. Hierarchy: bookmark-bar (18%) > pane headers (13%) > pane background (5%)
    expect(cssContent).toMatch(/#bookmark-bar\s*\{[^}]*background-color:\s*var\(--top-bar-bg\);/);
    expect(cssContent).toContain('--bg-color: #080d0f;');

    // 7. Border visibility: boundary lines are distinctly brighter than panels and toolbars (#3b5057: ~29% lightness)
    expect(cssContent).toContain('--border-color: #3b5057;');
  });

  it('should allocate sufficient width for rating filter dropdowns to prevent label truncation', () => {
    expect(cssContent).toMatch(/#custom-rating-val-container\s*\{[^}]*width:\s*108px;/);
    expect(cssContent).toMatch(/#custom-rating-op-container\s*\{[^}]*width:\s*96px;/);
  });

  it('should unify thumbnail-controls header height and border-bottom with other pane headers', () => {
    expect(cssContent).toMatch(/#thumbnail-controls\s*\{[^}]*border-bottom:\s*1px solid var\(--border-color\);/);
    expect(cssContent).toMatch(/#thumbnail-controls\s*\{[^}]*height:\s*var\(--header-height\);/);
  });

  it('should define distinct border tokens for default dark surfaces and bright/translucent surfaces', () => {
    // 1. Default boundary lines are distinctly calm (#3b5057: ~29% lightness)
    expect(cssContent).toContain('--border-color: #3b5057;');

    // 2. Bright surface border token (#4a656d: ~36% lightness)
    expect(cssContent).toContain('--border-color-light: #4a656d;');
    expect(cssContent).toContain('--border-light: var(--border-color-light);');

    // 3. Bright surface elements utilize --border-color-light
    expect(cssContent).toMatch(/#search-container\s*\{[^}]*border:\s*1px solid var\(--border-color-light\);/);
    expect(cssContent).toMatch(/#tab-container \.tab-item\.active\s*\{[^}]*border-top:\s*1px solid var\(--border-color-light\)/);
    expect(cssContent).toMatch(/\.titlebar\s*\{[^}]*border-bottom:\s*1px solid var\(--border-color-light\)/);
    expect(cssContent).toMatch(/\.toolbar\s*\{[^}]*border-bottom:\s*1px solid var\(--border-color-light\);/);
    expect(cssContent).toMatch(/#bookmark-bar\s*\{[^}]*border-bottom:\s*1px solid var\(--border-color-light\);/);
    // Proposal 4-1 (Option B): .control-divider uses var(--border-color) instead of high-contrast --border-color-light
    expect(cssContent).toMatch(/\.viewer-metadata-overlay\s*\{[^}]*border-left:\s*1px solid var\(--border-color-light\);/);
    expect(cssContent).toMatch(/\.viewer-metadata-overlay \.prompt-look\s*\{[^}]*border-color:\s*var\(--border-color-light\);/);
  });

  it('should define --viewer-bg-rgb and --marker-hud-bg tokens and use them for position markers', () => {
    expect(cssContent).toContain('--viewer-bg-rgb: 20, 26, 29;');
    expect(cssContent).toContain('--marker-hud-bg: rgba(var(--viewer-bg-rgb), 0.85);');
    expect(cssContent).toMatch(/\.inspector-position-marker\s*\{[^}]*background-color:\s*var\(--marker-hud-bg\);/);
    expect(cssContent).toMatch(/\.inspector-coord-badge\s*\{[^}]*background-color:\s*var\(--marker-hud-bg\);/);
    expect(cssContent).not.toMatch(/\.inspector-position-marker\s*\{[^}]*background-color:\s*rgba\(19,\s*27,\s*30/);
  });

  it('should eliminate duplicate borders and reduce control divider contrast (Proposal 4-1 Option B & 4-2)', () => {
    // 提案4-1 (案B): .control-divider の白浮きを高コントラストな --border-color-light から --border-color に引き下げて低減
    expect(cssContent).toMatch(/\.control-divider\s*\{[^}]*background-color:\s*var\(--border-color\);/);
    expect(cssContent).not.toMatch(/\.control-divider\s*\{[^}]*background-color:\s*var\(--border-color-light\);/);

    // 提案4-2: テーブル最下行のセル下線を解除し、コンテナ下端(#center-top)の境界線との重複を排除して単一化
    const layoutCssPath = path.resolve(__dirname, '../src/renderer/css/layout.css');
    const layoutContent = fs.readFileSync(layoutCssPath, 'utf-8');
    const lastRowMatch = layoutContent.match(/#file-list-body\s+tr:last-child,\s*[\r\n]+#file-list-body\s+tr:last-child\s+td\s*\{([^}]+)\}/);
    expect(lastRowMatch).not.toBeNull();
    expect(lastRowMatch[1]).toMatch(/border-bottom:\s*none;/);
  });

  it('should define unified translucent accent tokens and apply them across controls (Proposal 5)', () => {
    // 提案5: 半透明アクセント（アルファ値）の4段階トークン定義
    expect(cssContent).toContain('--accent-subtle: rgba(var(--accent-rgb), 0.12);');
    expect(cssContent).toContain('--accent-hover-tint: rgba(var(--accent-rgb), 0.25);');
    expect(cssContent).toContain('--accent-active-tint: rgba(var(--accent-rgb), 0.40);');
    expect(cssContent).toContain('--accent-focus-ring: rgba(var(--accent-rgb), 0.60);');

    // コントロールへの段階的適用
    const layoutCssPath = path.resolve(__dirname, '../src/renderer/css/layout.css');
    const layoutContent = fs.readFileSync(layoutCssPath, 'utf-8');
    const componentsCssPath = path.resolve(__dirname, '../src/renderer/css/components.css');
    const componentsContent = fs.readFileSync(componentsCssPath, 'utf-8');
    const dialogsCssPath = path.resolve(__dirname, '../src/renderer/css/dialogs.css');
    const dialogsContent = fs.readFileSync(dialogsCssPath, 'utf-8');

    // 検索ボックス・ドロップダウンのフォーカスリング (0.25)
    expect(layoutContent).toMatch(/#search-container:focus-within\s*\{[^}]*box-shadow:\s*0 0 0 2px var\(--accent-hover-tint\);/);
    expect(componentsContent).toMatch(/\.custom-select:focus,\s*[\r\n]+\.custom-select\.open\s*\{[^}]*box-shadow:\s*0 0 0 2px var\(--accent-hover-tint\);/);

    // ドロップダウンメニューのホバー (0.25) と選択 (0.12)
    expect(dialogsContent).toMatch(/\.custom-select-item:hover\s*\{[^}]*background-color:\s*var\(--accent-hover-tint\);/);
    expect(dialogsContent).toMatch(/\.custom-select-item\.selected\s*\{[^}]*background-color:\s*var\(--accent-subtle\);/);

    // テーブル・ツリー行ホバー (0.25) と選択 (0.40)
    expect(layoutContent).toMatch(/#file-table\s+tr:hover\s*\{[^}]*background:\s*var\(--accent-hover-tint\);/);
    expect(layoutContent).toMatch(/#file-table\s+tr\.selected\s*\{[^}]*background:\s*var\(--accent-active-tint\);/);
    expect(layoutContent).toMatch(/#dir-tree\s+\.tree-item:hover\s*\{[^}]*background-color:\s*var\(--accent-hover-tint\);/);
    expect(layoutContent).toMatch(/#dir-tree\s+\.tree-item\.selected\s*\{[^}]*background:\s*var\(--accent-active-tint\);/);

    // スライダーつまみホバー・キーボードフォーカスリング (0.60)
    expect(componentsContent).toMatch(/input\[type="range"\]::-webkit-slider-thumb:hover\s*\{[^}]*box-shadow:\s*0 0 6px var\(--accent-focus-ring\);/);
  });

  it('should ensure prompt-look uses var(--prompt-bg) (#000000) and diff-tag uses var(--bg-color) to maintain user 5-tier design scheme', () => {
    const variablesCssPath = path.resolve(__dirname, '../src/common/css/variables.css');
    const variablesContent = fs.readFileSync(variablesCssPath, 'utf-8');
    const dialogsCssPath = path.resolve(__dirname, '../src/renderer/css/dialogs.css');
    const dialogsContent = fs.readFileSync(dialogsCssPath, 'utf-8');
    const layoutCssPath = path.resolve(__dirname, '../src/renderer/css/layout.css');
    const layoutContent = fs.readFileSync(layoutCssPath, 'utf-8');

    // タグ領域の背景色（奥に沈むコンテナ）: #000000
    expect(variablesContent).toContain('--prompt-bg: #000000;');

    // タグ領域（奥に沈むコンテナ）が var(--prompt-bg) であること
    expect(dialogsContent).toMatch(/\.prompt-look\s*\{[^}]*background-color:\s*var\(--prompt-bg\);/);
    // タグチップが var(--bg-color) (#080d0f) であること
    expect(dialogsContent).toMatch(/\.diff-tag\s*\{[^}]*background-color:\s*var\(--bg-color\);/);

    // 検索バー（ツールバー全体）が #22343a (var(--top-bar-bg)) であり、検索入力枠（テキストボックス）が #182529 (var(--panel-bg)) であること
    expect(layoutContent).toMatch(/\.toolbar\s*\{[^}]*background-color:\s*var\(--top-bar-bg\);/);
    expect(layoutContent).toMatch(/#search-container\s*\{[^}]*background:\s*var\(--panel-bg\);/);

    // 非アクティブタブホバーが #182529 (var(--panel-bg)) に統合されていること
    expect(layoutContent).toMatch(/#tab-container \.tab-item:not\(\.active\):hover\s*\{[^}]*background-color:\s*var\(--panel-bg\)/);
  });

  it('should ensure tag hover uses var(--accent-hover-tint) for cyan hue consistency without hardcoded white tints', () => {
    const dialogsCssPath = path.resolve(__dirname, '../src/renderer/css/dialogs.css');
    const dialogsContent = fs.readFileSync(dialogsCssPath, 'utf-8');
    const viewerCssPath = path.resolve(__dirname, '../src/viewer/viewer.css');
    const viewerContent = fs.readFileSync(viewerCssPath, 'utf-8');
    const rendererJsPath = path.resolve(__dirname, '../src/renderer/renderer.js');
    const rendererJsContent = fs.readFileSync(rendererJsPath, 'utf-8');

    // dialogs.css の .diff-tag:hover で var(--accent-hover-tint) が使用されていること
    expect(dialogsContent).toMatch(/\.diff-tag:hover\s*\{[^}]*background-color:\s*var\(--accent-hover-tint\);/);
    expect(dialogsContent).not.toMatch(/\.diff-tag:hover\s*\{[^}]*rgba\(255,\s*255,\s*255/);

    // viewer.css の .prompt-tag:hover で var(--accent-hover-tint) が使用されていること
    expect(viewerContent).toMatch(/\.prompt-tag:hover\s*\{[^}]*background-color:\s*var\(--accent-hover-tint\);/);

    // renderer.js の globalTagStyle で var(--accent-hover-tint) が使用され、ハードコードの白透過がないこと
    expect(rendererJsContent).toContain('background-color: var(--accent-hover-tint) !important;');
    expect(rendererJsContent).not.toContain('background-color: rgba(255, 255, 255, 0.1) !important;');
  });
});

