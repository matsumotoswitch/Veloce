// ============================================================================
// Veloce - UI Management & Virtual Scrolling System (renderer-ui.js)
// ============================================================================
// 本モジュールは、仮想スクロール（グリッドビューおよびリストビュー）、
// DOM要素のプーリング、選択状態・トースト表示・ダイアログ構築などのUI全般を管轄する。
//
// コア最適化アーキテクチャ:
// 1. 仮想スクロール (Virtual Scroll):
//    可視領域（+バッファ）のみDOMを描画し、数十万件の画像でも低メモリ・高レスポンスを維持。
// 2. DOM要素の再利用 (DOM Pool):
//    要素の都度生成・破棄によるガベージコレクション(GC)を防止するため、
//    既存のDOM要素を display: 'none' でプールし再利用。
// 3. 排他ロック制御 (_runWithUpdateLock):
//    高速スクロール時の非同期レンダリング競合を防ぎ、最新スクロール位置で確実に確定。
// 4. Chromium 109 / WebView2 最適化:
//    DOM置換直後のスタイル不整合を防ぐ同期Reflowや、O(1)のプロパティ直接代入を徹底。
// ============================================================================

import { appState, dndState } from './renderer-state.js';
import { applyGlowEffect as glowElement, getStreamUrl, escapeHtml, isAudioFile, getAudioCoverUrl, AUDIO_PLACEHOLDER_URL, isLocalMediaServerUrl } from '../common/utils.js';
import { validateFilename, INVALID_FILENAME_RE } from '../common/path-utils.js';
import { showAppDialog } from '../common/dialog-base.js';
import { extractMetadataFields, parsePromptTags, formatRequestType } from '../common/metadata-format.js';
import { showDiffModal } from './renderer-diff.js';
import { ICON_SVGS, COLORS, ICON_DESCRIPTIONS, createFavoriteEditorUI } from './favorite-icons.js';

const CHUNK_SIZE = 100;

// 破損MP4動画用のフォールバックSVGを事前にBase64化し、onerrorでの都度エンコードとGC発生を排除
export const BROKEN_MP4_FALLBACK_URL = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4IiBmaWxsPSJub25lIiBzdHJva2U9IiM0NDQiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxyZWN0IHg9IjMiIHk9IjMiIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgcng9IjIiIHJ5PSIyIj48L3JlY3Q+PGNpcmNsZSBjeD0iOC41IiBjeT0iOC41IiByPSIxLjUiPjwvY2lyY2xlPjxwb2x5bGluZSBwb2ludHM9IjIxIDE1IDE2IDEwIDUgMjEiPjwvcG9seWxpbmU+PC9zdmc+';

export { AUDIO_PLACEHOLDER_URL };

let dragCache = { element: null, midX: 0 };

/**
 * 最大公約数を返す（リストビューのアスペクト比計算用）
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
function gcd(a, b) { return b === 0 ? a : gcd(b, a % b); }

export function getRatingForPath(path) {
  if (!path || !appState || !appState.ratings) return 0;
  const direct = appState.ratings[path];
  if (direct !== undefined) return direct;
  // Windows/UNCのスラッシュ・バックスラッシュ表記の差異を安全に吸収
  if (path.indexOf('/') !== -1) {
    const back = path.replace(/\//g, '\\');
    if (appState.ratings[back] !== undefined) return appState.ratings[back];
  } else if (path.indexOf('\\') !== -1) {
    const fwd = path.replace(/\\/g, '/');
    if (appState.ratings[fwd] !== undefined) return appState.ratings[fwd];
  }
  return 0;
}

export function formatSize(bytes) {
  if (bytes === undefined || bytes === null) return '-';
  return bytes.toLocaleString();
}

export function formatBytesHuman(bytes) {
  if (bytes === undefined || bytes === null || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}

export function formatDate(timestamp) {
  if (!timestamp) return '-';
  // Rust側のUnixタイムスタンプ(秒)とJSのミリ秒の違いを吸収
  const ms = timestamp < 1000000000000 ? timestamp * 1000 : timestamp;
  const d = new Date(ms);
  const yyyy = d.getFullYear();
  const MM = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${yyyy}/${MM}/${dd} ${hh}:${mm}:${ss}`;
}

/**
 * メイン画面のUIとDOM操作を管理するクラス
 */
class UIManager {
  static ICONS = {
    DRIVE: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="12" x2="2" y2="12"></line><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path><line x1="6" y1="16" x2="6.01" y2="16"></line><line x1="10" y1="16" x2="10.01" y2="16"></line></svg>`,
    FOLDER: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="none" fill="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`,
    FOLDER_OPEN: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"/></svg>`,
    FLAME: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4"/></svg>`,
    CHEVRON_LEFT: `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6" fill="none"/></svg>`,
    CHEVRON_RIGHT: `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6" fill="none"/></svg>`,
    DATABASE_ZAP: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M3 5V19A9 3 0 0 0 15 21.84"></path><path d="M21 5V8.5"></path><path d="M21 12L18 17H22L19 22"></path></svg>`,
    CHEVRON_UP: `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6" fill="none"/></svg>`,
    CHEVRON_DOWN: `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6" fill="none"/></svg>`,
    SORT_ASC: `<svg class="sort-arrow-inline" viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6" fill="none"/></svg>`,
    SORT_DESC: `<svg class="sort-arrow-inline" viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6" fill="none"/></svg>`,
    SORT_ARROW: `<svg class="sort-arrow sort-arrow-inline" viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6" fill="none"/></svg>`,
    ERASER: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21"></path><path d="M22 21H7"></path><path d="m5 11 9 9"></path></svg>`,
    COPY: `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`,
    CLIPBOARD: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clipboard"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/></svg>`,
    FOLDER_PLUS: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path><line x1="12" y1="10" x2="12" y2="16"></line><line x1="9" y1="13" x2="15" y2="13"></line></svg>`,
    EDIT: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>`,
    TRASH: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>`,
    FILE_PLUS: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>`,
    FOLDER_PEN: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M2 11.5V5a2 2 0 0 1 2-2h3.9c.7 0 1.3.3 1.7.9l.8 1.2c.4.6 1 .9 1.7.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-9.5"/><path d="M11.378 13.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/></svg>`,
    FOLDER_X: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/><path d="m9.5 10.5 5 5"/><path d="m14.5 10.5-5 5"/></svg>`,
    FILE_PEN: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M12.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v9.34"/><path d="M14 2v5a1 1 0 0 0 1 1h5"/><path d="M10.378 12.622a1 1 0 0 1 3 3.003L8.36 20.637a2 2 0 0 1-.854.506l-2.867.837a.5.5 0 0 1-.62-.62l.836-2.869a2 2 0 0 1 .506-.853z"/></svg>`,
    FILE_X: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"/><path d="M14 2v5a1 1 0 0 0 1 1h5"/><path d="m14.5 12.5-5 5"/><path d="m9.5 12.5 5 5"/></svg>`,
    X: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,
    X_CIRCLE: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x-circle"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>`,
    ARROW_RIGHT_TO_LINE: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right-to-line"><path d="M17 12H3"/><path d="m11 18 6-6-6-6"/><path d="M21 5v14"/></svg>`,
    STAR: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,
    SORT: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="15" y1="18" x2="9" y2="18"></line><line x1="18" y1="11" x2="6" y2="11"></line><line x1="21" y1="4" x2="3" y2="4"></line></svg>`,
    FAV_STAR: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,
    FAV_HEART: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>`,
    FAV_CROWN: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/></svg>`,
    FAV_GEM: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 3 8 9l4 13 4-13-2.5-6"/><path d="M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z"/><path d="M2 9h20"/></svg>`,
    FAV_LAYERS: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/></svg>`,
    FAV_SUN: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>`,
    FAV_MOON: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"/></svg>`,
    FAV_FLOWER: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 16.5A4.5 4.5 0 1 1 7.5 12 4.5 4.5 0 1 1 12 7.5a4.5 4.5 0 1 1 4.5 4.5 4.5 4.5 0 1 1-4.5 4.5"/><path d="M12 7.5V9"/><path d="M7.5 12H9"/><path d="M16.5 12H15"/><path d="M12 16.5V15"/><path d="m8 8 1.88 1.88"/><path d="M14.12 9.88 16 8"/><path d="m8 16 1.88-1.88"/><path d="M14.12 14.12 16 16"/></svg>`,
    FAV_SWORDS: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/><line x1="13" x2="19" y1="19" y2="13"/><line x1="16" x2="20" y1="16" y2="20"/><line x1="19" x2="21" y1="21" y2="19"/><polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5"/><line x1="5" x2="9" y1="14" y2="18"/><line x1="7" x2="4" y1="17" y2="20"/><line x1="3" x2="5" y1="19" y2="21"/></svg>`,
    FAV_SHIELD_HALF: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="M12 22V2"/></svg>`,
    FAV_CROSSHAIR: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="22" x2="18" y1="12" y2="12"/><line x1="6" x2="2" y1="12" y2="12"/><line x1="12" x2="12" y1="6" y2="2"/><line x1="12" x2="12" y1="22" y2="18"/></svg>`,
    FAV_WAND_SPARKLES: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72"/><path d="m14 7 3 3"/><path d="M5 6v4"/><path d="M19 14v4"/><path d="M10 2v2"/><path d="M7 8H3"/><path d="M21 16h-4"/><path d="M11 3H9"/></svg>`,
    FAV_BOT: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>`,
    FAV_PAW_PRINT: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="4" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="20" cy="16" r="2"/><path d="M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z"/></svg>`,
    FAV_GHOST: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 10h.01"/><path d="M15 10h.01"/><path d="M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z"/></svg>`,
    FAV_SKULL: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12.5 17-.5-1-.5 1h1z"/><path d="M15 22a1 1 0 0 0 1-1v-1a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20v1a1 1 0 0 0 1 1z"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="12" r="1"/></svg>`,
    FAV_BOOK_HEART: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/><path d="M8.62 9.8A2.25 2.25 0 1 1 12 6.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z"/></svg>`,
    FAV_BEER: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 11h1a3 3 0 0 1 0 6h-1"/><path d="M9 12v6"/><path d="M13 12v6"/><path d="M14 7.5c-1 0-1.44.5-3 .5s-2-.5-3-.5-1.72.5-2.5.5a2.5 2.5 0 0 1 0-5c.78 0 1.57.5 2.5.5S9.44 2 11 2s2 1.5 3 1.5 1.72-.5 2.5-.5a2.5 2.5 0 0 1 0 5c-.78 0-1.5-.5-2.5-.5Z"/><path d="M5 8v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8"/></svg>`,
    FAV_UTENSILS: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/></svg>`,
    FAV_COFFEE: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 2v2"/><path d="M14 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/><path d="M6 2v2"/></svg>`,
    FAV_MIC_VOCAL: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m11 7.601-5.994 8.19a1 1 0 0 0 .1 1.298l.817.818a1 1 0 0 0 1.314.087L15.09 12"/><path d="M16.5 21.174C15.5 20.5 14.372 20 13 20c-2.058 0-3.928 2.356-6 2-2.072-.356-2.775-3.369-1.5-4.5"/><circle cx="16" cy="7" r="5"/></svg>`,
    FAV_MUSIC: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`,
    FAV_ANCHOR: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6v16"/><path d="m19 13 2-1a9 9 0 0 1-18 0l2 1"/><path d="M9 11h6"/><circle cx="12" cy="4" r="2"/></svg>`,
    FAV_CHESS_KNIGHT: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z"/><path d="M16.5 18c1-2 2.5-5 2.5-9a7 7 0 0 0-7-7H6.635a1 1 0 0 0-.768 1.64L7 5l-2.32 5.802a2 2 0 0 0 .95 2.526l2.87 1.456"/><path d="m15 5 1.425-1.425"/><path d="m17 8 1.53-1.53"/><path d="M9.713 12.185 7 18"/></svg>`,
    CHECK: `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
    WINDOW_MINIMIZE: `<svg viewBox="0 0 10 1" width="10" height="1"><rect width="10" height="1" fill="currentColor"/></svg>`,
    WINDOW_MAXIMIZE: `<svg viewBox="0 0 10 10" width="10" height="10"><rect width="10" height="10" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
    WINDOW_RESTORE: `<svg viewBox="0 0 10 10" width="10" height="10"><rect x="1" y="3" width="6" height="6" fill="none" stroke="currentColor" stroke-width="1"/><polyline points="3,3 3,1 9,1 9,7 7,7" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
    WINDOW_CLOSE: `<svg viewBox="0 0 10 10" width="10" height="10"><path d="M0,0 L10,10 M10,0 L0,10" stroke="currentColor" stroke-width="1"/></svg>`,
    RELOAD: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-refresh-cw"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>`,
    REFRESH: `<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-refresh-ccw"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 21v-5h5"/></svg>`,
    DIFF: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-columns-2"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M12 3v18"/></svg>`
  };

  /**
   * コピーボタンのHTMLを生成します。
   * @param {string} text コピー対象のテキスト
   * @returns {string} ボタンのHTML
   */
  static createCopyButtonHTML(text) {
    if (!text || text === '-') return '';
    const escaped = String(text).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `<span class="diff-copy-btn" data-copy-text="${escaped}">
        ${UIManager.ICONS.COPY}
      </span>`;
  }

  /**
   * @param {AppState} state - アプリケーション状態のインスタンス
   */
  constructor(state) {
    this.state = state;
    // 頻繁に操作するDOM要素はここで取得しておく
    /**
     * @type {{
     *   fileListBody: HTMLElement,
     *   thumbnailGrid: HTMLElement,
     *   dirTree: HTMLElement,
     *   thumbnailSizeSlider: HTMLInputElement,
     *   resizerLeft: HTMLElement,
     *   resizerRight: HTMLElement,
     *   resizerCenter: HTMLElement,
     *   searchBar: HTMLInputElement,
     *   searchClearBtn: HTMLElement,
     *   openCacheBtn: HTMLElement,
     *   clearCacheBtn: HTMLElement
     * }}
     */
    this.elements = {
      fileListBody: document.getElementById('file-list-body'),
      thumbnailGrid: document.getElementById('center-bottom'),
      dirTree: document.getElementById('dir-tree'),
      thumbnailSizeSlider: document.getElementById('thumbnail-size-slider'),
      resizerLeft: document.getElementById('resizer-left'),
      resizerRight: document.getElementById('resizer-right'),
      resizerCenter: document.getElementById('resizer-center'),
      searchBar: document.getElementById('search-bar'),
      searchClearBtn: document.getElementById('search-clear-btn'),
      openCacheBtn: document.getElementById('open-cache-btn'),
      clearCacheBtn: document.getElementById('clear-cache-btn'),
      auditCacheBtn: document.getElementById('audit-cache-btn')
    };
    this.toastContainer = document.getElementById('toast-container');
    // カスタムツールチップの初期化
    this.initCustomTooltip();

    // スクロール時にツールチップを強制的に隠す
    window.addEventListener('scroll', () => this.hideCustomTooltip(), true);

    // マウスホイールのスクロール量を制御
    this.initWheelControl();

    // スクロール方向の追跡（Phase 2: UX-2）
    this._lastScrollTop = 0;
    this.scrollDirection = 'down';
    this._lastListScrollTop = 0;
    this.listScrollDirection = 'down';

    // 仮想スクロール用スライディングウィンドウ・キャッシュ（スクロール毎の非同期IPC呼び出しを排除）
    this._itemWindowCache = { start: -1, items: [], totalCount: 0 };
    this._lastInitialChunkRef = null;
  }

  initWheelControl() {
    const container = this.elements.thumbnailGrid;
    if (!container) return;

    let targetScroll = container.scrollTop;
    let isAnimating = false;
    
    // 連続したホイール操作を1回のスムーズなアニメーションに統合（アキュムレート）する
    const calcScrollDelta = (deltaY, deltaMode, clientHeight) => {
      if (deltaMode === 1) {
        return deltaY * 24; // LINE
      } else if (deltaMode === 2) {
        return deltaY * clientHeight; // PAGE
      } else {
        return deltaY * 1.5; // PIXEL (WHEEL_SCALE_FACTOR)
      }
    };

    container.addEventListener('wheel', (e) => {
      // 横スクロールはネイティブに任せる
      if (e.deltaX !== 0) return;
      // 修飾キーが押されている場合（ズーム等）も除外
      if (e.ctrlKey || e.metaKey) return;

      e.preventDefault();

      const delta = calcScrollDelta(e.deltaY, e.deltaMode, container.clientHeight);

      if (!isAnimating) {
        targetScroll = container.scrollTop;
      }
      
      targetScroll += delta;
      
      const maxScroll = container.scrollHeight - container.clientHeight;
      targetScroll = Math.max(0, Math.min(maxScroll, targetScroll));

      if (!isAnimating) {
        isAnimating = true;
        let expectedScrollTop = container.scrollTop;

        const animate = () => {
          // 外部要因（キーボード移動等）でscrollTopが大きく変更された場合はアニメーションを中断
          if (Math.abs(container.scrollTop - expectedScrollTop) > 20) {
            isAnimating = false;
            return;
          }

          const diff = targetScroll - container.scrollTop;
          
          if (Math.abs(diff) < 1.5) {
            container.scrollTop = targetScroll;
            isAnimating = false;
            return;
          }
          
          const step = diff * 0.45; // 減衰係数（高めにしてキビキビ動かす）
          // 無限ループ防止のため、最低でも1pxは動かす
          const actualStep = Math.abs(step) < 1 ? Math.sign(step) : step;
          container.scrollTop += actualStep;
          expectedScrollTop = container.scrollTop;

          requestAnimationFrame(animate);
        };
        // ホイール入力から描画までの遅延（1フレーム分のラグ）をなくすため、即座に1回目を実行
        animate();
      }
    }, { passive: false });
  }

  /**
   * 仮想スクロール描画の排他ロック制御機構
   * 連続スクロール時に非同期レンダリング処理が並行して二重実行されるのを防ぎ、
   * 実行中に生じた最新の更新要求を保留（Pending）して完了後に次フレーム（rAF）で再実行する
   * @param {string} lockKey - ロックの識別子 ('list' や 'grid' など)
   * @param {() => Promise<void>} taskFn - 排他実行する非同期描画関数
   */
  async _runWithUpdateLock(lockKey, taskFn) {
    const updatingKey = `_${lockKey}Updating`;
    const pendingKey = `_${lockKey}UpdatePending`;

    // 既にレンダリング処理が進行中の場合は、最新状態の再描画フラグを立ててスキップ
    if (this[updatingKey]) {
      this[pendingKey] = true;
      return;
    }

    this[updatingKey] = true;
    try {
      await taskFn();
    } finally {
      this[updatingKey] = false;
      // 処理中にスクロール位置がさらに進んでいた場合は、次フレームで最新位置の描画を実行
      if (this[pendingKey]) {
        this[pendingKey] = false;
        requestAnimationFrame(() => this._runWithUpdateLock(lockKey, taskFn));
      }
    }
  }

  // タブのスクロール状態をチェックし、左右端のグラデーションフェードの表示/非表示を切り替える
  updateTabScrollState() {
    const container = document.getElementById('tab-container');
    if (!container) return;

    const scrollLeft = container.scrollLeft;
    const maxScroll = container.scrollWidth - container.clientWidth;
    const scrollRight = maxScroll - scrollLeft;
    const hasOverflow = container.scrollWidth > container.clientWidth + 1;

    const hasLeft = hasOverflow && scrollLeft > 2;
    const hasRight = hasOverflow && scrollRight > 2;

    container.classList.toggle('has-overflow-left', hasLeft);
    container.classList.toggle('has-overflow-right', hasRight);

    const newTabBtn = document.getElementById('new-tab-btn');
    if (newTabBtn) {
      newTabBtn.classList.toggle('is-overflowing', hasRight);
    }
  }

  /**
   * 指定したタブ（または現在のアクティブタブ）をタブコンテナの表示範囲内にスクロール表示します。
   * ネイティブの scrollIntoView() による祖先要素の不要なスクロール暴走を防ぐため、
   * #tab-container の scrollLeft のみを直接計算して操作します。
   * @param {HTMLElement} [targetTabEl=null] - スクロール対象のタブ要素（省略時はアクティブタブ）
   */
  scrollTabIntoView(targetTabEl = null) {
    const container = document.getElementById('tab-container');
    if (!container) return;

    const tabEl = targetTabEl || container.querySelector('.tab-item.active');
    if (!tabEl) return;

    const tabRect = tabEl.getBoundingClientRect();
    const contRect = container.getBoundingClientRect();
    if (contRect.width === 0) return;

    const padding = 8;
    if (tabRect.left < contRect.left + padding) {
      container.scrollLeft = Math.max(0, container.scrollLeft - (contRect.left + padding - tabRect.left));
    } else if (tabRect.right > contRect.right - padding) {
      container.scrollLeft = container.scrollLeft + (tabRect.right - (contRect.right - padding));
    }

    this.updateTabScrollState();
  }

  renderTabs() {
    const container = document.getElementById('tab-container');
    if (!container) return;

    if (!this.state.tabs || this.state.tabs.length === 0) return;
    const newTabBtn = document.getElementById('new-tab-btn');

    // 「＋」ボタンへのドラッグ＆ドロップ対応（一番後ろへ移動）
    if (newTabBtn && !newTabBtn.dataset.dragInitialized) {
      newTabBtn.dataset.dragInitialized = 'true';
      newTabBtn.addEventListener('dragover', (e) => {
        if (!Array.from(e.dataTransfer.types).includes('application/json-tab')) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        const container = document.getElementById('tab-container');
        if (container) {
          container.querySelectorAll('.tab-item').forEach(item => {
            if (item !== newTabBtn) {
              item.classList.remove('drag-over-left', 'drag-over-right');
              item.style.zIndex = '';
            }
          });
        }
        newTabBtn.classList.add('drag-over-left');
      });
      newTabBtn.addEventListener('dragleave', (e) => {
        if (!Array.from(e.dataTransfer.types).includes('application/json-tab')) return;
        newTabBtn.classList.remove('drag-over-left');
      });
      newTabBtn.addEventListener('drop', (e) => {
        if (!Array.from(e.dataTransfer.types).includes('application/json-tab')) return;
        e.preventDefault();
        newTabBtn.classList.remove('drag-over-left');
        const fromIndexStr = e.dataTransfer.getData('application/json-tab');
        if (fromIndexStr && window.onTabMove) window.onTabMove(parseInt(fromIndexStr, 10), this.state.tabs.length - 1, true);
      });
    }

    // DOMの再生成を防ぎ、タブIDを元に既存のタブ要素を正確にマップ・再利用する
    this.state.tabs.forEach((tab, idx) => {
      if (!tab.id) tab.id = 'tab_' + idx + '_' + Date.now();
    });

    const activeTabIds = new Set(this.state.tabs.map(t => String(t.id)));

    const existingTabMap = new Map();
    container.querySelectorAll('.tab-item:not(#new-tab-btn)').forEach(el => {
      if (el.dataset.tabId) {
        existingTabMap.set(el.dataset.tabId, el);
      }
    });

    existingTabMap.forEach((el, id) => {
      if (!activeTabIds.has(id) && !el.classList.contains('tab-fade-out') && !el.classList.contains('tab-dent')) {
        el.remove();
      }
    });

    this.state.tabs.forEach((tab, index) => {
      let tabEl = existingTabMap.get(String(tab.id));

      if (!tabEl) {
        tabEl = document.createElement('div');
        tabEl.className = 'tab-item';
        tabEl.draggable = true;

        const iconSpan = document.createElement('span');
        iconSpan.className = 'tab-icon';
        tabEl.appendChild(iconSpan);

        const label = document.createElement('span');
        label.className = 'tab-label';
        tabEl.appendChild(label);
        
        this.bindTooltip(tabEl, () => {
          const currentTab = this.state.tabs[parseInt(tabEl.dataset.index, 10)];
          return currentTab ? `${currentTab.name}\n${currentTab.path}` : '';
        });

        const closeBtn = document.createElement('span');
        closeBtn.className = 'tab-close-btn';
        closeBtn.innerHTML = `<svg viewBox="0 0 10 10" width="8" height="8"><path d="M1,1 L9,9 M9,1 L1,9" stroke="currentColor" stroke-width="1.5"/></svg>`;
        this.bindTooltip(closeBtn, 'タブを閉じる', { stopPropagation: true });
        closeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (window.onTabClose) window.onTabClose(parseInt(tabEl.dataset.index, 10));
        });
        tabEl.appendChild(closeBtn);

        tabEl.addEventListener('click', () => {
          if (window.onTabClick) window.onTabClick(parseInt(tabEl.dataset.index, 10));
        });
        
        tabEl.addEventListener('mousedown', (e) => { if (e.button === 1) e.preventDefault(); });
        
        tabEl.addEventListener('auxclick', (e) => {
          if (e.button === 1) { 
            e.stopPropagation();
            if (window.onTabClose) window.onTabClose(parseInt(tabEl.dataset.index, 10));
          }
        });

        tabEl.addEventListener('contextmenu', (e) => {
          if (window.onTabContextMenu) window.onTabContextMenu(e, parseInt(tabEl.dataset.index, 10));
        });

        tabEl.addEventListener('dragstart', (e) => {
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('application/json-tab', tabEl.dataset.index);
          setTimeout(() => { tabEl.classList.add('is-dragging'); }, 0); 
        });
        tabEl.addEventListener('dragend', (e) => {
          tabEl.classList.remove('is-dragging');
          const container = document.getElementById('tab-container');
          if (container) {
            container.querySelectorAll('.tab-item').forEach(item => item.classList.remove('drag-over-left', 'drag-over-right'));
          }
        });
        tabEl.addEventListener('dragover', (e) => {
          if (!Array.from(e.dataTransfer.types).includes('application/json-tab')) return;
          e.preventDefault();
          e.dataTransfer.dropEffect = 'move';
          
          if (dragCache.element !== tabEl) {
            const container = document.getElementById('tab-container');
            if (container) {
              container.querySelectorAll('.tab-item').forEach(item => {
                if (item !== tabEl) {
                  item.classList.remove('drag-over-left', 'drag-over-right');
                  item.style.zIndex = '';
                }
              });
            }
            const rect = tabEl.getBoundingClientRect();
            dragCache.element = tabEl;
            dragCache.midX = rect.left + rect.width / 2;
          }

          if (e.clientX < dragCache.midX) {
            tabEl.classList.add('drag-over-left');
            tabEl.classList.remove('drag-over-right');
          } else {
            tabEl.classList.add('drag-over-right');
            tabEl.classList.remove('drag-over-left');
          }
          tabEl.style.zIndex = '3'; // ドロップインジケーターが他のタブやボタンに隠れないように最前面へ
        });
        tabEl.addEventListener('dragleave', (e) => {
          if (!Array.from(e.dataTransfer.types).includes('application/json-tab')) return;
          tabEl.classList.remove('drag-over-left', 'drag-over-right');
          tabEl.style.zIndex = '';
        });
        tabEl.addEventListener('drop', (e) => {
          if (!Array.from(e.dataTransfer.types).includes('application/json-tab')) return;
          e.preventDefault();
          tabEl.classList.remove('drag-over-left', 'drag-over-right');
          tabEl.style.zIndex = '';
          const fromIndexStr = e.dataTransfer.getData('application/json-tab');
          if (!fromIndexStr) return;
          const rect = tabEl.getBoundingClientRect();
          const midX = rect.left + rect.width / 2;
          if (window.onTabMove) window.onTabMove(parseInt(fromIndexStr, 10), parseInt(tabEl.dataset.index, 10), e.clientX >= midX);
        });

        if (newTabBtn && newTabBtn.parentNode === container) {
          container.insertBefore(tabEl, newTabBtn);
        } else {
          container.appendChild(tabEl);
        }
      } else {
        // Ensure the existing element is moved to the correct visual order
        if (newTabBtn && newTabBtn.parentNode === container) {
          container.insertBefore(tabEl, newTabBtn);
        } else {
          container.appendChild(tabEl);
        }
      }

      // --- 状態の更新 ---
      if (tab.isNew) {
        tabEl.classList.remove('tab-fade-in');
        void tabEl.offsetWidth; // リフローを強制してアニメーションを再トリガー
        tabEl.classList.add('tab-fade-in');
        tab.isNew = false;
        
        // アニメーション完了後にクラスを削除し、DOM移動時の意図しない再再生を防ぐ
        const onAnimationEnd = (e) => {
          if (e.animationName === 'tabFadeIn') {
            tabEl.classList.remove('tab-fade-in');
            tabEl.removeEventListener('animationend', onAnimationEnd);
          }
        };
        tabEl.addEventListener('animationend', onAnimationEnd);
      } else {
        tabEl.classList.remove('tab-fade-in');
      }

      // 再利用されたDOMに削除アニメーションのクラスやインラインスタイルが残っていればリセット
      tabEl.classList.remove('tab-fade-out', 'tab-dent');
      tabEl.style.width = '';
      tabEl.style.minWidth = '';
      tabEl.style.maxWidth = '';
      tabEl.style.paddingLeft = '';
      tabEl.style.paddingRight = '';
      tabEl.style.marginLeft = '';
      tabEl.style.marginRight = '';
      tabEl.style.borderWidth = '';
      tabEl.style.transition = '';

      tabEl.dataset.index = index;
      tabEl.dataset.tabId = tab.id;

      if (index === this.state.activeTabIndex) {
        tabEl.classList.add('active');
      } else {
        tabEl.classList.remove('active');
      }

      const iconSpan = tabEl.querySelector('.tab-icon');
      if (iconSpan) {
        iconSpan.style.color = ''; // 再利用時のためにリセット
        
        let itemData = null;
        let isSmartFolder = false;
        
        if (this.state.favorites) {
            itemData = this.state.favorites.find(f => f.path === tab.path);
        }
        
        if (!itemData && tab.path && tab.path.startsWith('smart://')) {
            const id = tab.path.replace('smart://', '');
            if (this.state.smartFolders) {
                itemData = this.state.smartFolders.find(f => f.id === id);
                if (itemData) isSmartFolder = true;
            }
        }

        if (itemData) {
          if (itemData.icon && typeof ICON_SVGS !== 'undefined' && ICON_SVGS[itemData.icon]) {
            iconSpan.innerHTML = ICON_SVGS[itemData.icon];
          } else if (itemData.icon && itemData.icon.startsWith('FAV_')) {
            iconSpan.innerHTML = UIManager.ICONS[itemData.icon] || UIManager.ICONS.FAV_STAR;
          } else {
            iconSpan.innerHTML = UIManager.ICONS.FAV_STAR;
          }
          iconSpan.className = `tab-icon icon-color-${itemData.color || 'default'}`;
        } else {
          iconSpan.innerHTML = UIManager.ICONS.FOLDER;
          iconSpan.className = 'tab-icon icon-color-folder';
        }

        if (isSmartFolder) {
          tabEl.classList.add('is-smart-tab');
        } else {
          tabEl.classList.remove('is-smart-tab');
        }
        
        // アイコンのサイズを強制的に14pxに
        const svg = iconSpan.querySelector('svg');
        if (svg) {
          svg.setAttribute('width', '14');
          svg.setAttribute('height', '14');
        }
      }

      const label = tabEl.querySelector('.tab-label');
      if (label && label.textContent !== tab.name) {
        label.textContent = tab.name;
      }
    });

    requestAnimationFrame(() => {
      this.updateTabScrollState();
    });
  }

  initCustomTooltip() {
    this.tooltipEl = document.createElement('div');
    this.tooltipEl.className = 'custom-tooltip';
    document.body.appendChild(this.tooltipEl);
    this.isTooltipVisible = false;
    this.lastMouseX = 0;
    this.lastMouseY = 0;
  }

  showCustomTooltip(text, x, y) {
    const tabMenu = document.getElementById('tab-list-menu');
    // タブ一覧メニューが開いている時はツールチップを出さず、メニューも消さない
    if (tabMenu && tabMenu.classList.contains('show')) {
      return;
    }

    const ctxMenu = document.getElementById('context-menu');
    // コンテキストメニューが開いている時はツールチップを出さず、メニューも消さない
    if (ctxMenu && ctxMenu.classList.contains('show')) {
      return;
    }

    this.isTooltipVisible = true;
    this.lastMouseX = x;
    this.lastMouseY = y;
    if (this.tooltipEl.textContent !== text) {
      this.tooltipEl.textContent = text;
    }

    // 前回の未実行のアニメーションフレームがあればキャンセル（重複実行による負荷を防止）
    if (this.tooltipRafId) {
      cancelAnimationFrame(this.tooltipRafId);
    }

    // DOMにテキストが反映された後にサイズを取得して位置を調整する
    this.tooltipRafId = requestAnimationFrame(() => {
      this.tooltipRafId = null; // 実行時にIDをクリア
      const rect = this.tooltipEl.getBoundingClientRect();
      let posX = x + 15;
      let posY = y + 15;

      // 画面外にはみ出さないよう調整
      if (posX + rect.width > window.innerWidth) posX = window.innerWidth - rect.width - 10;
      if (posY + rect.height > window.innerHeight) posY = window.innerHeight - rect.height - 10;

      this.tooltipEl.style.left = `${posX}px`;
      this.tooltipEl.style.top = `${posY}px`;
      this.tooltipEl.classList.add('show');
    });
  }

  hideCustomTooltip() {
    this.isTooltipVisible = false;
    
    if (this.tooltipRafId) {
      cancelAnimationFrame(this.tooltipRafId);
      this.tooltipRafId = null;
    }

    if (this.tooltipEl) {
      this.tooltipEl.classList.remove('show');
    }
  }

  /**
   * 要素にカスタムツールチップ（mouseenter, mousemove, mouseleave, click）を登録します。
   * 重複するイベントリスナー定義を集約し、ボイラープレートを削減します。
   * @param {HTMLElement} element - 対象要素
   * @param {string | ((e?: MouseEvent) => string)} textOrFn - 表示テキストまたは動的テキスト取得関数
   * @param {Object} [options] - 設定オプション
   * @param {boolean} [options.stopPropagation] - イベント伝播を停止するか
   * @param {() => boolean} [options.isDisabled] - ツールチップ表示を無効化する条件判定関数
   * @param {(e: MouseEvent) => void} [options.onMouseEnter] - mouseenter 時に実行するコールバック
   */
  bindTooltip(element, textOrFn, options = {}) {
    if (!element) return;
    element.removeAttribute('title');

    const resolveText = (e) => {
      return typeof textOrFn === 'function' ? textOrFn(e) : textOrFn;
    };

    element.addEventListener('mouseenter', (e) => {
      if (options.stopPropagation) e.stopPropagation();
      if (options.isDisabled && options.isDisabled()) return;
      if (element.disabled) return;
      if (options.onMouseEnter) options.onMouseEnter(e);
      const text = resolveText(e);
      if (text) this.showCustomTooltip(text, e.clientX, e.clientY);
    });

    element.addEventListener('mousemove', (e) => {
      if (options.stopPropagation) e.stopPropagation();
      if (options.isDisabled && options.isDisabled()) return;
      if (element.disabled) return;
      const text = resolveText(e);
      if (text) this.showCustomTooltip(text, e.clientX, e.clientY);
    });

    element.addEventListener('mouseleave', (e) => {
      if (options.stopPropagation) e.stopPropagation();
      this.hideCustomTooltip();
    });

    element.addEventListener('click', () => {
      this.hideCustomTooltip();
    });
  }

  static bindTooltip(element, textOrFn, options = {}) {
    if (uiManager) {
      uiManager.bindTooltip(element, textOrFn, options);
    }
  }

  /**
   * トースト通知を画面に表示します。
   * @param {string} message - 表示するメッセージ
   * @param {number} [duration=3000] - 表示する時間(ミリ秒)。0の場合は自動で消えません。
   * @param {string|null} [id=null] - トーストの一意なID。既存のトーストを更新する場合に使用。
   * @param {string} [type='info'] - トーストの種類 ('info', 'success', 'warning', 'error')
   */
  showToast(message, duration = 3000, id = null, type = 'info') {
    if (duration !== 0) {
      duration = (type === 'error') ? 5000 : 1000;
    }

    if (!this.toastContainer) {
      let container = document.getElementById('toast-container');
      if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
      }
      this.toastContainer = container;
    }

    const elementId = id ? (id.startsWith('toast-') ? id : `toast-${id}`) : null;
    let toast = elementId ? document.getElementById(elementId) : null;

    if (toast) {
      toast.textContent = message;
      // Reset type classes
      toast.classList.remove('success', 'error', 'warning');
    } else {
      toast = document.createElement('div');
      toast.className = 'toast-message';
      if (elementId) toast.id = elementId;
      toast.textContent = message;
      this.toastContainer.appendChild(toast);
    }

    if (type !== 'info') {
      toast.classList.add(type);
    }

    requestAnimationFrame(() => {
      toast.classList.add('show');
    });

    if (toast.timeoutId) {
      clearTimeout(toast.timeoutId);
    }

    if (duration > 0) {
      toast.timeoutId = setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
          if (toast.parentElement) toast.remove();
        }, 300);
      }, duration);
    }
  }

  /**
   * トースト通知を画面に表示する静的ヘルパー。
   * @param {string} message - 表示するメッセージ
   * @param {number} [duration=3000] - 表示する時間(ミリ秒)
   * @param {string|null} [id=null] - トーストの一意なID
   * @param {string} [type='info'] - トーストの種類 ('info', 'success', 'warning', 'error')
   */
  static showToast(message, duration = 3000, id = null, type = 'info') {
    if (typeof uiManager !== 'undefined' && uiManager) {
      uiManager.showToast(message, duration, id, type);
    }
  }

  /**
   * 指定したIDのトースト通知を消去します。
   * フェードアウトアニメーション（300ms）完了後にDOMから要素を削除します。
   * @param {string} id - トーストの一意なID（接頭辞 'toast-' の有無を問わず指定可能）
   */
  dismissToast(id) {
    if (!id) return;
    const elementId = id.startsWith('toast-') ? id : `toast-${id}`;
    const toast = document.getElementById(elementId);
    if (toast) {
      if (toast.timeoutId) {
        clearTimeout(toast.timeoutId);
        toast.timeoutId = null;
      }
      toast.classList.remove('show');
      setTimeout(() => {
        if (toast.parentElement) {
          toast.remove();
        }
      }, 300);
    }
  }

  /**
   * 指定したIDのトースト通知を消去する静的ヘルパー。
   * @param {string} id - トーストの一意なID（接頭辞 'toast-' の有無を問わず指定可能）
   */
  static dismissToast(id) {
    if (typeof uiManager !== 'undefined' && uiManager) {
      uiManager.dismissToast(id);
    } else {
      if (!id) return;
      const elementId = id.startsWith('toast-') ? id : `toast-${id}`;
      const toast = document.getElementById(elementId);
      if (toast) {
        if (toast.timeoutId) {
          clearTimeout(toast.timeoutId);
          toast.timeoutId = null;
        }
        toast.classList.remove('show');
        setTimeout(() => {
          if (toast.parentElement) {
            toast.remove();
          }
        }, 300);
      }
    }
  }

  /**
   * カスタムプロンプトダイアログを表示します。
   * @param {string} message 
   * @param {string} defaultValue 
   * @param {boolean} selectBaseNameOnly 
   * @returns {Promise<string|null>}
   */
  showPrompt(message, defaultValue = '', selectBaseNameOnly = false) {
    return new Promise((resolve) => {
      // ファイルリネーム時の拡張子保護用
      const originalExt = (selectBaseNameOnly && defaultValue.lastIndexOf('.') > 0)
        ? defaultValue.slice(defaultValue.lastIndexOf('.'))
        : '';

      const overlay = document.createElement('div');
      overlay.className = 'dialog-overlay';

      const dialog = document.createElement('div');
      dialog.className = 'dialog-box';

      const messageEl = document.createElement('div');
      messageEl.className = 'dialog-message has-input';
      messageEl.textContent = message;

      const inputEl = document.createElement('input');
      inputEl.type = 'text';
      inputEl.className = 'dialog-input';
      inputEl.value = defaultValue;
      inputEl.spellcheck = false;

      const warningEl = document.createElement('div');
      warningEl.className = 'dialog-warning';

      const inputContainer = document.createElement('div');
      inputContainer.className = 'dialog-input-group';
      inputContainer.appendChild(inputEl);
      inputContainer.appendChild(warningEl);

      const buttonsDiv = document.createElement('div');
      buttonsDiv.className = 'dialog-buttons';

      const cancelBtn = document.createElement('button');
      cancelBtn.className = 'dialog-btn cancel';
      cancelBtn.textContent = 'キャンセル';

      const okBtn = document.createElement('button');
      okBtn.className = 'dialog-btn primary';
      okBtn.textContent = 'OK';

      buttonsDiv.appendChild(okBtn);
      buttonsDiv.appendChild(cancelBtn);

      dialog.appendChild(messageEl);
      dialog.appendChild(inputContainer);
      dialog.appendChild(buttonsDiv);
      overlay.appendChild(dialog);
      document.body.appendChild(overlay);
      requestAnimationFrame(() => {
        overlay.classList.add('show');
      });

      const keydownHandler = (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          cleanup();
          resolve(null);
        }
      };
      document.addEventListener('keydown', keydownHandler, true);

      const cleanup = () => {
        document.removeEventListener('keydown', keydownHandler, true);
        overlay.classList.remove('show');
        setTimeout(() => {
          if (document.body.contains(overlay)) {
            document.body.removeChild(overlay);
          }
        }, 200);
      };

      const validateInput = () => {
        const value = inputEl.value;
        const result = validateFilename(value);
        if (!result.valid) {
          if (!value || value.trim() === '') {
            warningEl.classList.remove('show');
            inputEl.classList.remove('error');
            okBtn.disabled = true;
          } else {
            warningEl.textContent = result.message;
            warningEl.classList.add('show');
            inputEl.classList.toggle('error', INVALID_FILENAME_RE.test(value));
            okBtn.disabled = true;
          }
        } else {
          warningEl.classList.remove('show');
          inputEl.classList.remove('error');
          okBtn.disabled = false;
        }
      };

      inputEl.addEventListener('input', validateInput);
      validateInput();

      setTimeout(() => {
        inputEl.focus();
        if (selectBaseNameOnly && defaultValue.lastIndexOf('.') > 0) {
          inputEl.setSelectionRange(0, defaultValue.lastIndexOf('.'));
        } else {
          inputEl.select();
        }
      }, 50);

      const finishPrompt = () => {
        if (!okBtn.disabled) {
          cleanup();
          let finalValue = inputEl.value;

          if (selectBaseNameOnly && originalExt) {
            if (!finalValue.toLowerCase().endsWith(originalExt.toLowerCase())) {
              if (finalValue.includes('.')) {
                finalValue = finalValue.slice(0, finalValue.lastIndexOf('.')) + originalExt;
              } else {
                finalValue += originalExt;
              }
            }
          }

          resolve(finalValue);
        }
      };

      okBtn.addEventListener('click', finishPrompt);

      cancelBtn.addEventListener('click', () => {
        cleanup();
        resolve(null);
      });



      inputEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          finishPrompt();
        }
      });
    });
  }

  /**
   * 同名ファイルの競合時の処理を選択するダイアログを表示します。
   * @param {number} conflictCount 
   * @param {string} actionStr 
   * @returns {Promise<'overwrite'|'skip'|'cancel'>}
   */
  showConflictDialog(conflictCount, actionStr) {
    return showAppDialog({
      messageHtml: `宛先に同じ名前のファイルが <strong>${conflictCount}件</strong> 存在します。<br>どのように処理しますか？`,
      buttons: [
        { label: `上書きして${actionStr}`, className: 'dialog-btn danger', value: 'overwrite' },
        { label: '重複をスキップ', className: 'dialog-btn primary', value: 'skip' },
        { label: 'キャンセル', className: 'dialog-btn cancel', value: 'cancel' }
      ],
      buttonsWrap: true,
      escapeValue: 'cancel',
      focusIndex: 1
    });
  }

  /**
   * 存在しないフォルダのタブに切り替えようとした際のダイアログを表示します。
   * @param {string} path
   * @param {boolean} canCloseTab
   * @returns {Promise<'close'|'cancel'|'ok'>}
   */
  showMissingFolderDialog(path, canCloseTab) {
    const folderName = path.split('\\').pop() || path.split('/').pop() || path;
    const pathEl = document.createElement('div');
    pathEl.className = 'dialog-path';
    pathEl.textContent = path;

    const buttons = [];
    if (canCloseTab) {
      buttons.push({ label: 'タブを閉じる', className: 'dialog-btn danger', value: 'close' });
      buttons.push({ label: 'キャンセル', className: 'dialog-btn cancel', value: 'cancel' });
    } else {
      buttons.push({ label: 'OK', className: 'dialog-btn cancel', value: 'ok' });
    }

    return showAppDialog({
      messageHtml: `フォルダ「<strong>${folderName}</strong>」は存在しません。${canCloseTab ? '<br>このタブを閉じますか？' : ''}`,
      extraNodes: [pathEl],
      buttons,
      escapeValue: canCloseTab ? 'cancel' : 'ok',
      focusIndex: 0
    });
  }

  /**
   * カスタム確認ダイアログを表示します。
   * @param {string} message 
   * @returns {Promise<boolean>}
   */
  showConfirm(message) {
    return showAppDialog({
      message,
      buttons: [
        { label: '削除', className: 'dialog-btn danger', value: true },
        { label: 'キャンセル', className: 'dialog-btn cancel', value: false }
      ],
      escapeValue: false,
      focusIndex: 0
    });
  }

  /**
   * アイコンや要素を発光させます。
   * @param {HTMLElement} el 対象の要素
   */
  applyGlowEffect(el) {
    glowElement(el);
  }

  /**
   * リストとサムネイルグリッドの選択状態を表すUIを一括で更新します。
   * 仮想スクロールで実際に描画されているDOM子要素（約30〜60個）を直接走査することで、
   * 数万件の選択（Ctrl+A等）時にも querySelector のDOM走査を一切行わず O(visible nodes) で即座に更新します。
   */
  updateSelectionUI() {
    if (!this.elements.fileListBody) {
      this.elements.fileListBody = document.getElementById('file-list-body');
    }
    if (!this.elements.thumbnailGrid) {
      this.elements.thumbnailGrid = document.getElementById('center-bottom');
    }
    if (!this.elements.fileListBody && !this.elements.thumbnailGrid) return;

    const currentSelection = this.state.selection;

    // 1. ファイルリストの同期 (tbodyの直接の子要素 tr を走査)
    if (this.elements.fileListBody) {
      const rows = this.elements.fileListBody.children;
      for (let k = 0; k < rows.length; k++) {
        const row = rows[k];
        if (row.dataset && row.dataset.index !== undefined) {
          const idx = parseInt(row.dataset.index, 10);
          if (!isNaN(idx)) {
            const isSelected = currentSelection.has(idx);
            if (row.classList.contains('selected') !== isSelected) {
              row.classList.toggle('selected', isSelected);
            }
          }
        }
      }
    }

    // 2. サムネイルグリッドの同期 (.virtual-content または thumbnailGrid の直接の子要素を走査)
    if (this.elements.thumbnailGrid) {
      const gridContent = this.elements.thumbnailGrid.querySelector('.virtual-content') || this.elements.thumbnailGrid;
      const thumbs = gridContent.children;
      for (let k = 0; k < thumbs.length; k++) {
        const thumb = thumbs[k];
        if (thumb.dataset && thumb.dataset.index !== undefined) {
          const idx = parseInt(thumb.dataset.index, 10);
          if (!isNaN(idx)) {
            const isSelected = currentSelection.has(idx);
            if (thumb.classList.contains('selected') !== isSelected) {
              thumb.classList.toggle('selected', isSelected);
            }
          }
        }
      }
    }
  }

  /**
   * パネル（左右ペイン）の表示・非表示や幅を CSS 変数に反映してレイアウトを更新します。
   */
  applyLayout() {
    const root = document.documentElement;
    const lWidth = this.state.layout.leftVisible ? `${this.state.layout.leftWidth}px` : '0px';
    const rWidth = this.state.layout.rightVisible ? `${this.state.layout.rightWidth}px` : '0px';
    
    root.style.setProperty('--left-width', lWidth);
    root.style.setProperty('--right-width', rWidth);

    if (this.state.layout.leftVisible) {
      root.removeAttribute('data-left-collapsed');
    } else {
      root.setAttribute('data-left-collapsed', 'true');
    }

    if (this.state.layout.rightVisible) {
      root.removeAttribute('data-right-collapsed');
    } else {
      root.setAttribute('data-right-collapsed', 'true');
    }

    const lTopHeight = this.state.layout.leftTopVisible ? `${this.state.layout.leftTopHeight}px` : '0px';
    root.style.setProperty('--left-top-height', lTopHeight);
    if (this.state.layout.leftTopVisible) {
      root.removeAttribute('data-left-top-collapsed');
    } else {
      root.setAttribute('data-left-top-collapsed', 'true');
    }

    const rTopHeight = this.state.layout.rightTopVisible ? `${this.state.layout.rightTopHeight}px` : '0px';
    root.style.setProperty('--right-top-height', rTopHeight);
  }

  /**
   * 2つの画像ファイルの全メタデータを比較表示します。
   * 全項目をプロンプトと同じテキストボックス形式で左右に並べて表示します。
   * （実装は renderer-diff.js に委譲）
   */
  showDiffModal(file1, file2, meta1 = {}, meta2 = {}) {
    return showDiffModal(file1, file2, meta1, meta2, this);
  }

  /**
   * 仮想スクロール用のスライディングウィンドウ・キャッシュを無効化する。
   * ソート順変更・フィルタ変更・ファイル追加削除時などに呼び出してバックエンドとの整合性を保証する。
   */
  invalidateItemWindowCache() {
    this._itemWindowCache = { start: -1, items: [], totalCount: 0 };
    this._lastInitialChunkRef = null;
  }

  /**
   * 指定範囲のアイテム配列でスライディングウィンドウ・キャッシュを初期化する。
   * @param {number} start - 開始インデックス
   * @param {Array<Object>} items - キャッシュするアイテム配列
   * @param {number} [totalCount] - 現在の総件数
   */
  seedItemWindowCache(start, items, totalCount) {
    const arr = Array.isArray(items) ? items.slice() : [];
    const total = typeof totalCount === 'number' ? totalCount : (appState ? appState.totalCount : arr.length);
    this._itemWindowCache = {
      start,
      items: arr,
      totalCount: total
    };
  }

  /**
   * スライディングウィンドウ・キャッシュ内に要求範囲が完全に含まれている場合、同期的にスライスを返す。
   * キャッシュミスの場合は null を返し、呼び出し元で _fetchWindowItems にフォールバックさせる。
   * @param {number} startIndex - 取得開始インデックス
   * @param {number} count - 取得件数
   * @returns {Array<Object>|null}
   */
  _getCachedWindowItems(startIndex, count) {
    if (Array.isArray(appState.initialChunk) && appState.initialChunk.length > 0 && this._lastInitialChunkRef !== appState.initialChunk) {
      this._lastInitialChunkRef = appState.initialChunk;
      this.seedItemWindowCache(0, appState.initialChunk, appState.totalCount);
    }

    const cache = this._itemWindowCache;
    if (!cache || cache.start < 0 || cache.items.length === 0 || cache.totalCount !== appState.totalCount) {
      return null;
    }

    if (startIndex < cache.start) {
      return null;
    }

    const relStart = startIndex - cache.start;
    const relEnd = relStart + count;
    const cacheCoversEnd = relEnd <= cache.items.length || (cache.start + cache.items.length >= appState.totalCount && relStart < cache.items.length);
    if (!cacheCoversEnd) {
      return null;
    }

    return cache.items.slice(relStart, relEnd);
  }

  /**
   * バックエンドから要求範囲を含むスライディングウィンドウ（最大400件）を一括取得してキャッシュを更新し、
   * 要求されたスライスを返す。
   * @param {number} startIndex - 取得開始インデックス
   * @param {number} count - 取得件数
   * @returns {Promise<Array<Object>>}
   */
  async _fetchWindowItems(startIndex, count) {
    const WINDOW_SIZE = 400;
    const PRE_BUFFER = 60;
    const fetchStart = startIndex <= PRE_BUFFER ? 0 : startIndex - PRE_BUFFER;
    const total = appState.totalCount > 0 ? appState.totalCount : (startIndex + count);
    const desiredCount = Math.max(count + (startIndex - fetchStart), WINDOW_SIZE);
    const fetchCount = Math.max(count, Math.min(desiredCount, Math.max(count, total - fetchStart)));

    const fetched = await window.veloceAPI.getItems(fetchStart, fetchCount);
    if (!Array.isArray(fetched) || fetched.length === 0) {
      return [];
    }

    this._itemWindowCache = {
      start: fetchStart,
      items: fetched,
      totalCount: appState.totalCount
    };

    const relStart = startIndex - fetchStart;
    if (relStart >= 0 && fetched.length > relStart) {
      return fetched.slice(relStart, relStart + count);
    }
    return fetched.slice(0, count);
  }

  /**
   * ファイルリストとサムネイルグリッドの描画を非同期で行います。
   */
  async renderAll(resetScroll = false) {
    if (!this.elements.fileListBody || !this.elements.thumbnailGrid) {
      this.elements.fileListBody = document.getElementById('file-list-body');
      this.elements.thumbnailGrid = document.getElementById('center-bottom');
    }

    const renderId = ++this.state.currentRenderId;

    // 既存の画像の監視をすべて停止
    if (this.state.thumbnailObserver) {
        this.state.thumbnailObserver.disconnect();
    }

    if (resetScroll) {
      this._lastScrollTop = 0;
      this.scrollDirection = 'down';
      this._lastListScrollTop = 0;
      this.listScrollDirection = 'down';
      if (this.elements.fileListBody) this.elements.fileListBody.replaceChildren();
      
      // フォルダ選択時と同様に、タブ切り替え時等も以前のサムネイル表示を確実にクリアする
      if (this.elements.thumbnailGrid) {
        const content = this.elements.thumbnailGrid.querySelector('.virtual-content');
        if (content) content.replaceChildren();
        const spacer = this.elements.thumbnailGrid.querySelector('.virtual-spacer');
        if (spacer) spacer.style.height = '0px';
      }

      const fileListContainer = document.getElementById('center-top');
      if (fileListContainer) fileListContainer.scrollTop = 0;
      if (this.elements.thumbnailGrid) this.elements.thumbnailGrid.scrollTop = 0;
      if (typeof appState !== 'undefined') {
        appState.savedScrollTopGrid = 0;
        appState.savedScrollTopList = 0;
      }
    }

    if (Array.isArray(appState.initialChunk) && appState.initialChunk.length > 0) {
      this._lastInitialChunkRef = appState.initialChunk;
      this.seedItemWindowCache(0, appState.initialChunk, appState.totalCount);
    } else {
      this.invalidateItemWindowCache();
    }

    if (typeof this.updateVirtualGrid === 'function') {
      this.updateVirtualGrid(true);
    }

    if (typeof this.updateVirtualList === 'function') {
      this.updateVirtualList(true);
    }

    // 初回描画（グリッドとリスト）が両方 initialChunk を参照し終えた後に破棄する
    appState.initialChunk = null;

    // バックグラウンド生成の再スタート
    if (!this.state.isPreloadRunning) {
      this.state.isPreloadRunning = true;
      if (typeof window.processNextTask === 'function') {
        setTimeout(window.processNextTask, 50);
      }
    }
  }

  updateVirtualList(force = false) {
    return this._runWithUpdateLock('list', async () => {
      if (!this.elements.fileListBody) return;
    const container = document.getElementById('center-top');
    if (!container) return;
    const tbody = this.elements.fileListBody;

    if (!this._listScrollAttached && container) {
      let listTicked = false;
      container.addEventListener('scroll', () => {
        if (!listTicked) {
          requestAnimationFrame(() => {
            this.updateVirtualList();
            listTicked = false;
          });
          listTicked = true;
        }
      }, { passive: true });

      this._listResizeObserver = new ResizeObserver(() => {
        if (this._listResizeRaf) cancelAnimationFrame(this._listResizeRaf);
        this._listResizeRaf = requestAnimationFrame(() => this.updateVirtualList(true));
      });
      this._listResizeObserver.observe(container);
      this._listScrollAttached = true;
    }

    if (appState.totalCount === 0) {
      tbody.replaceChildren();
      if (this._listDomByPath) this._listDomByPath.clear();
      if (typeof appState !== 'undefined') {
        if (appState.visiblePathSet instanceof Set) {
          appState.visiblePathSet.clear();
        } else {
          appState.visiblePathSet = new Set();
        }
      }
      this.lastListStartIndex = -1;
      this.lastListEndIndex = -1;
      return;
    }

    // <tr>の概算高さ（CSSのpaddingやborderを含む）
    const rowHeight = 28; 
    const totalRows = appState.totalCount;
    
    const containerHeight = container.clientHeight || window.innerHeight;
    const totalHeight = totalRows * rowHeight;
    const maxScrollTop = Math.max(0, totalHeight - containerHeight);

    let scrollTop = (appState.savedScrollTopList !== undefined && appState.savedScrollTopList !== 0) 
      ? appState.savedScrollTopList 
      : container.scrollTop;

    // スクロール位置がコンテンツの高さを超えている場合は安全にクランプする
    if (scrollTop > maxScrollTop) {
      scrollTop = maxScrollTop;
      container.scrollTop = maxScrollTop;
      if (appState.savedScrollTopList !== undefined && appState.savedScrollTopList !== 0) {
        appState.savedScrollTopList = maxScrollTop;
      }
    }

    // スクロール進行方向に応じた適応型バッファ配分（合計20行を維持）
    if (typeof this._lastListScrollTop === 'number') {
      if (scrollTop < this._lastListScrollTop) {
        this.listScrollDirection = 'up';
      } else if (scrollTop > this._lastListScrollTop) {
        this.listScrollDirection = 'down';
      }
    }
    this._lastListScrollTop = scrollTop;

    const listBufferBefore = this.listScrollDirection === 'up' ? 15 : 5;
    const listBufferAfter = this.listScrollDirection === 'up' ? 5 : 15;

    const maxStartRow = Math.max(0, totalRows - 1);
    const startRow = Math.min(maxStartRow, Math.floor(Math.max(0, scrollTop) / rowHeight));
    const safeStartRow = Math.max(0, startRow - listBufferBefore);
    const endRow = Math.min(totalRows - 1, startRow + Math.ceil(containerHeight / rowHeight) + listBufferAfter);

    if (!force && this.lastListStartIndex === safeStartRow && this.lastListEndIndex === endRow) {
      return;
    }

    if (dndState && dndState.isAppDragging) {
      return;
    }

    this.lastListStartIndex = safeStartRow;
    this.lastListEndIndex = endRow;

    let topSpacer = tbody.querySelector('.list-top-spacer');
    let bottomSpacer = tbody.querySelector('.list-bottom-spacer');

    if (!topSpacer || !bottomSpacer) {
      tbody.innerHTML = `
        <tr class="list-top-spacer list-spacer-row"><td colspan="8" class="list-spacer-cell"></td></tr>
        <tr class="list-bottom-spacer list-spacer-row"><td colspan="8" class="list-spacer-cell"></td></tr>
      `;
      topSpacer = tbody.querySelector('.list-top-spacer');
      bottomSpacer = tbody.querySelector('.list-bottom-spacer');
    }

    const targetCount = endRow - safeStartRow + 1;

    // 足りない要素を追加
    while (tbody.children.length - 2 < targetCount) {
      const tr = document.createElement('tr');
      tr.className = 'list-item-row';
      tr.draggable = true;
      for (let i = 0; i < 8; i++) {
        tr.appendChild(document.createElement('td'));
      }
      tbody.insertBefore(tr, bottomSpacer);
    }

    // 余分な要素を削除
    while (tbody.children.length - 2 > targetCount) {
      const last = tbody.children[tbody.children.length - 2];
      if (last.dataset && last.dataset.filepath && this._listDomByPath && this._listDomByPath.get(last.dataset.filepath) === last) {
        this._listDomByPath.delete(last.dataset.filepath);
      }
      tbody.removeChild(last);
    }

    const topSpacerHeight = safeStartRow * rowHeight;
    const bottomSpacerHeight = (totalRows - 1 - endRow) * rowHeight;

    if (topSpacer._cachedHeight !== topSpacerHeight) {
      topSpacer._cachedHeight = topSpacerHeight;
      topSpacer.style.height = `${topSpacerHeight}px`;
    }
    if (bottomSpacer._cachedHeight !== bottomSpacerHeight) {
      bottomSpacer._cachedHeight = bottomSpacerHeight;
      bottomSpacer.style.height = `${bottomSpacerHeight}px`;
    }

    const neededListCount = endRow - safeStartRow + 1;
    let items = this._getCachedWindowItems(safeStartRow, neededListCount);
    if (!items) {
      items = await this._fetchWindowItems(safeStartRow, neededListCount);
    }

    // 非同期呼び出し完了時に最新スクロール位置との不整合を検知した場合は描画を破棄し、表示の同期整合性を維持する
    if (this.lastListStartIndex !== safeStartRow) {
      return;
    }

    for (let i = safeStartRow; i <= endRow; i++) {
      const file = items[i - safeStartRow];
      if (!file) continue;

      const tr = tbody.children[i - safeStartRow + 1]; // +1 for topSpacer
      
      const isSelected = appState.selection.has(i);
      if (isSelected) tr.classList.add('selected');
      else tr.classList.remove('selected');

      if (tr.dataset.filepath !== file.path || tr.dataset.index != i) {
        if (tr.dataset.filepath && this._listDomByPath && this._listDomByPath.get(tr.dataset.filepath) === tr) {
          this._listDomByPath.delete(tr.dataset.filepath);
        }

        tr.dataset.index = i;
        tr.dataset.filepath = file.path;
        
        if (!this._listDomByPath) this._listDomByPath = new Map();
        this._listDomByPath.set(file.path, tr);
        
        if (tr._cachedRowHeight !== rowHeight) {
          tr._cachedRowHeight = rowHeight;
          tr.style.height = `${rowHeight}px`;
        }

        const tds = tr.children;
        tds[0].textContent = file.name;
        tds[1].textContent = file.ext;
      } else {
        // Just update selection and _listDomByPath registration if path matches but state might have refreshed
        if (!this._listDomByPath) this._listDomByPath = new Map();
        this._listDomByPath.set(file.path, tr);
      }

      // Always check and update dynamic metadata (they may arrive asynchronously)
      const tds = tr.children;
      
      // メタデータ列の同期（生数値キャッシュによる O(1) 判定で毎フレームの文字列化・日付計算・DOM走査を排除）
      if (tds[2]._cachedWidth !== file.width) {
        tds[2]._cachedWidth = file.width;
        const newWidth = file.width ? file.width.toLocaleString() : '-';
        if (tds[2].textContent !== newWidth) tds[2].textContent = newWidth;
      }
      
      if (tds[3]._cachedHeight !== file.height) {
        tds[3]._cachedHeight = file.height;
        const newHeight = file.height ? file.height.toLocaleString() : '-';
        if (tds[3].textContent !== newHeight) tds[3].textContent = newHeight;
      }
      
      if (tds[4]._cachedWidth !== file.width || tds[4]._cachedHeight !== file.height) {
        tds[4]._cachedWidth = file.width;
        tds[4]._cachedHeight = file.height;
        let ratioStr = '-';
        if (file.width && file.height) {
          const d = gcd(file.width, file.height);
          const rw = file.width / d;
          const rh = file.height / d;
          ratioStr = (rw > 100 || rh > 100) ? `${(file.width / file.height).toFixed(2)}:1` : `${rw}:${rh}`;
        }
        if (tds[4].textContent !== ratioStr) tds[4].textContent = ratioStr;
      }

      if (tds[5]._cachedSize !== file.size) {
        tds[5]._cachedSize = file.size;
        const newSize = formatSize(file.size);
        if (tds[5].textContent !== newSize) tds[5].textContent = newSize;
      }
      
      if (tds[6]._cachedMtime !== file.mtime) {
        tds[6]._cachedMtime = file.mtime;
        const newMtime = formatDate(file.mtime);
        if (tds[6].textContent !== newMtime) tds[6].textContent = newMtime;
      }

      // レーティングの同期（_cachedRating による O(1) キャッシュ判定で毎フレームの innerHTML シリアライズを排除）
      const rating = getRatingForPath(file.path);
      if (tds[7]._cachedRating !== rating) {
        tds[7]._cachedRating = rating;
        if (rating > 0) {
          const starSvg = '<svg class="rating-star-icon" viewBox="0 0 24 24" width="14" height="14"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
          tds[7].innerHTML = starSvg + rating;
        } else {
          tds[7].replaceChildren();
          tds[7].textContent = '-';
        }
      }
    }

    // visiblePathSet を _listDomByPath から構築（既存Setを再利用してスクロール毎フレームのGC圧を根絶）
    let visibleSet = (typeof appState !== 'undefined' && appState.visiblePathSet instanceof Set)
      ? appState.visiblePathSet
      : new Set();
    visibleSet.clear();
    if (this._listDomByPath) {
      for (const fp of this._listDomByPath.keys()) {
        visibleSet.add(fp);
      }
    }
    if (typeof appState !== 'undefined') {
      appState.visiblePathSet = visibleSet;
    }

    // スクロール位置を同期復元する場合のみレイアウトを確定させ、ジャンプ時の描画遅延を防止（通常スクロール時の不要Reflowを排除）
    if (appState.savedScrollTopList !== undefined && appState.savedScrollTopList !== 0) {
      void tbody.offsetHeight;
      container.scrollTop = appState.savedScrollTopList;
      appState.savedScrollTopList = 0;
    }
    });
  }

  updateVirtualGrid(force = false) {
    return this._runWithUpdateLock('grid', async () => {
      if (!this.elements.thumbnailGrid) return;
    const container = this.elements.thumbnailGrid;

    // 仮想スクロール用の初期化
    let content = container.querySelector('.virtual-content');
    let spacer = container.querySelector('.virtual-spacer');

    if (!content || !spacer) {
      container.innerHTML = `
        <div class="virtual-spacer"></div>
        <div class="virtual-content"></div>
        <div class="empty-state-container"></div>
      `;
      content = container.querySelector('.virtual-content');
      spacer = container.querySelector('.virtual-spacer');

      container.style.position = 'relative';
      let gridTicked = false;
      container.addEventListener('scroll', () => {
        if (!gridTicked) {
          requestAnimationFrame(() => {
            this.updateVirtualGrid();
            gridTicked = false;
          });
          gridTicked = true;
        }
      }, { passive: true });

      if (typeof ResizeObserver !== 'undefined') {
        this._gridResizeObserver = new ResizeObserver(() => {
          if (this._gridResizeRaf) cancelAnimationFrame(this._gridResizeRaf);
          this._gridResizeRaf = requestAnimationFrame(() => this.updateVirtualGrid(true));
        });
        if (this._gridResizeObserver && typeof this._gridResizeObserver.observe === 'function') {
          this._gridResizeObserver.observe(container);
        }
      }

      container.addEventListener('click', (e) => {
        const clearBtn = e.target.closest('.empty-state-clear-btn');
        if (clearBtn && this.elements.searchClearBtn) {
          this.elements.searchClearBtn.click();
        }
      });
    }

    if (appState.totalCount === 0) {
      content.replaceChildren();
      if (this._domByPath) this._domByPath.clear();
      if (typeof appState !== 'undefined') {
        if (appState.visiblePathSet instanceof Set) {
          appState.visiblePathSet.clear();
        } else {
          appState.visiblePathSet = new Set();
        }
      }
      spacer.style.height = '0px';
      const emptyContainer = container.querySelector('.empty-state-container');
      if (emptyContainer) {
        emptyContainer.style.display = 'flex';
        const isSearchOrFilter = !!(appState.searchQuery || (appState.ratingFilterVal && appState.ratingFilterVal !== 0));
        const targetMode = isSearchOrFilter ? 'search' : 'folder';
        if (emptyContainer.dataset.mode !== targetMode) {
          emptyContainer.dataset.mode = targetMode;
          emptyContainer.innerHTML = targetMode === 'search'
            ? `<svg class="empty-state-icon" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><div class="empty-state-text">検索結果が見つかりません</div><button class="empty-state-clear-btn" type="button">検索条件をクリア</button><div class="empty-state-hint">または Escape キーでクリア</div>`
            : `<svg class="empty-state-icon" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg><div class="empty-state-text">このフォルダには画像がありません</div>`;
        }
      }
      this.lastGridStartIndex = -1;
      this.lastGridEndIndex = -1;
      return;
    } else {
      const emptyContainer = container.querySelector('.empty-state-container');
      if (emptyContainer) {
        emptyContainer.style.display = 'none';
        emptyContainer.dataset.mode = '';
      }
    }

    const itemSize = parseFloat(this.elements.thumbnailSizeSlider?.value) || 120;
    const gap = 8;
    const padding = 8;
    const width = container.clientWidth - (padding * 2);

    // カラム数と行数の計算
    const cols = Math.max(1, Math.floor((width + gap) / (itemSize + gap)));
    const rows = Math.ceil(appState.totalCount / cols);
    const rowHeight = itemSize + gap;
    const totalHeight = rows * rowHeight + (padding * 2);

    const newTotalHeight = `${totalHeight}px`;
    if (spacer.style.height !== newTotalHeight) {
      spacer.style.height = newTotalHeight;
    }

    // 描画サイクル中にスクロール位置を復元し、以降の計算で正しい startIndex を利用する（二重レンダリングと遅延を防止）
    if (appState.savedScrollTopGrid) {
      container.scrollTop = appState.savedScrollTopGrid;
      appState.savedScrollTopGrid = 0;
    }

    const containerHeight = container.clientHeight || window.innerHeight;
    const maxScrollTop = Math.max(0, totalHeight - containerHeight);

    // アイテム数急減時等でスクロール位置が最大高さを超えている場合は安全にクランプする
    if (container.scrollTop > maxScrollTop) {
      container.scrollTop = maxScrollTop;
    }
    const scrollTop = Math.min(container.scrollTop, maxScrollTop);

    // スクロール進行方向に応じた適応型バッファ配分（合計16行を維持）
    if (typeof this._lastScrollTop === 'number') {
      if (scrollTop < this._lastScrollTop) {
        this.scrollDirection = 'up';
      } else if (scrollTop > this._lastScrollTop) {
        this.scrollDirection = 'down';
      }
    }
    this._lastScrollTop = scrollTop;

    const bufferBefore = this.scrollDirection === 'up' ? 12 : 4;
    const bufferAfter = this.scrollDirection === 'up' ? 4 : 12;

    // 表示すべき行の計算（進行方向側を厚く、通過側を薄く動的配分）
    const maxStartRow = Math.max(0, rows - 1);
    const startRow = Math.min(maxStartRow, Math.floor(Math.max(0, scrollTop - padding) / rowHeight));
    const safeStartRow = Math.max(0, startRow - bufferBefore);
    const visibleRowCount = Math.ceil(containerHeight / rowHeight);
    const visibleEndRow = Math.min(rows - 1, startRow + visibleRowCount);
    const endRow = Math.min(rows - 1, startRow + visibleRowCount + bufferAfter);

    const startIndex = Math.min(Math.max(0, appState.totalCount - 1), safeStartRow * cols);
    const endIndex = Math.max(startIndex, Math.min(appState.totalCount - 1, ((endRow + 1) * cols) - 1));
    const visibleStartIndex = Math.min(Math.max(0, appState.totalCount - 1), startRow * cols);
    const visibleEndIndex = Math.max(visibleStartIndex, Math.min(appState.totalCount - 1, ((visibleEndRow + 1) * cols) - 1));

    // スクロール位置が変わっていなければスキップ
    if (!force && this.lastGridStartIndex === startIndex && this.lastGridEndIndex === endIndex) {
      return;
    }

    // ドラッグ中にDOMを再構築すると、ドラッグ元の要素が消滅して操作が強制キャンセルされるのを防ぐ
    if (dndState && dndState.isAppDragging) {
      return;
    }

    this.lastGridStartIndex = startIndex;
    this.lastGridEndIndex = endIndex;

    const neededGridCount = endIndex - startIndex + 1;
    let items = this._getCachedWindowItems(startIndex, neededGridCount);
    if (!items) {
      items = await this._fetchWindowItems(startIndex, neededGridCount);
    }

    // 非同期呼び出し中にスクロールが遷移した場合は古い結果を破棄し、同期外れによるちらつきと表示崩れを防止する
    const currentScrollTop = Math.min(container.scrollTop, maxScrollTop);
    const currentStartRow = Math.min(maxStartRow, Math.floor(Math.max(0, currentScrollTop - padding) / rowHeight));
    const currentSafeStartRow = Math.max(0, currentStartRow - bufferBefore);
    const currentStartIndex = Math.min(Math.max(0, appState.totalCount - 1), currentSafeStartRow * cols);
    if (!force && currentStartIndex !== startIndex) {
      return;
    }

    // viewportPathSet: 現在画面（ビューポート）内に実際に表示されているアイテムのパス集合（描写優先度の最上位）
    // 後続のDOM同期やサムネイルキューイング処理で最新の画面位置を即座に参照できるよう、items取得直後に即時確定する
    let viewportSet = (typeof appState !== 'undefined' && appState.viewportPathSet instanceof Set)
      ? appState.viewportPathSet
      : new Set();
    viewportSet.clear();
    for (let i = visibleStartIndex; i <= visibleEndIndex; i++) {
      if (i >= startIndex && i <= endIndex) {
        const f = items[i - startIndex];
        if (f && f.path) viewportSet.add(f.path);
      }
    }
    if (typeof appState !== 'undefined') {
      appState.viewportPathSet = viewportSet;
    }

    // コンテンツ領域をスクロール位置に合わせて移動 (DOM更新の直前に行うことで、破棄時の表示崩れを防ぐ)
    const offsetY = (safeStartRow * rowHeight) + padding;
    const newTransform = `translate3d(0, ${offsetY}px, 0)`;
    if (content.style.transform !== newTransform) {
      content.style.transform = newTransform;
    }

    // DOMの再構築（要素の再利用）
    const targetCount = endIndex - startIndex + 1;

    let domStructureChanged = false;

    // 足りない要素を追加
    while (content.children.length < targetCount) {
      domStructureChanged = true;
      const wrapper = document.createElement('div');
      wrapper.className = 'thumbnail-item';
      wrapper.dataset.isVisible = 'true';
      wrapper.draggable = true;
      
      const img = document.createElement('img');
      img.className = 'thumbnail-img';
      img.decoding = "async";
      
      const label = document.createElement('div');
      label.className = 'thumbnail-label';
      
      const badge = document.createElement('div');
      badge.className = 'rating-badge';
      badge.innerHTML = '<svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span class="rating-value"></span>';
      badge.classList.remove('show');

      const mediaBadge = document.createElement('div');
      mediaBadge.className = 'media-badge';
      mediaBadge.innerHTML = '<span class="media-badge-text"></span>';

      wrapper.appendChild(img);
      wrapper.appendChild(label);
      wrapper.appendChild(badge);
      wrapper.appendChild(mediaBadge);
      content.appendChild(wrapper);
    }

    // 1. 基本DOM構造・プロパティの同期（全要素の配置・サイズ・選択・レーティング）
    for (let i = startIndex; i <= endIndex; i++) {
      const file = items[i - startIndex];
      if (!file) continue;

      const wrapper = content.children[i - startIndex];
      if (wrapper.style.display !== '') {
        wrapper.style.display = ''; // プールから復帰して確実に表示する
        domStructureChanged = true;
      }
      // children[] 固定インデックスで直アクセス（querySelector廃止でO(subtree)走査を排除）
      const img   = wrapper.children[0]; // .thumbnail-img
      const label = wrapper.children[1]; // .thumbnail-label
      const isSelected = appState.selection.has(i);

      if (isSelected) {
        wrapper.classList.add('selected');
      } else {
        wrapper.classList.remove('selected');
      }

      // サイズが変化したときのみ style を書き込む（無条件書き込みによる Reflow 予約を排除）
      if (wrapper._cachedItemSize !== itemSize) {
        wrapper._cachedItemSize = itemSize;
        wrapper.style.height = `${itemSize}px`;
        if (img.style.height) img.style.height = '';
      }

      // パスが変わった場合のみ内容を更新する
      if (wrapper.dataset.filepath !== file.path || wrapper.dataset.index != i) {
        if (wrapper.dataset.filepath && this._domByPath && this._domByPath.get(wrapper.dataset.filepath) === wrapper) {
          this._domByPath.delete(wrapper.dataset.filepath);
        }

        wrapper.dataset.filepath = file.path;
        wrapper.dataset.index = i;

        // 画面上に表示されているアイテム（visibleStartIndex 〜 visibleEndIndex）のみスケルトンローディング状態（エフェクト）にする
        // 画面外バッファ領域にはローディングエフェクトを出さず、現在画面の表示優先度と視認性を明確にする
        const isItemInViewport = i >= visibleStartIndex && i <= visibleEndIndex;
        if (isItemInViewport) {
          wrapper.classList.add('loading');
          img.classList.add('loading');
        } else {
          wrapper.classList.remove('loading');
          img.classList.remove('loading');
        }

        if (file.name) {
          label.textContent = file.name;
          wrapper.dataset.filename = file.name;
          label.removeAttribute('title');
          wrapper.removeAttribute('title');
        } else {
          label.textContent = '';
          delete wrapper.dataset.filename;
          label.removeAttribute('title');
          wrapper.removeAttribute('title');
        }
      }

      // _domByPath は常に最新の状態を維持する（仮想スクロールでの再利用に対応）
      if (!this._domByPath) this._domByPath = new Map();
      this._domByPath.set(file.path, wrapper);

      // レーティングの同期（パスやインデックスが変わらなくてもショートカット操作に追従させる）
      // _cachedRating を用いることで O(1) かつ変更時のみの DOM アクセスに限定
      const rating = getRatingForPath(file.path);
      if (wrapper._cachedRating !== rating) {
        wrapper._cachedRating = rating;
        const badge = wrapper.children[2];
        if (badge) {
          if (rating > 0) {
            badge.children[1].textContent = rating;
            badge.classList.add('show');
          } else {
            badge.classList.remove('show');
          }
        }
      }

      // メディア種別オーバーレイバッジの同期（O(1) キャッシュ比較）
      const mediaBadgeLabel = isAudioFile(file.path) ? 'MP3' : '';
      if (wrapper._cachedMediaType !== mediaBadgeLabel) {
        wrapper._cachedMediaType = mediaBadgeLabel;
        const mediaBadge = wrapper.children[3];
        if (mediaBadge) {
          if (mediaBadgeLabel) {
            mediaBadge.children[0].textContent = mediaBadgeLabel;
            mediaBadge.classList.add('show');
          } else {
            mediaBadge.classList.remove('show');
          }
        }
      }
    }

    // --- サムネイル画像描写の優先順序構築 (Phase 2: スクロール方向への動的適応) ---
    // サムネイル描写の始点は常に「現在画面に表示されている領域 (visibleStartIndex 〜 visibleEndIndex)」を最優先とする。
    // その後のバッファ領域は、スクロール方向（進行方向）に合わせて動的に優先度を切り替える：
    // - 上スクロール時: 画面内 -> 画面上側バッファ -> 画面下側バッファ
    // - 下スクロール/静止時: 画面内 -> 画面下側バッファ -> 画面上側バッファ
    const loadOrder = [];
    // 1. 現在画面に表示されている領域（最優先・始点は visibleStartIndex）
    for (let i = visibleStartIndex; i <= visibleEndIndex; i++) {
      if (i >= startIndex && i <= endIndex) {
        loadOrder.push(i);
      }
    }
    if (this.scrollDirection === 'up') {
      // 2. 画面上側バッファ (上スクロール進行方向: 画面に近い側から上方へ)
      for (let i = visibleStartIndex - 1; i >= startIndex; i--) {
        loadOrder.push(i);
      }
      // 3. 画面下側バッファ (通過した領域)
      for (let i = visibleEndIndex + 1; i <= endIndex; i++) {
        loadOrder.push(i);
      }
    } else {
      // 2. 画面下側バッファ (下スクロール進行方向: 画面直下から下方へ)
      for (let i = visibleEndIndex + 1; i <= endIndex; i++) {
        loadOrder.push(i);
      }
      // 3. 画面上側バッファ (通過した領域)
      for (let i = visibleStartIndex - 1; i >= startIndex; i--) {
        loadOrder.push(i);
      }
    }

    const filesToEnqueue = [];

    for (const i of loadOrder) {
      const file = items[i - startIndex];
      if (!file) continue;

      const wrapper = content.children[i - startIndex];
      if (!wrapper) continue;
      const img = wrapper.children[0];
      if (!img) continue;

      if (img.dataset.currentSrc !== file.path || img.classList.contains('loading')) {
        img.dataset.currentSrc = file.path;

        if (appState.thumbnailUrls.has(file.path)) {
          const targetUrl = appState.thumbnailUrls.get(file.path);
          // O(1) LRU 更新: 参照されたエントリを Map 末尾（MRU）へ移動
          appState.thumbnailUrls.delete(file.path);
          appState.thumbnailUrls.set(file.path, targetUrl);
          img.classList.toggle('audio-placeholder', targetUrl === AUDIO_PLACEHOLDER_URL);
          if (img.src !== targetUrl) {
            img.src = targetUrl;
          }
          if (img.complete && img.naturalWidth > 0) {
            if (wrapper.dataset.filepath === file.path) {
              img.classList.remove('loading');
              wrapper.classList.remove('loading');
              if (img.naturalWidth === 0 && !img.src.startsWith('data:image/svg+xml')) {
                // Force onerror logic if broken
                img.dispatchEvent(new Event('error'));
              }
            }
          } else {
            img.onload = function() {
              if (wrapper.dataset.filepath === file.path) {
                this.classList.remove('loading');
                wrapper.classList.remove('loading');
              }
            };
            img.onerror = function() {
              if (wrapper.dataset.filepath !== file.path) return;
              this.classList.remove('loading');
              wrapper.classList.remove('loading');
              let fallback;
              if (file.path.toLowerCase().endsWith('.mp4')) {
                fallback = BROKEN_MP4_FALLBACK_URL;
              } else if (isAudioFile(file.path)) {
                fallback = AUDIO_PLACEHOLDER_URL;
                this.classList.add('audio-placeholder');
              } else {
                fallback = getStreamUrl(file.path, window.veloceAPI.convertFileSrc(file.path));
              }
              if (this.src !== fallback) {
                const isStaticFallback = isAudioFile(file.path) || file.path.toLowerCase().endsWith('.mp4');
                if (isStaticFallback || (!this.src.startsWith('asset://') && !isLocalMediaServerUrl(this.src))) {
                  if (window.appState && window.appState.thumbnailUrls) {
                    window.appState.thumbnailUrls.set(file.path, fallback);
                    if (window.evictThumbnailCache) window.evictThumbnailCache();
                  }
                  this.src = fallback;
                }
              }
            };
            if (img.complete && img.naturalWidth > 0) {
              if (wrapper.dataset.filepath === file.path) {
                img.classList.remove('loading');
                wrapper.classList.remove('loading');
              }
            }
          }
          if (typeof window.markThumbnailCompleted === 'function') window.markThumbnailCompleted(file.path);
        } else if (file.hasThumbnailCache && !(appState.rebuiltPaths && appState.rebuiltPaths.has(file.path))) {
          const hashParam = file.hashKey ? `&hash=${encodeURIComponent(file.hashKey)}` : '';
          const tokenParam = window.videoServerToken ? `&token=${encodeURIComponent(window.videoServerToken)}` : '';
          const url = window.videoServerPort
            ? `http://127.0.0.1:${window.videoServerPort}/?path=${encodeURIComponent(file.path)}&mtime=${file.mtime}&thumb=1${hashParam}${tokenParam}`
            : `https://veloce.localhost/thumbnail/?path=${encodeURIComponent(file.path)}&mtime=${file.mtime}${hashParam}${tokenParam}`;
          appState.thumbnailUrls.set(file.path, url);
          if (window.evictThumbnailCache) window.evictThumbnailCache();
          img.src = url;
          if (img.complete && img.naturalWidth > 0) {
            if (wrapper.dataset.filepath === file.path) {
              img.classList.remove('loading');
              wrapper.classList.remove('loading');
            }
          } else {
            img.onload = function() {
              if (wrapper.dataset.filepath === file.path) {
                this.classList.remove('loading');
                wrapper.classList.remove('loading');
              }
            };
            img.onerror = function() {
              if (wrapper.dataset.filepath !== file.path) return;
              this.classList.remove('loading');
              wrapper.classList.remove('loading');
              // URL失敗時はstale URLエントリを削除してから再生成キューに委譲する
              if (window.appState && window.appState.thumbnailUrls) {
                window.appState.thumbnailUrls.delete(file.path);
              }
              if (window.thumbnailManager) {
                window.thumbnailManager.enqueuePriority(file.path);
              }
            };
            if (img.complete && img.naturalWidth > 0) {
              if (wrapper.dataset.filepath === file.path) {
                img.classList.remove('loading');
                wrapper.classList.remove('loading');
              }
            }
          }
          if (typeof window.markThumbnailCompleted === 'function') window.markThumbnailCompleted(file.path);
        } else {
          img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
          img.onload = null;
          img.onerror = null;
          if (window.thumbnailManager) {
            filesToEnqueue.push({ filePath: file.path, skipDbCheck: true });
          }
        }
      }
    }

    // DOMプールの余分な要素を非表示にして使い回す（GCとReflowの発生を抑える）
    const currentChildrenCount = content.children.length;
    for (let i = targetCount; i < currentChildrenCount; i++) {
      const unusedWrapper = content.children[i];
      if (unusedWrapper.style.display !== 'none') {
        unusedWrapper.style.display = 'none';
        domStructureChanged = true;
        if (unusedWrapper.dataset.filepath && this._domByPath) {
          this._domByPath.delete(unusedWrapper.dataset.filepath);
          unusedWrapper.dataset.filepath = '';
        }
        // querySelectorの誤爆（古いindexがヒットする）を防ぐためクリア
        unusedWrapper.dataset.index = '';
      }
    }

    // DOM構造の変化（要素新規生成・表示非表示切替）または強制更新時のみ同期レイアウトを確定し、通常スクロール時の不要Reflowを根絶
    if (domStructureChanged || force) {
      void content.offsetHeight;
    }



    // visiblePathSet を _domByPath から構築（既存Setを再利用してスクロール毎フレームのGC圧を根絶）
    let visibleSet = (typeof appState !== 'undefined' && appState.visiblePathSet instanceof Set)
      ? appState.visiblePathSet
      : new Set();
    visibleSet.clear();
    if (this._domByPath) {
      for (const fp of this._domByPath.keys()) {
        visibleSet.add(fp);
      }
    }
    if (typeof appState !== 'undefined') {
      appState.visiblePathSet = visibleSet;
    }

    // --- 通り過ぎた不要タスクのパージ (Phase 3: UX-3) ---
    // 高速スクロール時にビューポート＋前後バッファ（visibleSet）から完全に外れた未着手優先タスクを削除し、
    // CPU/Workerリソースを現在画面に集中させる
    if (window.thumbnailManager && typeof window.thumbnailManager.purgeOutOfView === 'function') {
      window.thumbnailManager.purgeOutOfView(visibleSet);
    }

    // --- バックグラウンド・プレロード位置の現在地追従 (Phase 1: UX-1) ---
    // ユーザーが見ている画面の直後から先回りフェッチを行うため、preloadCursor を visibleEndIndex + 1 に同期
    if (visibleEndIndex >= 0 && typeof appState !== 'undefined' && appState.totalCount > 0) {
      const nextPreloadTarget = Math.min(appState.totalCount, visibleEndIndex + 1);
      const tm = window.thumbnailManager;
      const isOutOfRange = appState.preloadCursor < visibleStartIndex || appState.preloadCursor > visibleEndIndex + 150;
      if (appState.preloadCursor === 0 || isOutOfRange) {
        appState.preloadCursor = nextPreloadTarget;
        if (tm) {
          tm._preloadAnchor = nextPreloadTarget;
          tm._preloadWrapped = false;
          if (typeof tm.resetPreload === 'function') {
            tm.resetPreload();
          }
        }
      } else if (!tm?._preloadWrapped && appState.preloadCursor < nextPreloadTarget) {
        appState.preloadCursor = nextPreloadTarget;
      }
    }

    // --- ここでようやく enqueuePriority を呼ぶ ---
    if (filesToEnqueue.length > 0 && window.thumbnailManager) {
      if (typeof window.thumbnailManager.enqueuePriorityBatch === 'function') {
        window.thumbnailManager.enqueuePriorityBatch(filesToEnqueue, true);
      } else {
        for (const fp of filesToEnqueue) {
          window.thumbnailManager.enqueuePriority(fp, true);
        }
      }
    }

    // 画像読み込みタスクをキック
    if (typeof window.processNextTask === 'function') window.processNextTask();
    });
  }

  /**
   * サムネイル生成やメタデータ取得で判明した画像の幅・高さをファイル一覧テーブルに即時反映する
   * O(1) DOM Pool 更新により、画面全体の再レンダリングやReflowを回避する
   * @param {string} filePath - 対象ファイルのパス
   * @param {number} width - 画像の幅
   * @param {number} height - 画像の高さ
   */
  updateFileDimensions(filePath, width, height) {
    if (!width || !height) return;

    // 1. appState.initialChunk およびスライディングウィンドウ・キャッシュ内の該当アイテムを更新
    const state = (typeof window !== 'undefined' && window.appState) ? window.appState : appState;
    if (state && state.initialChunk) {
      const cached = state.initialChunk.find(f => f.path === filePath);
      if (cached) {
        cached.width = width;
        cached.height = height;
      }
    }
    if (this._itemWindowCache && Array.isArray(this._itemWindowCache.items)) {
      const winCached = this._itemWindowCache.items.find(f => f && f.path === filePath);
      if (winCached) {
        winCached.width = width;
        winCached.height = height;
      }
    }

    // 2. ファイル一覧テーブル（VirtualList）の該当行を O(1) で即時同期
    if (this._listDomByPath) {
      const tr = this._listDomByPath.get(filePath);
      if (tr && tr.children && tr.children.length >= 5) {
        const tds = tr.children;
        const newWidth = width.toLocaleString();
        if (tds[2].textContent !== newWidth) tds[2].textContent = newWidth;

        const newHeight = height.toLocaleString();
        if (tds[3].textContent !== newHeight) tds[3].textContent = newHeight;

        const d = gcd(width, height);
        const rw = width / d;
        const rh = height / d;
        const ratioStr = (rw > 100 || rh > 100) ? `${(width / height).toFixed(2)}:1` : `${rw}:${rh}`;
        if (tds[4].textContent !== ratioStr) tds[4].textContent = ratioStr;
      }
    }
  }

  /**
   * アプリケーション全体のテーマを適用します。
   * 'light' の場合は <html> に data-theme="light" を付与し、
   * 'dark' または未指定の場合は属性を削除して規定のダークモードを維持します。
   * @param {'dark'|'light'} [theme='dark'] - 適用するテーマ
   */
  applyTheme(theme) {
    const isLight = theme === 'light';
    if (isLight) {
      document.documentElement.setAttribute('data-theme', 'light');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
    if (this.state) {
      this.state.theme = isLight ? 'light' : 'dark';
    }
  }
}

export { UIManager };
export const uiManager = new UIManager(appState);

export { showDiffModal } from './renderer-diff.js';
export { ICON_SVGS, COLORS, ICON_DESCRIPTIONS, createFavoriteEditorUI, resolvePathDisplay } from './favorite-icons.js';
