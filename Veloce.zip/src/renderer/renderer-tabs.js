import { checkPathExists } from '../common/path-utils.js';
import { getFolderSort, setSetting } from '../common/settings-store.js';

/**
 * 現在のタブの状態を同期します。
 * @param {import('./renderer-state.js').AppState} appState
 * @param {import('./renderer-ui.js').UIManager} uiManager
 */
export function updateCurrentTabState(appState, uiManager) {
  if (appState.activeTabIndex >= 0 && appState.tabs[appState.activeTabIndex]) {
    const currentTab = appState.tabs[appState.activeTabIndex];
    if (typeof appState.searchQuery !== 'undefined') currentTab.searchQuery = appState.searchQuery;
    if (appState.sortConfig) currentTab.sortConfig = { ...appState.sortConfig };
    if (uiManager.elements.thumbnailGrid) {
      currentTab.scrollTop = uiManager.elements.thumbnailGrid.scrollTop || 0;
    }
  }
}

/**
 * タブの状態をローカルストレージに保存します。
 * @param {import('./renderer-state.js').AppState} appState
 * @param {import('./renderer-ui.js').UIManager} uiManager
 */
export function saveTabsState(appState, uiManager) {
  updateCurrentTabState(appState, uiManager);
  const state = {
    tabs: appState.tabs.map(t => ({
      id: t.id,
      path: t.path,
      name: t.name,
      searchQuery: t.searchQuery || '',
      sortConfig: t.sortConfig || { key: 'name', asc: true },
      scrollTop: t.scrollTop || 0,
      history: t.history || [t.path],
      historyIndex: t.historyIndex !== undefined ? t.historyIndex : 0
    })),
    activeTabIndex: appState.activeTabIndex
  };
  if (typeof window !== 'undefined' && window.SettingsStore) {
    window.SettingsStore.setItem('tabsState', JSON.stringify(state));
  } else if (typeof localStorage !== 'undefined') {
    localStorage.setItem('tabsState', JSON.stringify(state));
  }
}

/**
 * パスからタブの表示名を取得します。
 * @param {string} path
 * @param {Array<{path: string, name: string}>} favorites
 */
export function getTabNameForPath(path, favorites) {
  if (!path) return '';
  if (path === 'PC') return 'PC';
  const fav = favorites.find(f => f.path === path);
  if (fav) return fav.name;
  return path.split('\\').pop() || path;
}

/**
 * タブ操作ハンドラを初期化して window に登録します。
 * @param {object} ctx
 */
export function initTabHandlers(ctx) {
  const {
    appState,
    uiManager,
    expandTreeToPath,
    clearMetadataUI,
    updateNavButtons,
    updateSortIndicators
  } = ctx;

  window.onTabClick = async (index) => {
    if (index === appState.activeTabIndex) return;

    const tab = appState.tabs[index];
    if (!tab) return;

    const exists = await checkPathExists(tab.path);
    if (!exists) {
      const canCloseTab = appState.tabs.length > 1;
      const action = await uiManager.showMissingFolderDialog(tab.path, canCloseTab);
      if (action === 'close') {
        await window.onTabClose(index);
      }
      return;
    }

    updateCurrentTabState(appState, uiManager);

    // タブ切り替え直前に、前タブで実行中だったサムネイル生成・Worker・バッチ処理を即座に全破棄し、新タブの描画に影響を与えない
    if (window.thumbnailManager && typeof window.thumbnailManager.clear === 'function') {
      window.thumbnailManager.clear();
    }

    appState.activeTabIndex = index;
    uiManager.renderTabs();
    if (uiManager && typeof uiManager.scrollTabIntoView === 'function') {
      uiManager.scrollTabIntoView();
    }

    appState.searchQuery = tab.searchQuery || '';
    if (uiManager.elements.searchBar) uiManager.elements.searchBar.value = appState.searchQuery;
    const folderSort = getFolderSort(tab.path);
    if (folderSort) {
      appState.sortConfig = { ...folderSort };
      tab.sortConfig = { ...folderSort };
    } else if (tab.sortConfig) {
      appState.sortConfig = { ...tab.sortConfig };
    }
    setSetting('currentSort', JSON.stringify(appState.sortConfig));
    updateSortIndicators();

    if (window.veloceAPI.loadDirectory) {
      if (window.veloceAPI.setViewParams) {
        await appState.setViewParams(true);
      }
      appState.currentDirectory = tab.path;
      setSetting('currentDirectory', appState.currentDirectory);
      appState.totalCount = 0;
      appState.selection.clear();
      appState.selectedIndex = -1;
      uiManager.renderAll(true);
      clearMetadataUI();
      uiManager.showToast('フォルダを読み込み中', 0, 'dir-load-progress', 'info');

      // 次に読み込まれるディレクトリ描画後に復元するスクロール位置をセット
      appState.savedScrollTopGrid = tab.scrollTop || 0;

      updateNavButtons();

      window.veloceAPI.loadDirectory(tab.path);

      await expandTreeToPath(appState.currentDirectory);
      saveTabsState(appState, uiManager);
    }
  };

  window.onNewTabClick = async () => {
    let newPath = 'PC';
    try {
      if (window.__TAURI__?.path?.pictureDir) {
        newPath = await window.__TAURI__.path.pictureDir();
      }
    } catch (e) {
      console.warn('Failed to get picture dir:', e);
    }

    const newTab = {
      id: Date.now(),
      path: newPath,
      name: getTabNameForPath(newPath, appState.favorites),
      isNew: true,
      searchQuery: '',
      sortConfig: { key: 'name', asc: true },
      scrollTop: 0,
      history: [newPath],
      historyIndex: 0
    };
    appState.tabs.push(newTab);
    saveTabsState(appState, uiManager);

    await window.onTabClick(appState.tabs.length - 1);

    const container = document.getElementById('tab-container');
    if (container) {
      container.scrollLeft = container.scrollWidth;
    }
  };

  window.onTabClose = async (index) => {
    if (appState.tabs.length <= 1) return;

    const tabToRemove = appState.tabs[index];
    if (!tabToRemove || tabToRemove.isClosing) return;
    tabToRemove.isClosing = true;

    const container = document.getElementById('tab-container');
    let targetTabEl = null;

    if (container) {
      targetTabEl = container.querySelector(`.tab-item[data-tab-id="${tabToRemove.id}"]`) || container.querySelector(`.tab-item[data-index="${index}"]`);
    }

    // フェーズ1: tabFadeOut アニメーション開始
    if (targetTabEl) {
      // アニメーション開始前に現在の幅を確定してロック（flex による可変幅を固定値にする）
      const currentWidth = targetTabEl.getBoundingClientRect().width;
      targetTabEl.style.minWidth = currentWidth + 'px';
      targetTabEl.style.maxWidth = currentWidth + 'px';
      targetTabEl.style.width = currentWidth + 'px';

      targetTabEl.classList.add('tab-dent');

      // transform のバウンスが完了するタイミング(約70ms)で幅ゼロへのトランジションを開始する
      // overflow: hidden を解除したため、幅が縮小しても transform アニメーションは途切れない
      setTimeout(() => {
        if (!targetTabEl.parentNode) return;
        targetTabEl.classList.add('tab-collapsing');
      }, 70);
    }

    let nextIndex = appState.activeTabIndex;
    let shouldSwitch = false;

    if (appState.activeTabIndex === index) {
      nextIndex = index - 1;
      if (nextIndex < 0) nextIndex = 0;
      shouldSwitch = true;
    } else if (appState.activeTabIndex > index) {
      appState.activeTabIndex -= 1;
    }

    if (shouldSwitch && appState.tabs[nextIndex]) {
      const nextTab = appState.tabs[nextIndex];
      appState.activeTabIndex = nextIndex;

      if (container) {
        container.querySelectorAll('.tab-item').forEach(el => el.classList.remove('active'));
        const newActiveEl = container.querySelector(`.tab-item[data-tab-id="${nextTab.id}"]`) || container.querySelector(`.tab-item[data-index="${nextIndex}"]`);
        if (newActiveEl) newActiveEl.classList.add('active');
      }

      if (window.veloceAPI?.loadDirectory) {
        // 重いDOM更新とIPC通信を遅延させ、タブが閉じるアニメーション（220ms）が
        // メインスレッドのブロックによってコマ落ち（フレームドロップ）しないようにする
        setTimeout(async () => {
          // もし遅延中に別のタブがアクティブになっていたらキャンセル
          if (appState.activeTabIndex !== nextIndex) return;

          appState.currentDirectory = nextTab.path;
          setSetting('currentDirectory', appState.currentDirectory);
          
          appState.searchQuery = nextTab.searchQuery || '';
          if (uiManager.elements.searchBar) uiManager.elements.searchBar.value = appState.searchQuery;
          const folderSort = getFolderSort(nextTab.path);
          if (folderSort) {
            appState.sortConfig = { ...folderSort };
            nextTab.sortConfig = { ...folderSort };
          } else if (nextTab.sortConfig) {
            appState.sortConfig = JSON.parse(JSON.stringify(nextTab.sortConfig));
          }
          setSetting('currentSort', JSON.stringify(appState.sortConfig));
          updateSortIndicators();

          appState.totalCount = 0;
          appState.selection.clear();
          appState.selectedIndex = -1;
          uiManager.renderAll(true);
          clearMetadataUI();
          updateNavButtons();
          
          if (window.veloceAPI.setViewParams) {
            await appState.setViewParams(true);
          }

          appState.savedScrollTopGrid = nextTab.scrollTop || 0;
          
          window.veloceAPI.loadDirectory(nextTab.path);
          expandTreeToPath(appState.currentDirectory);
          if (uiManager && typeof uiManager.scrollTabIntoView === 'function') {
            uiManager.scrollTabIntoView();
          }
        }, 230);
      }
    }

    // フェーズ2: アニメーション(70ms遅延) + 幅縮小(150ms) + 余白(10ms) = 230ms後にDOM削除
    setTimeout(function() {
      const currentTabIdx = appState.tabs.indexOf(tabToRemove);
      if (currentTabIdx !== -1) {
        appState.tabs.splice(currentTabIdx, 1);
      }

      if (targetTabEl && targetTabEl.parentNode) {
        targetTabEl.remove();
      }

      uiManager.renderTabs();
      saveTabsState(appState, uiManager);
    }, 230);
  };

  window.onTabMove = (fromIndex, toIndex, insertAfter) => {
    if (fromIndex === toIndex) return;

    const tabs = appState.tabs;
    const activeTab = tabs[appState.activeTabIndex];

    const [movedTab] = tabs.splice(fromIndex, 1);

    let adjustedToIndex = toIndex;
    if (fromIndex < toIndex) adjustedToIndex -= 1;
    if (insertAfter) adjustedToIndex += 1;

    tabs.splice(adjustedToIndex, 0, movedTab);
    appState.activeTabIndex = tabs.indexOf(activeTab);

    uiManager.renderTabs();
    saveTabsState(appState, uiManager);
  };
}
