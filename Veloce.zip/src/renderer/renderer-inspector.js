/**
 * Veloce - Inspector & DOM Pool Management Module (renderer-inspector.js)
 * 
 * 責務:
 * 1. 右ペインインスペクター (#inspector-content) のメタデータ・タグ描画
 * 2. DOM Pool パターンによるセクション・タグ要素の再利用と GC (ガベージコレクション) 抑制
 * 3. 単一ファイルメタデータ描画 (renderMetadata)
 * 4. 複数画像選択時のサマリー描画 (renderMultipleSelectionSummary)
 * 5. インスペクターの空状態リセット・クリア (clearMetadataUI, resetInspectorPools)
 * 6. コピーボタン、ツールチップ、パス右クリック、プロンプトテキストコピー等のイベント委譲
 * 
 * Windows 8.1 / WebView2 (Chromium 109) 互換性を厳格に維持。
 */

import { appState } from './renderer-state.js';
import { UIManager, uiManager } from './renderer-ui.js';
import {
  extractMetadataFields,
  highlightSearchTerms,
  buildInspectorSections,
  createSearchTermsRegex
} from '../common/metadata-format.js';

// --- DOM Pool for Inspector ---
const inspectorSectionPool = [];
const inspectorTagPool = [];
let inspectorSectionIndex = 0;
let inspectorTagIndex = 0;
let _inspectorDelegationInit = false;
let _inspectorDelegationOptions = {};
let _currentInspectorRenderSeq = 0;

export function resetInspectorDelegationForTest() {
  _inspectorDelegationInit = false;
  _inspectorDelegationOptions = {};
  _currentInspectorRenderSeq = 0;
}

export function getCurrentInspectorRenderSeqForTest() {
  return _currentInspectorRenderSeq;
}

/**
 * DOM Pool からセクション要素を取得する（不足時は新規生成してPoolに追加）
 * @returns {{ root: HTMLDivElement, title: HTMLSpanElement, subLabel: HTMLSpanElement, copyWrapper: HTMLDivElement, copyBtn: HTMLElement|null, box: HTMLDivElement }}
 */
export function getInspectorSection() {
  if (inspectorSectionIndex < inspectorSectionPool.length) {
    const el = inspectorSectionPool[inspectorSectionIndex++];
    el.root.style.display = 'block';
    return el;
  }
  const section = document.createElement('div');
  section.className = 'inspector-section inspector-section-block';

  const h3 = document.createElement('h3');
  h3.className = 'inspector-section-h3';

  const titleWrapper = document.createElement('span');
  titleWrapper.className = 'inspector-title-wrapper';

  const titleSpan = document.createElement('span');
  const subLabelSpan = document.createElement('span');

  titleWrapper.appendChild(titleSpan);
  titleWrapper.appendChild(subLabelSpan);

  const copyWrapper = document.createElement('div');
  copyWrapper.className = 'inspector-copy-wrapper';

  h3.appendChild(titleWrapper);
  h3.appendChild(copyWrapper);

  const box = document.createElement('div');
  box.tabIndex = -1;

  section.appendChild(h3);
  section.appendChild(box);

  const elObj = {
    root: section,
    title: titleSpan,
    subLabel: subLabelSpan,
    copyWrapper: copyWrapper,
    copyBtn: null,
    box: box
  };

  inspectorSectionPool.push(elObj);
  inspectorSectionIndex++;
  return elObj;
}

/**
 * DOM Pool からタグ要素を取得する（不足時は新規生成してPoolに追加）
 * @returns {HTMLSpanElement}
 */
export function getInspectorTag() {
  if (inspectorTagIndex < inspectorTagPool.length) {
    const el = inspectorTagPool[inspectorTagIndex++];
    el.style.display = 'inline';
    return el;
  }
  const span = document.createElement('span');
  span.className = 'diff-tag common';
  inspectorTagPool.push(span);
  inspectorTagIndex++;
  return span;
}

/**
 * DOM Pool の利用インデックスをリセットし、プール内のDOM要素を初期状態へ戻す
 */
export function resetInspectorPools() {
  for (let i = 0; i < inspectorSectionIndex; i++) {
    const sec = inspectorSectionPool[i];
    sec.root.style.display = 'none';
    sec.box.replaceChildren();
    sec.title.style.color = '';
    sec.subLabel.textContent = '';
    sec.subLabel.className = '';
    sec.subLabel.replaceChildren();
    sec.copyWrapper.style.display = 'none';
    sec.box.className = 'prompt-look';
    sec.box.style.cssText = '';
  }
  for (let i = 0; i < inspectorTagIndex; i++) {
    inspectorTagPool[i].classList.remove('search-match');
  }
  inspectorSectionIndex = 0;
  inspectorTagIndex = 0;
}

/**
 * インスペクターのメタデータ表示を空状態にクリアする
 */
export function clearMetadataUI() {
  const staticTable = document.getElementById('static-file-info-table');
  const emptyInfoMsg = document.getElementById('file-info-empty');
  if (staticTable && emptyInfoMsg) {
    staticTable.style.display = 'none';
    emptyInfoMsg.style.display = 'flex';
  }

  resetInspectorPools();

  const emptyInspectorMsg = document.getElementById('inspector-empty');
  if (emptyInspectorMsg) {
    emptyInspectorMsg.classList.add('show');
  }

  const headerPath = document.getElementById('inspector-header-path');
  if (headerPath) {
    headerPath.style.display = 'none';
  }

  const spacer = document.getElementById('inspector-bottom-spacer');
  if (spacer) {
    spacer.style.display = 'none';
  }
}

/**
 * 複数画像選択時のインスペクターサマリーを描画する
 */
export async function renderMultipleSelectionSummary() {
  const container = document.getElementById('inspector-content');
  const headerPath = document.getElementById('inspector-header-path');
  const staticTable = document.getElementById('static-file-info-table');
  const emptyInfoMsg = document.getElementById('file-info-empty');

  // 単一ファイル用の静的ファイル情報テーブルを隠し、空状態表示へ切り替え
  if (staticTable && emptyInfoMsg) {
    staticTable.style.display = 'none';
    emptyInfoMsg.style.display = 'flex';
  }

  const emptyInspectorMsg = document.getElementById('inspector-empty');
  if (emptyInspectorMsg) emptyInspectorMsg.classList.remove('show');

  // DOM Pool の再利用インデックスをリセットし、前回のセクション・タグをクリーンアップ
  resetInspectorPools();

  const count = appState.selection.size;
  const total = appState.totalCount || count;
  const pct = total > 0 ? ((count / total) * 100).toFixed(1) : '100';

  // インスペクターヘッダーに選択件数と割合を表示
  if (headerPath) {
    headerPath.innerHTML = `<bdi dir="ltr">${count} / ${total} 件選択中 (${pct}%)</bdi>`;
    headerPath.removeAttribute('data-path');
    headerPath.style.display = 'block';
  }

  // 1. 複数選択概要セクション (DOM Poolから要素を取得してGC発生を抑制)
  const sec1 = getInspectorSection();
  sec1.title.textContent = '複数選択概要';
  sec1.copyWrapper.replaceChildren();
  sec1.subLabel.textContent = '';
  sec1.box.className = 'prompt-look param-box';
  sec1.box.style.cssText = '';

  const tag1 = getInspectorTag();
  tag1.style.cssText = '';
  tag1.className = 'diff-tag common';
  tag1.textContent = `選択数: ${count} 件 (フォルダ内 ${total} 件中 ${pct}%)`;
  sec1.box.appendChild(tag1);

  if (sec1.root.parentNode !== container) container.appendChild(sec1.root);

  // 2. 一括ショートカット操作ガイドセクション
  const sec2 = getInspectorSection();
  sec2.title.textContent = 'ショートカット操作';
  sec2.copyWrapper.replaceChildren();
  sec2.subLabel.textContent = '';
  sec2.box.className = 'prompt-look';
  sec2.box.style.cssText = '';

  const shortcuts = [
    '1 〜 5 : 一括レーティング',
    'Delete : 一括ゴミ箱移動',
    'Ctrl + C : パスコピー',
    'Ctrl + A : すべて選択'
  ];

  for (const sc of shortcuts) {
    const tag = getInspectorTag();
    tag.style.cssText = '';
    tag.className = 'diff-tag common';
    tag.textContent = sc;
    sec2.box.appendChild(tag);
  }

  if (sec2.root.parentNode !== container) container.appendChild(sec2.root);

  let spacer = document.getElementById('inspector-bottom-spacer');
  if (!spacer) {
    spacer = document.createElement('div');
    spacer.id = 'inspector-bottom-spacer';
    spacer.className = 'inspector-bottom-spacer';
  }
  spacer.style.display = 'block';
  container.appendChild(spacer);
}

/**
 * インスペクター内のイベント委譲を初期化する
 * @param {Object} [options]
 * @param {Object} [options.contextMenuManager] - コンテキストメニュー管理オブジェクト
 * @param {Function} [options.showNotification] - 通知関数
 */
export function initInspectorDelegation(options = {}) {
  if (options.contextMenuManager) {
    _inspectorDelegationOptions.contextMenuManager = options.contextMenuManager;
  }
  if (options.showNotification) {
    _inspectorDelegationOptions.showNotification = options.showNotification;
  }

  if (_inspectorDelegationInit) return;
  const container = document.getElementById('inspector-content');
  const delegationRoot = document.getElementById('right-pane') || container;
  if (!delegationRoot) return;

  _inspectorDelegationInit = true;

  delegationRoot.addEventListener('click', async (e) => {
    const copyBtn = e.target.closest('.diff-copy-btn');
    if (copyBtn) {
      const text = copyBtn.getAttribute('data-copy-text');
      if (text) {
        await navigator.clipboard.writeText(text);
        if (window.uiManager) window.uiManager.showToast('クリップボードにコピーしました', 3000, null, 'success');
        else if (options.showNotification) options.showNotification('クリップボードにコピーしました', 'success');
        uiManager.applyGlowEffect(copyBtn);
        uiManager.hideCustomTooltip();
      }
    }
  });

  delegationRoot.addEventListener('mousemove', (e) => {
    const copyBtn = e.target.closest('.diff-copy-btn');
    if (copyBtn) {
      uiManager.showCustomTooltip('コピー', e.clientX, e.clientY);
    } else {
      uiManager.hideCustomTooltip();
    }
  });

  delegationRoot.addEventListener('mouseleave', () => {
    uiManager.hideCustomTooltip();
  }, true);

  delegationRoot.addEventListener('contextmenu', (e) => {
    const openBtn = e.target.closest('.open-folder-btn') ||
      (e.target.closest('#inspector-header')?.querySelector('#inspector-header-path'));
    if (openBtn) {
      e.preventDefault();
      e.stopPropagation();

      const filePathStr = openBtn.getAttribute('data-path');
      if (!filePathStr) return;

      const lastSlash = Math.max(filePathStr.lastIndexOf('\\'), filePathStr.lastIndexOf('/'));
      const dirPath = lastSlash !== -1 ? filePathStr.substring(0, lastSlash) : filePathStr;
      const folderName = dirPath.split(/[\\/]/).pop() || dirPath;

      const cmm = _inspectorDelegationOptions.contextMenuManager || options.contextMenuManager || window.contextMenuManager;
      if (cmm) {
        cmm.show('inspector-header', {
          targetFolder: { path: dirPath, name: folderName },
          isRoot: false
        }, e.clientX, e.clientY);
      }
    }
  });

  delegationRoot.addEventListener('copy', (e) => {
    const selection = window.getSelection();
    if (selection.isCollapsed) return;
    const promptLook = e.target.closest('.prompt-look');
    if (!promptLook) return;

    const clone = selection.getRangeAt(0).cloneContents();
    const tempDiv = document.createElement('div');
    tempDiv.appendChild(clone);
    const tags = tempDiv.querySelectorAll('.diff-tag');
    tags.forEach(tag => { tag.textContent = tag.textContent + ', '; });
    let copiedText = tempDiv.textContent.replace(/,\s*$/, '').trim();
    e.clipboardData.setData('text/plain', copiedText);
    e.preventDefault();
  });
}

/**
 * 単一ファイルのメタデータをインスペクターに描画する
 * @param {Object} file - 描画対象のファイルオブジェクト
 * @param {Object} [options] - 委譲初期化用オプション
 */
export async function renderMetadata(file, options = {}) {
  const container = document.getElementById('inspector-content');
  if (!file || !container) return;

  const renderSeq = ++_currentInspectorRenderSeq;

  const emptyInspectorMsg = document.getElementById('inspector-empty');
  if (emptyInspectorMsg) emptyInspectorMsg.classList.remove('show');

  try {
    const rawMeta = window.veloceAPI?.parseMetadata
      ? await window.veloceAPI.parseMetadata(file.path)
      : null;

    // 非同期呼び出し完了時に最新のリクエストシーケンスと一致しない場合は破棄（キー連打・非同期解決遅延による表示上書き防止）
    if (renderSeq !== _currentInspectorRenderSeq) {
      return;
    }

    const meta = rawMeta || {};

    if (meta.width > 0 && meta.height > 0 && (!file.width || !file.height)) {
      file.width = meta.width;
      file.height = meta.height;
      if (uiManager && typeof uiManager.updateFileDimensions === 'function') {
        uiManager.updateFileDimensions(file.path, meta.width, meta.height);
      }
      if (window.veloceAPI && typeof window.veloceAPI.updateFileDimensions === 'function') {
        window.veloceAPI.updateFileDimensions(file.path, meta.width, meta.height);
      }
    }

    const d = extractMetadataFields(file, meta);

    let searchStr = '';
    if (uiManager.elements.searchBar?.value) {
      searchStr = uiManager.elements.searchBar.value;
    } else if (typeof appState !== 'undefined' && appState.searchQuery) {
      searchStr = appState.searchQuery;
    }
    const terms = searchStr.trim() !== ''
      ? searchStr.toLowerCase().split(/[,\n\r]+/).map(t => t.trim()).filter(Boolean)
      : [];
    const termsRegex = terms.length > 0 ? createSearchTermsRegex(terms) : null;

    resetInspectorPools();

    const badge = container.querySelector('.inspector-location-badge');
    if (badge) badge.remove();

    const headerPath = document.getElementById('inspector-header-path');
    if (headerPath) {
      if (file.path) {
        const filePathStr = String(file.path);
        const lastSlash = Math.max(filePathStr.lastIndexOf('\\'), filePathStr.lastIndexOf('/'));
        const dirPath = lastSlash !== -1 ? filePathStr.substring(0, lastSlash) : filePathStr;
        const escapedPath = dirPath.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

        headerPath.innerHTML = `<bdi dir="ltr">${escapedPath}</bdi>`;
        headerPath.setAttribute('data-path', file.path);
        headerPath.removeAttribute('title');
        headerPath.style.display = 'block';
      } else {
        headerPath.style.display = 'none';
      }
    }

    let hasContent = false;
    const sections = buildInspectorSections(d);

    for (const section of sections) {
      if (!section.value || section.value === '-') continue;
      hasContent = true;

      const secEl = getInspectorSection();
      secEl.title.textContent = section.title;

      // プロンプトや除外要素など、コピーが想定されるセクションのみコピーボタンを表示
      const isCopyable = !!section.copyable;
      if (isCopyable) {
        if (!secEl.copyBtn) {
          secEl.copyWrapper.innerHTML = UIManager.createCopyButtonHTML(section.value);
          secEl.copyBtn = secEl.copyWrapper.firstElementChild;
        } else {
          secEl.copyBtn.setAttribute('data-copy-text', section.value);
        }
        secEl.copyWrapper.style.display = 'flex';
      } else {
        secEl.copyWrapper.style.display = 'none';
      }

      let sectionHasMatch = false;

      if (section.isPosition) {
        secEl.box.className = 'prompt-look inspector-position-block';
        secEl.box.style.cssText = '';
        secEl.box.replaceChildren();

        // モード表示（四角い枠線なしのテキスト表示）
        const isAuto = section.positionMode === 'AIにおまかせ' || section.useCoords === false;
        const modeText = section.positionMode || (isAuto ? 'AIにおまかせ' : 'カスタム');
        const modeRow = document.createElement('div');
        modeRow.className = 'inspector-position-mode-row';
        const modeTag = document.createElement('span');
        modeTag.className = `inspector-position-mode-text ${isAuto ? 'inspector-position-mode--auto' : 'inspector-position-mode--custom'}`;
        modeTag.textContent = modeText;
        modeRow.appendChild(modeTag);
        secEl.box.appendChild(modeRow);

        // 「AIにおまかせ」の場合はその旨のみ表示し、画像や座標情報は表示しない
        if (!isAuto && section.charPositions && section.charPositions.length > 0) {
          const mapWrapper = document.createElement('div');
          mapWrapper.className = 'inspector-position-map-wrapper';

          const map = document.createElement('div');
          map.className = 'inspector-position-map';

          const imgWidth = section.width;
          const imgHeight = section.height;
          if (imgWidth && imgHeight) {
            map.style.aspectRatio = `${imgWidth} / ${imgHeight}`;
          }

          // 背景画像（サムネイルまたは元画像URL）
          const thumbUrl = (appState?.thumbnailUrls?.get(file.path)) ||
                           (window.appState?.thumbnailUrls?.get(file.path)) ||
                           (typeof window.veloceAPI?.convertFileSrc === 'function' ? window.veloceAPI.convertFileSrc(file.path) : '') || '';
          if (thumbUrl) {
            const bgImg = document.createElement('img');
            bgImg.className = 'inspector-position-bg-img';
            bgImg.src = thumbUrl;
            bgImg.onload = () => {
              if (bgImg.naturalWidth && bgImg.naturalHeight && (!section.width || !section.height)) {
                map.style.aspectRatio = `${bgImg.naturalWidth} / ${bgImg.naturalHeight}`;
              }
            };
            map.appendChild(bgImg);
          }

          const coordsContainer = document.createElement('div');
          coordsContainer.className = 'inspector-position-coords';

          section.charPositions.forEach((cp) => {
            const charNum = cp.index;
            const markerIndex = ((charNum - 1) % 8) + 1;
            const colorClass = `char-marker-${markerIndex}`;

            cp.centers.forEach((center) => {
              const marker = document.createElement('div');
              marker.className = `inspector-position-marker ${colorClass}`;
              marker.style.left = `${(center.x * 100).toFixed(2)}%`;
              marker.style.top = `${(center.y * 100).toFixed(2)}%`;
              marker.textContent = String(charNum);
              map.appendChild(marker);

              const coordItem = document.createElement('div');
              coordItem.className = 'inspector-coord-item';

              const badge = document.createElement('span');
              badge.className = `inspector-coord-badge ${colorClass}`;
              badge.textContent = String(charNum);

              const text = document.createElement('span');
              text.className = 'inspector-coord-text';
              const xPct = (center.x * 100).toFixed(1);
              const yPct = (center.y * 100).toFixed(1);
              text.textContent = `X: ${xPct}%, Y: ${yPct}% (${center.x.toFixed(3)}, ${center.y.toFixed(3)})`;

              coordItem.appendChild(badge);
              coordItem.appendChild(text);
              coordsContainer.appendChild(coordItem);
            });
          });

          mapWrapper.appendChild(map);
          secEl.box.appendChild(mapWrapper);
          secEl.box.appendChild(coordsContainer);
        }
      } else if (section.isRaw || section.isText) {
        secEl.box.className = section.isText ? 'prompt-look text-box' : 'prompt-look raw-box';
        secEl.box.style.cssText = '';
        const rawText = String(section.value);
        if (termsRegex) {
          termsRegex.lastIndex = 0;
          sectionHasMatch = termsRegex.test(rawText);
          if (sectionHasMatch) {
            secEl.box.innerHTML = highlightSearchTerms(rawText, termsRegex);
          } else {
            secEl.box.textContent = rawText;
          }
        } else {
          secEl.box.textContent = rawText;
        }
      } else if (section.isParam) {
        secEl.box.className = 'prompt-look param-box';
        secEl.box.style.cssText = '';
        const paramText = String(section.value);

        if (termsRegex) {
          termsRegex.lastIndex = 0;
          const isMatch = termsRegex.test(paramText);
          if (isMatch) {
            sectionHasMatch = true;
          }
          secEl.box.innerHTML = highlightSearchTerms(paramText, termsRegex);
        } else {
          secEl.box.textContent = paramText;
        }
      } else {
        secEl.box.className = 'prompt-look';
        secEl.box.style.cssText = '';

        const tags = String(section.value).split(/[,\n\r]+/).map(t => t.trim()).filter(t => t);
        for (const t of tags) {
          const tagEl = getInspectorTag();

          if (termsRegex) {
            termsRegex.lastIndex = 0;
            const isMatch = termsRegex.test(t);
            if (isMatch) {
              sectionHasMatch = true;
            }
            tagEl.classList.toggle('search-match', isMatch);
            tagEl.innerHTML = highlightSearchTerms(t, termsRegex);
          } else {
            tagEl.classList.remove('search-match');
            tagEl.textContent = t;
          }
          secEl.box.appendChild(tagEl);
        }
      }

      if (sectionHasMatch) {
        secEl.title.style.color = 'var(--glow-gold)';
      } else {
        secEl.title.style.color = '';
      }

      if (section.subLabel && section.subLabel !== 'Text to Image') {
        const labels = section.subLabel.split(' + ');
        secEl.subLabel.replaceChildren();
        secEl.subLabel.className = 'sublabel-tags-wrapper';

        labels.forEach(lbl => {
          let modifier = '';
          if (lbl.includes('Inpainting')) {
            modifier = ' sublabel-tag--inpainting';
          } else if (lbl.includes('Vibe Transfer')) {
            modifier = ' sublabel-tag--vibe';
          } else if (lbl.includes('Character Reference')) {
            modifier = ' sublabel-tag--char-ref';
          } else if (lbl.includes('Image to Image') || lbl.includes('Img2Img')) {
            modifier = ' sublabel-tag--img2img';
          } else if (lbl === 'Alpha Channel') {
            modifier = ' sublabel-tag--alpha-channel';
          } else {
            modifier = ' sublabel-tag--muted';
          }
          const span = document.createElement('span');
          span.className = `sublabel-tag${modifier}`;
          span.textContent = `[${lbl}]`;
          secEl.subLabel.appendChild(span);
        });
      } else {
        secEl.subLabel.replaceChildren();
        secEl.subLabel.className = '';
      }

      if (secEl.root.parentNode !== container) {
        container.appendChild(secEl.root);
      }
    }

    if (!hasContent) {
      const rawMetaStr = JSON.stringify(meta, null, 2);
      if (rawMetaStr !== '{}' && rawMetaStr !== 'null') {
        const secEl = getInspectorSection();
        secEl.title.textContent = '未対応のメタデータ形式';
        secEl.copyWrapper.replaceChildren();
        secEl.subLabel.textContent = '';
        secEl.box.className = 'prompt-look raw-box';
        secEl.box.style.cssText = '';
        secEl.box.textContent = rawMetaStr;
        if (secEl.root.parentNode !== container) container.appendChild(secEl.root);
        hasContent = true;
      }
    }

    let spacer = document.getElementById('inspector-bottom-spacer');
    if (!spacer) {
      spacer = document.createElement('div');
      spacer.id = 'inspector-bottom-spacer';
      spacer.className = 'inspector-bottom-spacer';
    }
    if (hasContent) {
      spacer.style.display = 'block';
      container.appendChild(spacer);
    } else {
      spacer.style.display = 'none';
    }

    initInspectorDelegation(options);
  } catch (error) {
    if (container) {
      container.innerHTML = `<div class="render-error-box">描画エラー: ${error.message}</div>`;
    }
  }
}
