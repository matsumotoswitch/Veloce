const invoke = window.__TAURI__.invoke || (window.__TAURI__.tauri && window.__TAURI__.tauri.invoke) || (window.__TAURI__.core && window.__TAURI__.core.invoke);
const convertFileSrc = window.__TAURI__.convertFileSrc || (window.__TAURI__.tauri && window.__TAURI__.tauri.convertFileSrc) || (window.__TAURI__.core && window.__TAURI__.core.convertFileSrc);
const listen = (window.__TAURI__.event && window.__TAURI__.event.listen) || (window.__TAURI__.tauri && window.__TAURI__.tauri.listen) || (window.__TAURI__.core && window.__TAURI__.core.listen);
const tauriWindow = window.__TAURI__.window || {};
const appWindow = tauriWindow.appWindow || (tauriWindow.getCurrentWindow ? tauriWindow.getCurrentWindow() : null);
const { LogicalSize, LogicalPosition } = tauriWindow;

/**
 * @typedef {Object} VeloceAPI
 * @property {() => Promise<string[]>} getDrives
 * @property {(path: string) => Promise<boolean>} pathExists
 * @property {(path: string) => Promise<void>} loadDirectory
 * @property {(callback: (payload: {path: string, totalCount: number}) => void) => void} onDirectoryLoaded
 * @property {() => void} onSmartFolderPurged
 * @property {(callback: (payload: {processed: number, total: number}) => void) => void} onMetadataBatchUpdated
 * @property {(sortKey: string, asc: boolean, searchQuery: string) => Promise<number>} setViewParams
 * @property {() => Promise<Object<string, number>>} getAllRatings
 * @property {(ratings: Object<string, number>) => Promise<void>} migrateRatings
 * @property {() => Promise<Object<string, number>>} getSmartFolderCounts
 * @property {(offset: number, limit: number) => Promise<Array<import('./renderer-state.js').ImageFile>>} getItems
 * @property {(index: number) => Promise<import('./renderer-state.js').ImageFile|null>} getFileByIndex
 * @property {(updates: any[]) => Promise<void>} updateMetadataInState
 * @property {(path: string, width: number, height: number) => Promise<void>} updateFileDimensions
 * @property {(file: import('./renderer-state.js').ImageFile) => Promise<number>} notifyFileChanged
 * @property {(path: string) => Promise<number>} notifyFileRemoved
 * @property {(dirPath: string) => Promise<Array<{name: string, path: string}>>} getFolders
 * @property {(filePaths: string[]) => Promise<any[]>} getFullMetadataBatch
 * @property {(filePath: string) => Promise<string>} getThumbnail
 * @property {(filePath: string) => Promise<any>} parseMetadata
 * @property {(index: number) => Promise<{path: string, total: number}>} getViewerImage
 * @property {(data: {currentIndex: number, width: number, height: number, monitorWidth: number, monitorHeight: number}) => Promise<void>} openViewer
 * @property {() => Promise<boolean>} isViewerMaximized
 * @property {() => Promise<boolean>} isViewerFullscreen
 * @property {() => Promise<void>} toggleViewerFullscreen
 * @property {() => Promise<void>} minimizeViewer
 * @property {() => Promise<void>} maximizeViewer
 * @property {(width: number, height: number) => Promise<void>} resizeViewerWindow
 * @property {(width: number, height: number) => Promise<void>} setWindowSize
 * @property {() => Promise<void>} startViewerDragging
 * @property {(x: number, y: number) => Promise<void>} moveViewerWindow
 * @property {(filePath: string) => Promise<void>} copyImageToClipboard
 * @property {(filePath: string) => Promise<boolean>} trashFile
 * @property {(callback: (payload: any) => void) => void} onFileChanged
 * @property {(callback: (payload: string) => void) => void} onFileRemoved
 * @property {(callback: () => void) => void} onDirectoryChanged
 * @property {(callback: (payload: {path: string, rating: number}) => void) => void} onRatingChanged
 * @property {(parentDir: string, folderName: string) => Promise<{success: boolean, path?: string, error?: string}>} createFolder
 * @property {(oldPath: string, newName: string) => Promise<{success: boolean, path?: string, error?: string}>} renameFolder
 * @property {(oldPath: string, newName: string) => Promise<{success: boolean, path?: string, error?: string}>} renameFile
 * @property {(oldPath: string, newPath: string) => Promise<void>} syncFileMove
 * @property {(folderPath: string) => Promise<{success: boolean, error?: string}>} trashFolder
 * @property {(sourcePath: string, targetDir: string, intent?: 'auto'|'copy'|'move') => Promise<{success: boolean, action: string, reason: string|null}>} moveOrCopyFile
 * @property {(paths: string[], destDir: string) => Promise<string[]>} checkConflicts
 * @property {(filePath: string) => string} convertFileSrc
 * @property {() => void} toggleDevtools
 * @property {() => void} closeWindow
 * @property {() => Promise<void>} arrangeViewers
 * @property {() => void} focusWindow
 * @property {() => Promise<void>} showWindow
 * @property {() => Promise<string>} getLicenseText
 * @property {() => Promise<void>} openCacheFolder
 * @property {() => Promise<void>} clearCache
 * @property {() => Promise<{path: string, fileCount: number, totalSizeBytes: number}>} getCacheInfo
 * @property {() => Promise<void>} openInExplorer
 * @property {() => Promise<number>} getVideoServerPort
 * @property {() => Promise<string>} getVideoServerToken
 * @property {(filePath: string) => Promise<{data_url: string, width: number, height: number, header_bytes: number, payload_bytes: number, total_bytes: number, total_pixels: number, image_total_pixels: number, coverage_percent: number, occupied_columns: number}|null>} getAlphaOverlayImage
 */
/**
 * @description
 * フロントエンド（Webページ）とTauriバックエンド（Rust）間の通信を確立します。
 * @type {VeloceAPI}
 */
window.veloceAPI = {
  getAlphaOverlayImage: (filePath) => invoke('get_alpha_overlay_image', { filePath }),
  updateSmartFolders: (rules) => invoke('update_smart_folders', { rules }),
  /**
   * 利用可能なドライブ文字（またはルートディレクトリ）のリストを取得します。
   * @returns {Promise<Array<string>>} ドライブパスの配列
   */
  getDrives: () => invoke('get_drives'),
  /**
   * 指定されたパスのフォルダが存在するかを確認します。
   * @param {string} path - 確認するディレクトリのパス。
   * @returns {Promise<boolean>}
   */
  pathExists: (path) => invoke('path_exists', { path }),
  /**
   * 指定されたパスのディレクトリのプログレッシブ読み込みを開始します。
   * 結果は onDirectoryChunk イベントで受信します。
   * @param {string} path - 読み込むディレクトリのパス。
   * @returns {Promise<void>}
   */
  loadDirectory: (path) => invoke('load_directory', { targetPath: path }),
  /**
   * ディレクトリ読み込み完了時に件数のみを受信する新イベント
   */
  onDirectoryLoaded: (callback) => listen('directory-loaded', (event) => callback(event.payload)),
  onSmartFolderPurged: (callback) => listen('smart-folder-purged', () => callback()),
  onRatingsLoaded: (callback) => listen('ratings-loaded', (event) => callback(event.payload)),
  onMetadataBatchUpdated: (callback) => listen('metadata-batch-updated', (event) => callback(event.payload)),
  /**
   * Rust側でソート・検索を実行し、フィルタリング後の件数とパス一覧を返す
   */
  setViewParams: (sortKey, asc, searchQuery, ratingFilterVal = 0, ratingFilterOp = 'gte') => invoke('set_view_params', { sortKey, asc, searchQuery, ratingFilterVal, ratingFilterOp }),
  syncRatings: (ratings) => invoke('sync_ratings', { ratings }),
  getAllRatings: () => invoke('get_all_ratings'),
  updateSmartFolder: (rule) => invoke('update_smart_folder', { rule }),
  deleteSmartFolder: (id) => invoke('delete_smart_folder', { id }),
  getSmartFolderCounts: (rules) => invoke('get_smart_folder_counts', { rules }),
  migrateRatings: (ratings) => invoke('migrate_ratings', { ratings }),
  getVideoServerPort: () => invoke('get_video_server_port'),
  getVideoServerToken: () => invoke('get_video_server_token'),
  setRating: (path, rating) => invoke('set_rating', { path, rating }),
  initSettings: (entriesFromLocalstorage) => invoke('init_settings', { entriesFromLocalstorage }),
  getSetting: (key) => invoke('get_setting', { key }),
  setSetting: (key, value) => invoke('set_setting', { key, value }),
  setSettingsBatch: (settings) => invoke('set_settings_batch', { settings }),
  deleteSetting: (key) => invoke('delete_setting', { key }),
  getAllSettings: () => invoke('get_all_settings'),
  /**
   * 仮想スクロール用: 指定範囲のImageFileをRustから取得する
   */
  getItems: (offset, limit) => invoke('get_items', { offset, limit }),
  /**
   * selectImage用: 指定インデックスの単一ImageFileを取得
   */
  getFileByIndex: (index) => invoke('get_file_by_index', { index }),
  getFilesByIndices: (indices) => invoke('get_files_by_indices', { indices }),
  getVideoThumbnail: (path) => invoke('get_video_thumbnail', { path }),
  /**
   * メタデータの読み込み結果をRust側のSource of Truthに反映する
   */
  updateMetadataInState: (updates) => invoke('update_metadata_in_state', { updates }),
  /**
   * サムネイル生成やメタデータ解析で判明した画像の幅・高さをRust側に通知する
   * @param {string} path - 画像ファイルのパス。
   * @param {number} width - 画像の幅。
   * @param {number} height - 画像の高さ。
   * @returns {Promise<void>}
   */
  updateFileDimensions: (path, width, height) => invoke('update_file_dimensions', { path, width, height }),
  /**
   * ファイルウォッチャーから通知されたファイル変更をRust側に通知する
   */
  notifyFileChanged: (file) => invoke('notify_file_changed', { file }),
  /**
   * ファイルウォッチャーから通知されたファイル削除をRust側に通知する
   */
  notifyFileRemoved: (path) => invoke('notify_file_removed', { path }),
  notifyFilesBatch: (changedFiles, removedPaths) => invoke('notify_files_batch', { changedFiles, removedPaths }),
  /**
   * 指定されたパス内のサブフォルダのリストを取得します。
   * @param {string} path - 調査するディレクトリのパス。
   * @returns {Promise<Array<object>>} サブフォルダ情報のリスト。
   */
  getFolders: async (dirPath) => {
    const { fs } = window.__TAURI__;
    try {
      const entries = await fs.readDir(dirPath);
      // Tauri v1では、ディレクトリの場合のみ children プロパティが（空でも）付与されます
      const folders = entries
        .filter(entry => entry.children !== undefined)
        .map(entry => ({ name: entry.name, path: entry.path }));
      
      folders.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
      return folders;
    } catch (error) {
      console.warn("Failed to get folders:", error);
      return [];
    }
  },
  /**
   * 複数の画像ファイルのメタデータ（プロンプト、幅・高さなど）を一括で取得します。
   * @param {string[]} filePaths - 解析する画像ファイルパスの配列。
   * @returns {Promise<Array<object>>} 各ファイルのパスとメタデータ（幅・高さなど）を含むオブジェクトの配列。
   */
  getFullMetadataBatch: (filePaths) => invoke('get_full_metadata_batch', { filePaths }),
  /**
   * 指定された画像パスから軽量なサムネイル画像を生成して取得します。
   * @param {string} filePath - オリジナル画像のパス。
   * @returns {Promise<string>} サムネイル画像（またはフォールバック画像）のローカルAsset URL。
   */
  getThumbnail: async (filePath) => {
    try {
      return await invoke('generate_thumbnail', { filePath });
    } catch (e) {
      console.warn("Failed to generate thumbnail via command:", e);
      return window.__TAURI__.tauri.convertFileSrc(filePath);
    }
  },
  saveThumbnail: (filePath, b64Data) => invoke('save_thumbnail', { filePath, b64Data }),
  generateThumbnailBatch: (filePaths) => invoke('generate_thumbnail_batch', { filePaths }),
  readBinaryFile: (filePath) => window.__TAURI__.fs.readBinaryFile(filePath),
  /**
   * 画像ファイルからプロンプトなどのメタデータを解析します。
   * @param {string} filePath - 解析する画像ファイルのパス。
   * @returns {Promise<object>} 抽出されたメタデータ。
   */
  parseMetadata: (filePath) => invoke('parse_metadata', { filePath }),
  /**
   * Rust側のStateから現在選択されている画像情報を取得します。
   * @param {number} index - 画像のインデックス
   * @returns {Promise<object>} { path: string, total: number }
   */
  getViewerImage: (index) => invoke('get_viewer_image', { index }),
  /**
   * 画像ビューアウィンドウを開くようメインプロセスに要求します。
   * @param {object} data - { currentIndex: number, width: number, height: number }
   */
  openViewer: (data) => invoke('open_viewer', data),
  /**
   * 現在のウィンドウが最大化されているかを取得します。
   */
  isViewerMaximized: () => appWindow.isMaximized(),
  /**
   * 現在のウィンドウがフルスクリーンかを取得します。
   */
  isViewerFullscreen: () => appWindow.isFullscreen(),
  /**
   * ビューアウィンドウのフルスクリーン状態をトグルするようメインプロセスに要求します。
   */
  toggleViewerFullscreen: async () => {
    const isFs = await appWindow.isFullscreen();
    return appWindow.setFullscreen(!isFs);
  },
  /**
   * ビューアウィンドウを最小化するようメインプロセスに要求します。
   */
  minimizeViewer: () => appWindow.minimize(),
  /**
   * ビューアウィンドウを最大化するようメインプロセスに要求します。
   */
  maximizeViewer: async () => {
    const isMax = await appWindow.isMaximized();
    if (isMax) {
      await appWindow.unmaximize();
    } else {
      await appWindow.maximize();
    }
  },
  /**
   * ビューアウィンドウのサイズを変更するようメインプロセスに要求します。
   * @param {number} width - 変更後の幅。
   * @param {number} height - 変更後の高さ。
   */
  resizeViewerWindow: (width, height) => appWindow.setSize(new LogicalSize(width, height)),
  /**
   * ビューアウィンドウのサイズを変更するようメインプロセスに要求します。
   * @param {number} width - 変更後の幅。
   * @param {number} height - 変更後の高さ。
   */
  setWindowSize: async (width, height) => {
    if (window.__TAURI__ && window.__TAURI__.window) {
      const { appWindow, LogicalSize } = window.__TAURI__.window;
      await appWindow.setSize(new LogicalSize(width, height));
    }
  },
  /**
   * ビューアウィンドウのドラッグ移動をOSネイティブに委譲します。
   */
  startViewerDragging: () => appWindow.startDragging(),
  /**
   * ビューアウィンドウを移動するようメインプロセスに要求します。
   * @param {number} x - 移動先の画面X座標。
   * @param {number} y - 移動先の画面Y座標。
   */
  moveViewerWindow: (x, y) => appWindow.setPosition(new LogicalPosition(x, y)),
  /**
   * 画像をクリップボードにコピーするようメインプロセスに要求します。
   * @param {string} filePath - コピーする画像ファイルのパス。
   */
  copyImageToClipboard: (filePath) => invoke('copy_image_to_clipboard', { filePath }),
  /**
   * ファイルをゴミ箱に移動するようメインプロセスに要求します。
   * @param {string} filePath - ゴミ箱に移動するファイルのパス。
   * @returns {Promise<boolean>} 成功したかどうか。
   */
  trashFile: (filePath) => invoke('trash_file', { filePath }),
  /**
   * ファイルが追加または更新されたときの通知を受け取ります。
   */
  onFileChanged: (callback) => listen('file-changed', (event) => callback(event.payload)),
  /**
   * ファイルが削除されたときの通知を受け取ります。
   */
  onFileRemoved: (callback) => listen('file-removed', (event) => callback(event.payload)),
  /**
   * ディレクトリ構造が変更された（フォルダの作成・削除・リネーム）ときの通知を受け取ります。
   */
  onDirectoryChanged: (callback) => listen('directory-changed', () => callback()),
  /**
   * レーティングが変更されたときの通知を受け取ります。
   */
  onRatingChanged: (callback) => listen('rating-changed', (event) => callback(event.payload)),
  /**
   * フォルダを作成するようメインプロセスに要求します。
   * @param {string} parentDir - 親ディレクトリのパス。
   * @param {string} folderName - 新しいフォルダ名。
   */
  createFolder: async (parentDir, folderName) => {
    const { fs, path } = window.__TAURI__;
    try {
      const newPath = await path.join(parentDir, folderName);
      await fs.createDir(newPath);
      return { success: true, path: newPath };
    } catch (error) {
      return { success: false, error: String(error) };
    }
  },
  /**
   * フォルダ名を変更するようメインプロセスに要求します。
   * @param {string} oldPath - 変更前のフォルダのパス。
   * @param {string} newName - 新しいフォルダ名。
   */
  renameFolder: async (oldPath, newName) => {
    try {
      const newPath = await invoke('rename_folder', { oldPath, newName });
      return { success: true, path: newPath };
    } catch (error) {
      return { success: false, error: String(error) };
    }
  },
  /**
   * ファイル名を変更するようメインプロセスに要求します。
   * @param {string} oldPath - 変更前のファイルのパス。
   * @param {string} newName - 新しいファイル名。
   */
  renameFile: async (oldPath, newName) => {
    try {
      const newPath = await invoke('rename_file', { oldPath, newName });
      return { success: true, path: newPath };
    } catch (error) {
      return { success: false, error: String(error) };
    }
  },
  /**
   * フォルダをゴミ箱に移動するようメインプロセスに要求します。
   * @param {string} folderPath - 削除するフォルダのパス。
   */
  trashFolder: (folderPath) => invoke('trash_folder', { folderPath }),
  /**
   * ファイル移動に伴い、SQLite キャッシュおよびレーティングのパスを引き継ぎます。
   * @param {string} oldPath - 移動前のファイルパス。
   * @param {string} newPath - 移動後のファイルパス。
   * @returns {Promise<void>}
   */
  syncFileMove: (oldPath, newPath) => invoke('sync_file_move', { oldPath, newPath }),
  /**
   * ファイルを指定ディレクトリに移動またはコピーします。
   * @param {string} sourcePath - 元のファイルパス。
   * @param {string} targetDir - ドロップ先のディレクトリパス。
   * @param {'auto' | 'copy' | 'move'} [intent='auto'] - 強制的に実行するアクション
   * @param {object} [options={}] - 追加オプション（{ overwrite: false } 指定時は競合検出で中断）
   * @returns {Promise<object>} 処理結果 { success, action, targetPath, reason }。
   */
  moveOrCopyFile: async (sourcePath, targetDir, intent = 'auto', options = {}) => {
    const { fs, path } = window.__TAURI__;
    try {
      const fileName = await path.basename(sourcePath);
      const targetPath = await path.join(targetDir, fileName);
      const sourceDir = await path.dirname(sourcePath);

      if (sourceDir === targetDir) {
        return { success: false, action: '', reason: 'same_directory' };
      }

      if (options && options.overwrite === false) {
        const conflicts = await invoke('check_conflicts', { paths: [sourcePath], destDir: targetDir });
        if (Array.isArray(conflicts) && conflicts.length > 0) {
          return { success: false, action: '', reason: 'conflict' };
        }
      }

      let action = intent;
      if (action === 'auto') {
        const getRoot = p => p.match(/^[A-Za-z]:/) ? p.match(/^[A-Za-z]:/)[0].toLowerCase() : '/';
        action = getRoot(sourcePath) === getRoot(targetDir) ? 'move' : 'copy';
      }

      if (action === 'copy') {
        await fs.copyFile(sourcePath, targetPath);
      } else {
        let movedByFallback = false;
        try {
          await fs.renameFile(sourcePath, targetPath);
        } catch (e) {
          // 別ドライブ間への移動など、renameFileが失敗した際のフォールバック
          await fs.copyFile(sourcePath, targetPath);
          movedByFallback = true;
        }
        // 移動成功時（またはフォールバックのコピー完了直後）、元ファイル削除や trash_file より先に
        // SQLite のキャッシュおよびレーティングのパスをアトミックに同期してレーティング消失を防ぐ
        try {
          await invoke('sync_file_move', { oldPath: sourcePath, newPath: targetPath });
        } catch (syncErr) {
          console.error('Failed to sync file move in DB:', syncErr);
        }
        if (movedByFallback) {
          try {
            await fs.removeFile(sourcePath);
          } catch (rmErr) {
            // removeFileも失敗した場合は invoke('trash_file') でゴミ箱送りを試みる
            await invoke('trash_file', { filePath: sourcePath });
          }
        }
      }
      return { success: true, action, targetPath, reason: null };
    } catch (error) {
      return { success: false, action: '', reason: String(error) };
    }
  },
  /**
   * 宛先ディレクトリに同名ファイルが存在するかをチェックします。
   * @param {string[]} paths - 移動/コピーするファイルのパス配列。
   * @param {string} destDir - 宛先ディレクトリのパス。
   * @returns {Promise<string[]>} 重複しているファイルパスの配列。
   */
  checkConflicts: (paths, destDir) => invoke('check_conflicts', { paths, destDir }),
  /**
   * ローカルファイルパスをTauriのAssetプロトコルURLに変換します。
   * @param {string} filePath - ローカルファイルのパス
   * @returns {string} 変換されたURL
   */
  convertFileSrc: (filePath) => convertFileSrc(filePath),
  /**
   * 開発者ツールをトグル表示します（デバッグビルド時のみ有効）
   */
  toggleDevtools: () => { /* 完全に無効化 */ },
  /**
   * ウィンドウを安全に閉じます。
   */
  closeWindow: async () => {
    try {
      await appWindow.setAlwaysOnTop(false);
    } catch (e) {}
    appWindow.close();
  },
  /**
   * 開いているすべてのビューアーウィンドウを横一列に並べます。
   */
  arrangeViewers: () => invoke('arrange_viewers'),
  /**
   * 現在のウィンドウにフォーカスを当てて最前面にします。
   */
  focusWindow: () => {
    if (appWindow && appWindow.setFocus) {
      appWindow.setFocus();
    }
    window.focus();
  },
  /**
   * Rust側にウィンドウの表示を要求します。
   */
  showWindow: () => invoke('show_window'),
  /**
   * ライセンス情報を取得します。
   */
  getLicenseText: () => invoke('get_license_text'),
  /**
   * キャッシュフォルダ（親ディレクトリ）をエクスプローラで開きます。
   */
  openCacheFolder: () => invoke('open_cache_folder'),
  /**
   * サムネイル・メタデータキャッシュをすべて削除します。
   */
  clearCache: () => invoke('clear_cache'),
  /**
   * キャッシュの情報を取得します。
   */
  getCacheInfo: () => invoke('get_cache_info'),
  /**
   * 指定したパスをエクスプローラで開きます。
   */
  openInExplorer: (path) => invoke('open_in_explorer', { path }),
  /**
   * メタデータキャッシュをクリア
   */
  clearMetadataCache: (filePaths) => invoke('clear_metadata_cache', { filePaths }),
  /**
   * フォルダ選択ダイアログを開きます。
   * @returns {Promise<string|null>} 選択されたフォルダパス
   */
  openFolderDialog: async () => {
    if (window.__TAURI__ && window.__TAURI__.dialog) {
      const selected = await window.__TAURI__.dialog.open({ directory: true, multiple: false });
      return selected ? String(selected) : null;
    }
    return null;
  },
  debugLog: (msg) => invoke('debug_log', { msg })
};
