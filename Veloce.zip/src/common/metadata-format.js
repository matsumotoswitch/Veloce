import { formatDurationSeconds } from './utils.js';

/**
 * メタデータの数値を表示用にフォーマットします。
 * @param {number|string|null|undefined} num
 * @returns {string|null}
 */
export function formatMetadataNumber(num) {
  if (num === null || num === undefined) return null;
  const n = Number(num);
  return !isNaN(n) ? n.toLocaleString() : num;
}

/**
 * 録音日時文字列を「yyyy/mm/dd hh:mm:ss」形式に整形します。
 * タイムゾーン指定がない文字列（ID3v2 TDRC 等）は記載値のまま整形し、
 * 年のみ等（月日情報がない形式）は元の値を維持します。
 * @param {string|null|undefined} raw
 * @returns {string|null}
 */
export function formatRecordingDate(raw) {
  if (raw === null || raw === undefined) return null;
  const trimmed = String(raw).trim();
  if (!trimmed) return null;

  if (/(?:Z|[+-]\d{2}:?\d{2})$/i.test(trimmed)) {
    const parsed = new Date(trimmed);
    if (!Number.isNaN(parsed.getTime())) {
      const yyyy = parsed.getFullYear();
      const mm = String(parsed.getMonth() + 1).padStart(2, '0');
      const dd = String(parsed.getDate()).padStart(2, '0');
      const hh = String(parsed.getHours()).padStart(2, '0');
      const mi = String(parsed.getMinutes()).padStart(2, '0');
      const ss = String(parsed.getSeconds()).padStart(2, '0');
      return `${yyyy}/${mm}/${dd} ${hh}:${mi}:${ss}`;
    }
  }

  const m = trimmed.match(
    /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[T\s](\d{1,2})(?::(\d{1,2})(?::(\d{1,2}))?)?)?/
  );
  if (m) {
    const yyyy = m[1];
    const mm = m[2].padStart(2, '0');
    const dd = m[3].padStart(2, '0');
    const hh = (m[4] || '0').padStart(2, '0');
    const mi = (m[5] || '0').padStart(2, '0');
    const ss = (m[6] || '0').padStart(2, '0');
    return `${yyyy}/${mm}/${dd} ${hh}:${mi}:${ss}`;
  }

  return trimmed;
}

export function formatRequestType(reqType) {
  if (!reqType) return null;
  const types = {
    'PromptGenerateRequest': 'Text to Image',
    'NativeInfillingRequest': 'Inpainting',
    'ImageToImageRequest': 'Image to Image',
    'Img2ImgRequest': 'Image to Image',
    'VibeTransferRequest': 'Vibe Transfer',
    'VibeTransfer': 'Vibe Transfer',
    'CharacterReference': 'Character Reference',
    'ImageToImage': 'Image to Image'
  };

  if (reqType.includes('+')) {
    return reqType.split('+').map(t => types[t] || t).join(' + ');
  }

  return types[reqType] || reqType;
}

/**
 * キャラクター配置座標リスト（centers / center / coords）を正規化して抽出します。
 * @param {Object} cp
 * @returns {Array<{x: number, y: number}>}
 */
export function parseCharacterCenters(cp) {
  if (!cp || typeof cp !== 'object') return [];
  const rawList = Array.isArray(cp.centers)
    ? cp.centers
    : (cp.center
      ? [cp.center]
      : (cp.coords
        ? (Array.isArray(cp.coords) ? cp.coords : [cp.coords])
        : []));

  const results = [];
  for (const item of rawList) {
    if (!item) continue;
    if (typeof item === 'object') {
      const x = Number(item.x !== undefined ? item.x : item[0]);
      const y = Number(item.y !== undefined ? item.y : item[1]);
      if (!isNaN(x) && !isNaN(y)) {
        results.push({ x, y });
      }
    }
  }
  return results;
}

/**
 * 画像ファイルとメタデータからインスペクター/Diff共通の構造を抽出します。
 * @param {object} file
 * @param {object} meta
 * @returns {object}
 */
export function extractMetadataFields(file, meta = {}) {
  const p = meta.params || {};
  let requestType = p.request_type || null;

  const isVibeTransfer = 
    (Array.isArray(p.reference_information_extracted_multiple) && p.reference_information_extracted_multiple.length > 0) ||
    (Array.isArray(p.reference_image_multiple) && p.reference_image_multiple.length > 0) ||
    (Array.isArray(p.reference_strength_multiple) && p.reference_strength_multiple.length > 0);

  const isCharacterReference = 
    (Array.isArray(p.director_reference_strengths) && p.director_reference_strengths.length > 0) ||
    (Array.isArray(p.director_reference_information_extracted) && p.director_reference_information_extracted.length > 0) ||
    (Array.isArray(p.director_reference_images) && p.director_reference_images.length > 0) ||
    (Array.isArray(p.director_reference_descriptions) && p.director_reference_descriptions.length > 0);

  let enhancements = [];
  if (isVibeTransfer) enhancements.push('VibeTransfer');
  if (isCharacterReference) enhancements.push('CharacterReference');

  if (enhancements.length > 0) {
    if (requestType === 'Img2ImgRequest' || requestType === 'ImageToImageRequest') {
      enhancements.push('ImageToImage');
    }
    requestType = enhancements.join('+');
  }

  // --- ComfyUI 解析 ---
  if (Array.isArray(p.nodes) && Array.isArray(p.links)) {
    return parseComfyUI(file, meta, p);
  }
  if (p && typeof p === 'object' && !Array.isArray(p.nodes) && Object.values(p).some(v => v && typeof v === 'object' && v.class_type)) {
    return parseComfyUIPromptFormat(file, meta, p);
  }

  // --- A1111 / Forge 解析 ---
  let a1111Candidate = p.rawParameters || p.Description || p.prompt || file.prompt || meta.prompt;
  if (typeof a1111Candidate === 'string') {
    // EXIFのUTF-16LE文字列がUTF-8としてパースされた際に混入するNULL文字（\0）を除去し、先頭の識別子（UNICODEなど）を消す
    a1111Candidate = a1111Candidate.replace(/\0/g, '').replace(/^(?:[^<A-Za-z0-9]*UNICODE[^<A-Za-z0-9]*)?/i, '').trim();
    if (a1111Candidate.includes('Steps:') && a1111Candidate.includes('Sampler:')) {
      const a1111P = { ...p, rawParameters: a1111Candidate };
      return parseA1111(file, meta, a1111P);
    }
  }
  const ap = (p && typeof p.actual_prompts === 'object') ? p.actual_prompts :
             ((p && typeof p.actualPrompts === 'object') ? p.actualPrompts : null);

  const currentPrompt = meta.prompt || file.prompt || '';
  let adoptedPrompt = null;
  const rawAdopted = p.adoptedPrompt || p.adopted_prompt ||
    (ap && typeof ap.prompt === 'string' ? ap.prompt : (ap && ap.prompt && typeof ap.prompt.base_caption === 'string' ? ap.prompt.base_caption : null)) ||
    (typeof p.prompt === 'string' ? p.prompt : null);

  if (rawAdopted && typeof rawAdopted === 'string') {
    const trimmedAdopted = rawAdopted.trim();
    const trimmedCurrent = currentPrompt.trim();
    if (trimmedAdopted && (trimmedAdopted !== trimmedCurrent || trimmedCurrent.includes('||'))) {
      adoptedPrompt = trimmedAdopted;
    }
  }

  const currentNegativePrompt = meta.negativePrompt || file.negativePrompt || '';
  let adoptedNegativePrompt = null;
  const rawAdoptedUc = p.adoptedNegativePrompt || p.adopted_negative_prompt ||
    (ap && typeof ap.negative_prompt === 'string' ? ap.negative_prompt : (ap && ap.negative_prompt && typeof ap.negative_prompt.base_caption === 'string' ? ap.negative_prompt.base_caption : null)) ||
    (typeof p.uc === 'string' && p.uc.trim() !== currentNegativePrompt.trim() ? p.uc : null);

  if (rawAdoptedUc && typeof rawAdoptedUc === 'string') {
    const trimmedAdoptedUc = rawAdoptedUc.trim();
    const trimmedCurrentUc = currentNegativePrompt.trim();
    if (trimmedAdoptedUc && (trimmedAdoptedUc !== trimmedCurrentUc || trimmedCurrentUc.includes('||'))) {
      adoptedNegativePrompt = trimmedAdoptedUc;
    }
  }

  const data = {
    name: file.name,
    source: meta.source || file.source || null,
    metadataSource: meta.metadataSource || meta.metadata_source || file.metadataSource || null,
    requestType: requestType,
    prompt: currentPrompt,
    adoptedPrompt: adoptedPrompt,
    negativePrompt: currentNegativePrompt,
    adoptedNegativePrompt: adoptedNegativePrompt,
    chars: [],
    params: {}
  };

  const apCharPrompts = (ap && ap.prompt && Array.isArray(ap.prompt.char_captions)) ? ap.prompt.char_captions : null;
  const apCharUcs = (ap && ap.negative_prompt && Array.isArray(ap.negative_prompt.char_captions)) ? ap.negative_prompt.char_captions : null;

  if (Array.isArray(p.characterPrompts)) {
    data.chars = p.characterPrompts.map((cp, idx) => {
      const cPrompt = cp.prompt || '';
      const cUc = cp.uc || '';

      let cAdopted = cp.adoptedPrompt || cp.adopted_prompt || null;
      if (!cAdopted && apCharPrompts && apCharPrompts[idx] && typeof apCharPrompts[idx].char_caption === 'string') {
        cAdopted = apCharPrompts[idx].char_caption;
      }
      if (cAdopted && (cAdopted.trim() === cPrompt.trim() && !cPrompt.includes('||'))) {
        cAdopted = null;
      } else if (cAdopted) {
        cAdopted = cAdopted.trim();
      }

      let cAdoptedUc = cp.adoptedUc || cp.adopted_uc || null;
      if (!cAdoptedUc && apCharUcs && apCharUcs[idx] && typeof apCharUcs[idx].char_caption === 'string') {
        cAdoptedUc = apCharUcs[idx].char_caption;
      }
      if (cAdoptedUc && (cAdoptedUc.trim() === cUc.trim() && !cUc.includes('||'))) {
        cAdoptedUc = null;
      } else if (cAdoptedUc) {
        cAdoptedUc = cAdoptedUc.trim();
      }

      return {
        prompt: cPrompt,
        adoptedPrompt: cAdopted,
        uc: cUc,
        adoptedUc: cAdoptedUc,
        centers: parseCharacterCenters(cp)
      };
    });
  } else if (Array.isArray(file.charPrompts)) {
    data.chars = file.charPrompts.map((cp, idx) => {
      const cPrompt = (cp && typeof cp === 'object' && cp.prompt) ? cp.prompt : String(cp || '');
      const cUc = (cp && typeof cp === 'object' && cp.uc) ? cp.uc : '';

      let cAdopted = (cp && typeof cp === 'object' && (cp.adoptedPrompt || cp.adopted_prompt)) ? (cp.adoptedPrompt || cp.adopted_prompt) : null;
      if (!cAdopted && apCharPrompts && apCharPrompts[idx] && typeof apCharPrompts[idx].char_caption === 'string') {
        cAdopted = apCharPrompts[idx].char_caption;
      }
      if (cAdopted && (cAdopted.trim() === cPrompt.trim() && !cPrompt.includes('||'))) {
        cAdopted = null;
      } else if (cAdopted) {
        cAdopted = cAdopted.trim();
      }

      let cAdoptedUc = (cp && typeof cp === 'object' && (cp.adoptedUc || cp.adopted_uc)) ? (cp.adoptedUc || cp.adopted_uc) : null;
      if (!cAdoptedUc && apCharUcs && apCharUcs[idx] && typeof apCharUcs[idx].char_caption === 'string') {
        cAdoptedUc = apCharUcs[idx].char_caption;
      }
      if (cAdoptedUc && (cAdoptedUc.trim() === cUc.trim() && !cUc.includes('||'))) {
        cAdoptedUc = null;
      } else if (cAdoptedUc) {
        cAdoptedUc = cAdoptedUc.trim();
      }

      return {
        prompt: cPrompt,
        adoptedPrompt: cAdopted,
        uc: cUc,
        adoptedUc: cAdoptedUc,
        centers: parseCharacterCenters(cp)
      };
    });
  }

  const charPositions = [];
  data.chars.forEach((c, i) => {
    if (c.centers && c.centers.length > 0) {
      charPositions.push({
        index: i + 1,
        centers: c.centers
      });
    }
  });
  data.charPositions = charPositions;

  const useCoords = (p && typeof p.use_coords === 'boolean') ? p.use_coords :
                    (meta && typeof meta.use_coords === 'boolean') ? meta.use_coords :
                    (file && typeof file.use_coords === 'boolean') ? file.use_coords :
                    (p && p.v4_prompt && typeof p.v4_prompt.use_coords === 'boolean') ? p.v4_prompt.use_coords : null;
  data.useCoords = useCoords;

  const w = p.width || meta.width || file.width;
  const h = p.height || meta.height || file.height;
  data.width = w;
  data.height = h;
  const res = (w && h) ? `${formatMetadataNumber(w)}x${formatMetadataNumber(h)}` : null;

  let sampler = p.sampler || file.sampler || null;
  if (sampler && sampler !== '-' && p.sm && !sampler.includes('karras')) {
    sampler += ' (karras)';
  }

  data.params = {
    title: p.title ?? null,
    artist: p.artist ?? null,
    album: p.album ?? null,
    lyrics: p.lyrics ?? null,
    comment: p.comment ?? null,
    recordingDate: formatRecordingDate(p.recordingDate),
    duration: p.duration ?? (typeof p.durationSecs === 'number' && p.durationSecs > 0 ? formatDurationSeconds(p.durationSecs) : null),
    resolution: res,
    seed: p.seed ?? file.seed ?? null,
    steps: formatMetadataNumber(p.steps ?? file.steps ?? null),
    sampler,
    scale: p.scale ?? file.scale ?? null,
    cfg_rescale: p.cfg_rescale ?? file.cfg_rescale ?? null,
    uncond_scale: p.uncond_scale ?? file.uncond_scale ?? null,
    rawParameters: p.rawParameters ?? file.rawParameters ?? null
  };

  data.width = w || null;
  data.height = h || null;

  return data;
}

/**
 * カンマ区切りプロンプトをタグ配列に分解します。
 * @param {string|null|undefined} text
 * @returns {string[]}
 */
export function parsePromptTags(text) {
  if (!text) return [];
  return String(text).split(/[,\n\r]+/).map(t => t.trim()).filter(Boolean);
}

/**
 * 検索語の配列からハイライト用の単一正規表現を生成します。
 * タグごとの重複コンパイルを排除し、パフォーマンスを最適化します。
 * @param {string[]} terms
 * @returns {RegExp|null}
 */
export function createSearchTermsRegex(terms) {
  if (!terms || !Array.isArray(terms) || terms.length === 0) return null;
  const validTerms = terms.map(t => String(t).trim()).filter(Boolean);
  if (validTerms.length === 0) return null;
  // 特殊文字をエスケープして正規表現パターンを構築
  const escaped = validTerms.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  try {
    return new RegExp(`(${escaped})`, 'gi');
  } catch (e) {
    return null;
  }
}

/**
 * 検索語を <mark> タグでハイライトします。
 * @param {string} text
 * @param {string[]|RegExp} termsOrRegex
 * @returns {string}
 */
export function highlightSearchTerms(text, termsOrRegex) {
  if (!text || !termsOrRegex) return text;
  const re = termsOrRegex instanceof RegExp ? termsOrRegex : createSearchTermsRegex(termsOrRegex);
  if (!re) return text;
  const escaped = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  re.lastIndex = 0;
  return escaped.replace(re, '<mark class="search-highlight">$1</mark>');
}

/**
 * インスペクター用のセクション定義をデータから生成します。
 * @param {ReturnType<typeof extractMetadataFields>} data
 * @returns {Array<{title: string, value: *, isParam?: boolean, isRaw?: boolean, isText?: boolean, isPosition?: boolean, copyable?: boolean}>}
 */
export function buildInspectorSections(data) {
  const sections = [
    { title: 'モデル / バージョン', value: data.source, isParam: true, subLabel: data.requestType ? formatRequestType(data.requestType) : null }
  ];

  const promptSubLabel = (data.metadataSource && data.metadataSource !== 'None') ? data.metadataSource : null;

  sections.push(
    { title: 'プロンプト', value: data.prompt, copyable: true, subLabel: promptSubLabel }
  );

  if (data.adoptedPrompt) {
    sections.push(
      { title: '採用プロンプト', value: data.adoptedPrompt, copyable: true }
    );
  }

  sections.push(
    { title: '除外したい要素', value: data.negativePrompt, copyable: true }
  );

  if (data.adoptedNegativePrompt) {
    sections.push(
      { title: '採用除外したい要素', value: data.adoptedNegativePrompt, copyable: true }
    );
  }

  data.chars.forEach((c, i) => {
    sections.push({ title: `キャラクター ${i + 1} プロンプト`, value: c.prompt, copyable: true });
    if (c.adoptedPrompt) {
      sections.push({ title: `キャラクター ${i + 1} 採用プロンプト`, value: c.adoptedPrompt, copyable: true });
    }
    sections.push({ title: `キャラクター ${i + 1} 除外したい要素`, value: c.uc, copyable: true });
    if (c.adoptedUc) {
      sections.push({ title: `キャラクター ${i + 1} 採用除外したい要素`, value: c.adoptedUc, copyable: true });
    }
  });

  if (data.params.title) {
    sections.push({ title: 'タイトル', value: data.params.title, isParam: true, copyable: true });
  }
  if (data.params.artist) {
    sections.push({ title: 'アーティスト', value: data.params.artist, isParam: true, copyable: true });
  }
  if (data.params.album) {
    sections.push({ title: 'アルバム', value: data.params.album, isParam: true, copyable: true });
  }
  if (data.params.duration) {
    sections.push({ title: '再生時間', value: data.params.duration, isParam: true });
  }
  if (data.params.recordingDate) {
    sections.push({ title: '録音日時', value: data.params.recordingDate, isParam: true });
  }
  if (data.params.comment) {
    sections.push({ title: 'コメント', value: data.params.comment, isText: true, copyable: true });
  }
  if (data.params.lyrics) {
    sections.push({ title: '歌詞', value: data.params.lyrics, isText: true, copyable: true });
  }

  sections.push(
    { title: '画像サイズ', value: data.params.resolution, isParam: true },
    { title: 'シード値', value: data.params.seed, isParam: true },
    { title: 'ステップ', value: data.params.steps, isParam: true },
    { title: 'サンプラー', value: data.params.sampler, isParam: true },
    { title: 'プロンプトガイダンス', value: data.params.scale, isParam: true },
    { title: 'プロンプトガイダンスの再調整', value: data.params.cfg_rescale, isParam: true },
    { title: '除外したい要素の強さ', value: data.params.uncond_scale, isParam: true },
    { title: '生成パラメータ (Raw)', value: data.params.rawParameters, isRaw: true }
  );

  // キャラクター位置指定データが存在する場合、各種パラメータの下に「位置」セクションを追加
  if (data.charPositions && data.charPositions.length > 0) {
    const isAuto = data.useCoords === false;
    const positionModeText = isAuto ? 'AIにおまかせ' : 'カスタム';

    sections.push({
      title: '位置',
      value: data.charPositions,
      isPosition: true,
      width: data.width,
      height: data.height,
      charPositions: data.charPositions,
      useCoords: data.useCoords,
      positionMode: positionModeText
    });
  }

  return sections;
}

/**
 * ComfyUIのメタデータを解析して標準のデータ構造にマッピングします。
 */
function parseComfyUI(file, meta, p) {
  const nodes = p.nodes || [];
  const links = p.links || [];

  const linkMap = {};
  for (const l of links) {
    if (!l) continue;
    linkMap[l[0]] = l;
  }

  const nodeMap = {};
  for (const n of nodes) {
    nodeMap[n.id] = n;
  }

  const samplers = nodes.filter(n => n.type && typeof n.type === 'string' && n.type.includes('KSampler'));
  const sampler = samplers[0];

  let positivePrompt = '';
  let negativePrompt = '';
  let width = null;
  let height = null;
  let seed = null;
  let steps = null;
  let samplerName = null;
  let cfg = null;
  let modelName = null;

  function traceLink(node, inputName) {
    if (!node || !node.inputs) return null;
    const input = node.inputs.find(i => i.name === inputName);
    if (!input || !input.link) return null;
    const link = linkMap[input.link];
    if (!link) return null;
    return nodeMap[link[1]];
  }

  function extractTextFromNode(node) {
    if (!node) return '';
    if (node.type === 'CLIPTextEncode') {
      return (node.widgets_values && node.widgets_values[0]) ? String(node.widgets_values[0]) : '';
    }
    if (node.type === 'IllustriousPromptBuilder') {
      if (node.widgets_values && node.widgets_values[0]) {
        try {
          const data = JSON.parse(node.widgets_values[0]);
          if (data && Array.isArray(data.rows)) {
            const groups = {};
            for (const row of data.rows) {
              if (row.enabled && row.prompt) {
                const cat = row.category || 'Other';
                if (!groups[cat]) groups[cat] = [];
                groups[cat].push(row.prompt.trim());
              }
            }
            let formatted = '';
            for (const cat in groups) {
              formatted += `[${cat}]\n${groups[cat].join('\n')}\n\n`;
            }
            if (formatted) return formatted.trim();
          }
        } catch (e) {
          // ignore parsing error, fallback to flat string
        }
      }
      return (node.widgets_values && node.widgets_values[1]) ? String(node.widgets_values[1]) : '';
    }
    return '';
  }

  if (sampler) {
    if (sampler.widgets_values && sampler.widgets_values.length >= 6) {
      const w = sampler.widgets_values;
      if (typeof w[0] === 'number') seed = w[0];
      for (let i = 1; i < w.length; i++) {
        if (typeof w[i] === 'number' && Number.isInteger(w[i]) && w[i] > 1) {
          steps = w[i];
          if (typeof w[i+1] === 'number') cfg = w[i+1];
          if (typeof w[i+2] === 'string') samplerName = w[i+2];
          if (typeof w[i+3] === 'string') samplerName += ' ' + w[i+3];
          break;
        }
      }
    }

    const posNode = traceLink(sampler, 'positive');
    positivePrompt = extractTextFromNode(posNode);
    
    const negNode = traceLink(sampler, 'negative');
    negativePrompt = extractTextFromNode(negNode);

    let latentNode = traceLink(sampler, 'latent_image');
    if (latentNode && latentNode.type === 'EmptyLatentImage') {
      if (latentNode.widgets_values && latentNode.widgets_values.length >= 2) {
        width = latentNode.widgets_values[0];
        height = latentNode.widgets_values[1];
      }
    }
  }

  if (!width || !height) {
    const latent = nodes.find(n => n.type === 'EmptyLatentImage');
    if (latent && latent.widgets_values) {
      width = latent.widgets_values[0];
      height = latent.widgets_values[1];
    }
  }
  
  if (!positivePrompt && !negativePrompt) {
    const clips = nodes.filter(n => n.type === 'CLIPTextEncode');
    if (clips.length > 0) {
      positivePrompt = clips[0].widgets_values ? clips[0].widgets_values[0] : '';
      if (clips.length > 1) {
        negativePrompt = clips[1].widgets_values ? clips[1].widgets_values[0] : '';
      }
    }
  }

  const w = width || meta.width || file.width;
  const h = height || meta.height || file.height;
  const res = (w && h) ? `${formatMetadataNumber(w)}x${formatMetadataNumber(h)}` : null;

  return {
    name: file.name,
    source: "ComfyUI",
    metadataSource: meta.metadataSource || meta.metadata_source || file.metadataSource || null,
    requestType: null,
    prompt: positivePrompt || '',
    negativePrompt: negativePrompt || '',
    chars: [],
    params: {
      resolution: res,
      seed: seed,
      steps: steps ? formatMetadataNumber(steps) : null,
      sampler: samplerName,
      cfg_rescale: cfg,
      scale: cfg,
      uncond_scale: null,
      rawParameters: JSON.stringify(p, null, 2)
    }
  };
}

/**
 * A1111 / Forge のメタデータを解析して標準のデータ構造にマッピングします。
 */
function parseA1111(file, meta, p) {
  const raw = p.rawParameters || '';
  
  let positivePrompt = '';
  let negativePrompt = '';
  const parsedParams = {};

  // "Steps:" が現れる最後の行を探す
  const lines = raw.split('\n');
  let paramLineIndex = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].includes('Steps:')) {
      paramLineIndex = i;
      break;
    }
  }

  if (paramLineIndex !== -1) {
    const paramLine = lines[paramLineIndex];
    // パラメータ行をパース (Key: Value形式)
    // 括弧付きの値やカンマが含まれる値もあるため、単純なsplit(',')ではダメな場合があるが、
    // 基本的な抽出は正規表現で行う
    const kvRegex = /([a-zA-Z0-9\s]+):\s*([^,]+(?:,\s*"[^"]+")[^,]*|[^,]+)/g;
    let match;
    while ((match = kvRegex.exec(paramLine)) !== null) {
      const key = match[1].trim();
      const val = match[2].trim();
      parsedParams[key] = val;
    }

    // ネガティブプロンプトとポジティブプロンプトの抽出
    let textBeforeParams = lines.slice(0, paramLineIndex).join('\n').trim();
    
    // "Negative prompt: " で分割
    const negIndex = textBeforeParams.indexOf('Negative prompt:');
    if (negIndex !== -1) {
      positivePrompt = textBeforeParams.substring(0, negIndex).trim();
      negativePrompt = textBeforeParams.substring(negIndex + 'Negative prompt:'.length).trim();
    } else {
      positivePrompt = textBeforeParams;
    }
  }

  let source = "A1111 / Forge";
  if (parsedParams['Model']) {
    source += ` (${parsedParams['Model']})`;
  }

  let resolutionStr = parsedParams['Size'] || null;
  if (resolutionStr && resolutionStr.includes('x')) {
    const parts = resolutionStr.split('x');
    if (parts.length === 2) {
      const w = parseInt(parts[0], 10);
      const h = parseInt(parts[1], 10);
      if (!isNaN(w) && !isNaN(h)) {
        resolutionStr = `${formatMetadataNumber(w)}x${formatMetadataNumber(h)}`;
      }
    }
  }
  if (!resolutionStr) {
    const w = meta.width || file.width;
    const h = meta.height || file.height;
    if (w && h) {
      resolutionStr = `${formatMetadataNumber(w)}x${formatMetadataNumber(h)}`;
    }
  }

  return {
    name: file.name,
    source: source,
    metadataSource: meta.metadataSource || meta.metadata_source || file.metadataSource || null,
    requestType: null,
    prompt: positivePrompt || '',
    negativePrompt: negativePrompt || '',
    chars: [],
    params: {
      resolution: resolutionStr,
      seed: parsedParams['Seed'] || null,
      steps: parsedParams['Steps'] ? formatMetadataNumber(parsedParams['Steps']) : null,
      sampler: parsedParams['Sampler'] || null,
      cfg_rescale: null,
      scale: parsedParams['CFG scale'] || null,
      uncond_scale: null,
      rawParameters: raw
    }
  };
}

function parseComfyUIPromptFormat(file, meta, p) {
  let positivePrompt = '';
  let negativePrompt = '';
  let seed = null;
  let steps = null;
  let samplerName = null;
  let cfg = null;
  let modelName = null;

  let sampler = null;
  for (const key in p) {
    if (p[key] && typeof p[key].class_type === 'string' && p[key].class_type.includes('KSampler')) {
      sampler = p[key];
      break;
    }
  }

  function extractTextFromNodeId(nodeId) {
    const node = p[nodeId];
    if (!node || !node.inputs) return '';
    if (node.class_type === 'CLIPTextEncode' || node.class_type === 'CLIPTextEncodeSDXL') {
      return (node.inputs.text || '').toString();
    }
    if (node.inputs.text) return node.inputs.text.toString();
    return '';
  }

  if (sampler && sampler.inputs) {
    if (sampler.inputs.seed !== undefined) seed = sampler.inputs.seed;
    if (sampler.inputs.noise_seed !== undefined) seed = sampler.inputs.noise_seed;
    if (sampler.inputs.steps !== undefined) steps = sampler.inputs.steps;
    if (sampler.inputs.cfg !== undefined) cfg = sampler.inputs.cfg;
    if (sampler.inputs.sampler_name !== undefined) samplerName = sampler.inputs.sampler_name;
    if (sampler.inputs.scheduler !== undefined) samplerName = (samplerName || '') + '_' + sampler.inputs.scheduler;

    if (sampler.inputs.positive && Array.isArray(sampler.inputs.positive)) {
      positivePrompt = extractTextFromNodeId(sampler.inputs.positive[0]);
    }
    if (sampler.inputs.negative && Array.isArray(sampler.inputs.negative)) {
      negativePrompt = extractTextFromNodeId(sampler.inputs.negative[0]);
    }
  } else {
    let foundText = [];
    for (const key in p) {
      if (p[key] && p[key].class_type && p[key].class_type.includes('CLIPTextEncode')) {
        if (p[key].inputs && p[key].inputs.text) foundText.push(p[key].inputs.text.toString());
      }
    }
    if (foundText.length > 0) positivePrompt = foundText[0];
    if (foundText.length > 1) negativePrompt = foundText[1];
  }

  const w = meta.width || file.width;
  const h = meta.height || file.height;
  const res = (w && h) ? `${formatMetadataNumber(w)}x${formatMetadataNumber(h)}` : null;

  return {
    name: file.name,
    source: "ComfyUI",
    metadataSource: meta.metadataSource || meta.metadata_source || file.metadataSource || null,
    requestType: null,
    prompt: positivePrompt || '',
    negativePrompt: negativePrompt || '',
    chars: [],
    params: {
      resolution: res,
      seed: seed,
      steps: steps ? formatMetadataNumber(steps) : null,
      sampler: samplerName,
      cfg_rescale: cfg,
      scale: cfg,
      model: modelName,
      rawParameters: JSON.stringify(p, null, 2)
    }
  };
}

