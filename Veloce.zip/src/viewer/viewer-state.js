/**
 * ビューア画面のデータと状態を管理するクラス
 */
class ViewerState {
  constructor() {
    this.currentIndex = 0;          // 現在表示中の画像のインデックス
    this.totalImages = 0;           // 全画像数
    this.paths = [];                // メイン画面から引き継いだ全画像パスの配列
    this.currentImagePath = '';     // 現在表示中の画像のパス
    this.isZoomed = false;          // 100%表示（ズーム）状態かどうか
    this.currentRotation = 0;       // 現在の回転角度（度）
    this.currentScale = 1.0;        // 現在のズーム倍率
    this.currentTranslateX = 0;     // X方向の移動量
    this.currentTranslateY = 0;     // Y方向の移動量
    this.flipX = 1;                 // 水平方向の反転状態 (1: 通常, -1: 反転)
    this.flipY = 1;                 // 垂直方向の反転状態 (1: 通常, -1: 反転)
    this.isImageDragging = false;   // 画像のパン（移動）ドラッグ中かどうか
    this.imageDragStartX = 0;       // パン操作の開始X座標
    this.imageDragStartY = 0;       // パン操作の開始Y座標
    this.isFitToWindow = false;     // ウィンドウサイズに強制フィット（拡大処理あり）させるかどうか
    this.isImmersiveArranged = false; // 整列表示時の没入（余白なしカバー）モード
    this.isFullscreen = false;      // フルスクリーン状態かどうか
    this.isBorderVisible = true;    // ウィンドウ枠を表示するかどうか
    this.isUnsharped = false;       // アンシャープマスクフィルターを適用するかどうか
    this.isMetadataVisible = false; // メタデータオーバーレイを表示するかどうか
    this.lastFocusTime = 0;         // ウィンドウが最後にフォーカスを取得した時刻
    this.ignoreNextClick = false;   // フォーカス目的のクリックを無視するためのフラグ
    this.preloadCache = new Map();  // 前後の画像のプリロードキャッシュ
    this.lastDirection = 1;         // 直近のナビゲーション進行方向 (1: 次へ/前進, -1: 前へ/後退)
    this.isAlphaOverlayMode = false; // アルファチャンネルオーバーレイ（メタデータ領域ハイブリッド）表示中か
    this.originalSrc = null;        // オーバーレイ適用前の元画像URL
    this.overlayCache = new Map();  // アルファオーバーレイ結果キャッシュ (path -> overlayResult)
  }
}

export const viewerState = new ViewerState();