// ============================================================================
// Veloce - Independent Image Viewer Controller (viewer.js)
// ============================================================================
// 本モジュールは、軽量・高速な独立画像ビューアーウィンドウの表示制御を担う。
//
// コア最適化アーキテクチャ:
// 1. Window Pool (ウィンドウの再利用):
//    ウィンドウ生成・破棄に伴うGCおよびWebView2初期化遅延を排除するため、
//    非表示状態で待機しているプールウィンドウを再利用し、'viewer-init-session' で初期化。
// 2. 二重バッファリング DOM Swap:
//    画像切り替え時の黒画面やチラつき（フリッカー）を防止するため、
//    次画像のデコード完了まで旧画像を表示し続け、完了と同時にO(1)でDOM置換。
// 3. 先行プリロード (Preload Pipeline):
//    前後画像のオフスクリーンImageオブジェクトをバックグラウンド生成し、
//    ページ送り時の遅延ゼロを実現。
// 4. SVGアンシャープマスクフィルター:
//    小数倍率ズーム時でもボケを抑制し、ディテールを保った鮮明なレンダリングを提供。
// ============================================================================

import { viewerState } from './viewer-state.js';
import { ViewerUI, viewerUI } from './viewer-ui.js';
import { debounce, blockDevtoolsShortcuts, getStreamUrl, applyGlowEffect, isVideoFile, isAudioFile, getAudioCoverUrl, AUDIO_PLACEHOLDER_URL, formatDurationSeconds } from '../common/utils.js';
import { extractMetadataFields, parsePromptTags, buildInspectorSections } from '../common/metadata-format.js';

blockDevtoolsShortcuts();

/**
 * ビューアー全体のテーマを適用します。
 * 'light' の場合は <html> に data-theme="light" を付与し、
 * 'dark' または未指定の場合は属性を削除して規定のダークモードを維持します。
 * @param {'dark'|'light'} [theme='dark']
 */
export function applyViewerTheme(theme) {
  if (theme === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
  } else {
    document.documentElement.removeAttribute('data-theme');
  }
}

// 起動時に同期的にテーマ属性を確定させ、初回描画時のスタイル再計算を防止する
const initialViewerTheme = (typeof window !== 'undefined' && window.SettingsStore
  ? window.SettingsStore.getItem('theme')
  : (typeof localStorage !== 'undefined' ? localStorage.getItem('theme') : null)) === 'light' ? 'light' : 'dark';
applyViewerTheme(initialViewerTheme);

let viewerRatings = {};

const CONFIG = {
  ZOOM_STEP: 1.1,         // マウスホイールでのズーム倍率
  MIN_ZOOM: 0.1,          // 最小ズーム倍率 (10%)
  MAX_ZOOM: 30.0,         // 最大ズーム倍率 (3000%)
  EDGE_THRESHOLD: 10,     // ウィンドウ端のリサイズ判定エリア(px)
  FOCUS_DELAY: 200,       // フォーカス時の誤クリック防止時間(ms)
  RESIZE_THROTTLE: 150    // リサイズイベントの間引き時間(ms)
};

const VIEWER_VOLUME_KEY = 'viewerVolume';
const VIEWER_MUTED_KEY = 'viewerMuted';

/**
 * SettingsStore（フォールバック時は localStorage）から設定値を読み込む
 * @param {string} key
 * @returns {string|null}
 */
function readViewerSetting(key) {
  if (typeof window !== 'undefined' && window.SettingsStore && typeof window.SettingsStore.getItem === 'function') {
    return window.SettingsStore.getItem(key);
  }
  if (typeof localStorage !== 'undefined') {
    return localStorage.getItem(key);
  }
  return null;
}

/**
 * SettingsStore（フォールバック時は localStorage）へ設定値を保存する
 * @param {string} key
 * @param {string} value
 */
function writeViewerSetting(key, value) {
  const strVal = String(value);
  if (typeof window !== 'undefined' && window.SettingsStore && typeof window.SettingsStore.setItem === 'function') {
    window.SettingsStore.setItem(key, strVal);
  } else if (typeof localStorage !== 'undefined') {
    localStorage.setItem(key, strVal);
  }
}

/**
 * 永続化された音量（0.0 〜 1.0、未設定時は 1.0）を取得する
 * @returns {number}
 */
export function getSavedViewerVolume() {
  const raw = readViewerSetting(VIEWER_VOLUME_KEY);
  if (raw === null || raw === undefined || raw === '') return 1;
  const num = parseFloat(raw);
  if (isNaN(num)) return 1;
  return Math.max(0, Math.min(1, num));
}

/**
 * 永続化されたミュート状態を取得する（未設定時は引数の既定値に従う）
 * @param {boolean} [defaultIfUnset=false]
 * @returns {boolean}
 */
export function getSavedViewerMuted(defaultIfUnset = false) {
  const raw = readViewerSetting(VIEWER_MUTED_KEY);
  if (raw === 'true') return true;
  if (raw === 'false') return false;
  return Boolean(defaultIfUnset);
}

/**
 * 対象メディア要素（<video> / <audio>）へ保存済みの音量・ミュート状態を適用する
 * @param {HTMLMediaElement} media
 * @param {boolean} [defaultMutedIfUnset=false]
 */
export function applyVolumeSettingsToMedia(media, defaultMutedIfUnset = false) {
  if (!media) return;
  try {
    media.volume = getSavedViewerVolume();
  } catch (e) {}
  media.muted = getSavedViewerMuted(defaultMutedIfUnset);
}

function isAudioPlaceholderMedia(media) {
  if (!media) return false;
  if (media.classList && media.classList.contains('audio-placeholder')) return true;
  if (typeof media.src === 'string' && media.src === AUDIO_PLACEHOLDER_URL) return true;
  if (media.dataset && media.dataset.audioPath) {
    const natW = media.naturalWidth || 0;
    const natH = media.naturalHeight || 0;
    if (natW === 0 || natH === 0) return true;
  }
  return false;
}

function getMediaWidth(media) {
  if (!media) return 1;
  if (isAudioPlaceholderMedia(media)) return 480;
  return media.tagName === 'VIDEO' ? (media.videoWidth || 1) : (media.naturalWidth || 1);
}

function getMediaHeight(media) {
  if (!media) return 1;
  if (isAudioPlaceholderMedia(media)) return 480;
  return media.tagName === 'VIDEO' ? (media.videoHeight || 1) : (media.naturalHeight || 1);
}

/**
 * 対象メディア要素でコントロールバーを既定表示すべきかを判定する
 * 音声ファイル（<audio>）では設定にかかわらず常時表示し、動画（<video>）は設定に従う
 * @param {HTMLMediaElement|null} media
 * @returns {boolean}
 */
function shouldShowSeekBarForMedia(media) {
  if (!isPlayableMedia(media)) return false;
  if (media.tagName === 'AUDIO') return true;
  return isDefaultSeekBarEnabled();
}

/**
 * ビューアー用の軽量トースト通知を表示します。
 * DOM要素の再利用と自動破棄を行い、メイン画面と同一のスタイルを適用します。
 * @param {string} message - 通知メッセージ (HTML文字列可)
 * @param {number} [duration=3000] - 表示時間 (ms)
 * @param {string} [type='info'] - トースト種別 ('info' | 'success' | 'warning' | 'error')
 */
export function showToast(message, duration = 3000, type = 'info', options = {}) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast-message ${type}`;
  if (options && options.isHtml === true && typeof message === 'string') {
    toast.innerHTML = message;
  } else {
    toast.textContent = message;
  }
  container.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  const hideTimeout = setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      if (toast.parentElement) toast.remove();
    }, 200);
  }, duration);

  return { toast, container, hideTimeout };
}

if (typeof window !== 'undefined') {
  window.showToast = showToast;
}

window.addEventListener('focus', () => {
  // <video> / <audio> 要素の内部操作（再生・一時停止等）がウィンドウ focus を誘発するケースがある。
  // これを「フォーカス目的クリック」と誤判定して ignoreNextClick を立てないよう、
  // activeElement が VIDEO または AUDIO の場合は lastFocusTime を更新しない。
  if (document.activeElement && (document.activeElement.tagName === 'VIDEO' || document.activeElement.tagName === 'AUDIO')) return;
  viewerState.lastFocusTime = Date.now();
});

let currentViewerImg = document.getElementById('viewer-img');
let currentlyVisibleImg = currentViewerImg;
let currentAudioElement = null;
if (currentViewerImg) currentViewerImg.classList.add('mode-default');

function isPlayableMedia(media) {
  return !!(media && (media.tagName === 'VIDEO' || media.tagName === 'AUDIO'));
}

/**
 * 現在ビューアで再生制御対象となるメディア要素（<audio> または <video>）を返す
 * @returns {HTMLMediaElement|null}
 */
export function getActivePlaybackMedia() {
  if (currentAudioElement && currentAudioElement.tagName === 'AUDIO') {
    return currentAudioElement;
  }
  const activeImg = (viewerUI && viewerUI.elements && viewerUI.elements.viewerImg) || document.getElementById('viewer-img');
  if (activeImg && activeImg.tagName === 'VIDEO') {
    return activeImg;
  }
  return null;
}

/**
 * 現在ビューアで音声ファイル（MP3）を表示中かを判定する
 * @returns {boolean}
 */
function isCurrentlyDisplayingAudio() {
  if (isAudioFile(viewerState.currentImagePath)) return true;
  if (currentAudioElement && currentAudioElement.tagName === 'AUDIO') return true;
  const imgEl = currentlyVisibleImg || currentViewerImg || (viewerUI && viewerUI.elements && viewerUI.elements.viewerImg);
  if (imgEl && imgEl.dataset && imgEl.dataset.audioPath) return true;
  return false;
}

/**
 * 現在ビューアで音声ファイル（MP3）のプレースホルダ（カバー画像なし／未ロード）を表示中かを判定する
 * カバー画像が登録されており正常にロード・表示されている場合は false を返す
 * @returns {boolean}
 */
function isCurrentlyDisplayingAudioPlaceholder() {
  if (!isCurrentlyDisplayingAudio()) return false;
  const imgEl = currentlyVisibleImg || currentViewerImg || (viewerUI && viewerUI.elements && viewerUI.elements.viewerImg) || document.getElementById('viewer-img');
  return isAudioPlaceholderMedia(imgEl);
}

/**
 * 現在再生対象のメディア（動画・音声）の音量を指定パーセント（±5等）増減させ、永続化・UI同期・トースト通知を行う
 * @param {number} deltaPercent - 増減パーセント（例: +5, -5）
 * @returns {boolean} 適用された場合は true
 */
function adjustActiveMediaVolumeByPercent(deltaPercent) {
  const activeMedia = getActivePlaybackMedia();
  if (!isPlayableMedia(activeMedia)) return false;

  const currentVol = (typeof activeMedia.volume === 'number' && !isNaN(activeMedia.volume))
    ? activeMedia.volume
    : getSavedViewerVolume();
  const currentMuted = (typeof activeMedia.muted === 'boolean')
    ? activeMedia.muted
    : getSavedViewerMuted(false);

  const nextPercent = Math.max(0, Math.min(100, Math.round(currentVol * 100) + deltaPercent));
  const nextVol = nextPercent / 100;

  if (deltaPercent > 0 && currentMuted) {
    writeViewerSetting(VIEWER_MUTED_KEY, 'false');
  }
  writeViewerSetting(VIEWER_VOLUME_KEY, String(nextVol));
  applyVolumeSettingsToMedia(activeMedia, currentMuted && deltaPercent <= 0);

  if (videoSeekBarContainer && typeof videoSeekBarContainer.updateVolumeControls === 'function') {
    videoSeekBarContainer.updateVolumeControls();
  }
  showToast(`音量 ${nextPercent}%`);
  return true;
}

/**
 * 現在再生対象のメディア（動画・音声）の再生位置を指定秒数（±5等）シークし、[0, duration] にクランプする
 * @param {number} deltaSeconds - シーク秒数（例: +5, -5）
 * @returns {boolean} シークが実行された場合は true
 */
function seekActiveMediaBySeconds(deltaSeconds) {
  const activeMedia = getActivePlaybackMedia();
  if (!isPlayableMedia(activeMedia)) return false;

  const duration = activeMedia.duration;
  if (typeof duration !== 'number' || !Number.isFinite(duration) || duration <= 0) {
    return false;
  }

  const current = (typeof activeMedia.currentTime === 'number' && Number.isFinite(activeMedia.currentTime))
    ? activeMedia.currentTime
    : 0;
  const nextTime = Math.max(0, Math.min(duration, current + deltaSeconds));
  activeMedia.currentTime = nextTime;

  if (videoSeekBarContainer && typeof videoSeekBarContainer.updateProgress === 'function') {
    videoSeekBarContainer.updateProgress();
  }
  return true;
}

/**
 * 再生中の音声要素（<audio>）を確実に停止・破棄し、音声残りやバックグラウンド再生を防ぐ
 */
export function stopAndDiscardAudio() {
  if (currentAudioElement) {
    try {
      currentAudioElement.pause();
      currentAudioElement.removeAttribute('src');
      if (typeof currentAudioElement.load === 'function') {
        currentAudioElement.load();
      }
    } catch (e) {}
    if (typeof currentAudioElement.remove === 'function') {
      currentAudioElement.remove();
    }
    currentAudioElement = null;
  }
}

/**
 * 音声ファイル（MP3）のカバー画像表示用 <img> 要素を生成する。
 * カバーが存在しない・読み込み失敗時は Lucide ベースのプレースホルダへ切り替える。
 * @param {string} filePath
 * @returns {HTMLImageElement}
 */
function createAudioCoverImageElement(filePath) {
  const img = document.createElement('img');
  img.decoding = 'async';
  img.dataset.audioPath = filePath;
  const coverUrl = getAudioCoverUrl(filePath);
  if (coverUrl) {
    img.addEventListener('error', () => {
      if (!img.classList.contains('audio-placeholder')) {
        img.classList.add('audio-placeholder');
        img.src = AUDIO_PLACEHOLDER_URL;
        if (img === currentlyVisibleImg) {
          img.addEventListener('load', () => {
            if (img === currentlyVisibleImg) {
              setZoomState(viewerState.isZoomed);
              viewerUI.updateImageRendering();
              resizeWindowToFitImage();
            }
          }, { once: true });
        }
      }
    }, { once: true });
    img.src = coverUrl;
  } else {
    img.classList.add('audio-placeholder');
    img.src = AUDIO_PLACEHOLDER_URL;
  }
  return img;
}

/**
 * プリロードキャッシュ内の全画像・動画リソースを確実に解放してキャッシュを消去
 */
function clearPreloadCache() {
  for (const cached of viewerState.preloadCache.values()) {
    if (cached && cached.img) {
      if (cached.img === currentlyVisibleImg || cached.img === currentViewerImg) {
        continue;
      }
      if (cached.img.tagName === 'VIDEO') {
        cached.img.pause();
        cached.img.removeAttribute('src');
        cached.img.load();
      }
      if (typeof cached.img.remove === 'function') cached.img.remove();
    }
  }
  viewerState.preloadCache.clear();
}

const COPY_ICON_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
let _lastCopiedOverlayTags = '';

/**
 * メタデータオーバーレイのDOM要素を生成または取得します。
 * @returns {HTMLElement}
 */
export function createMetadataOverlay() {
  let overlay = document.getElementById('viewer-metadata-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'viewer-metadata-overlay';
    overlay.className = 'viewer-metadata-overlay';

    const header = document.createElement('div');
    header.className = 'viewer-metadata-header';

    const title = document.createElement('span');
    title.className = 'viewer-metadata-title';
    title.textContent = 'メタデータ';

    header.appendChild(title);

    const content = document.createElement('div');
    content.id = 'viewer-metadata-content';
    content.className = 'viewer-metadata-content inspector-data';

    overlay.appendChild(header);
    overlay.appendChild(content);

    // 画像操作やドラッグへのイベント伝播を防止
    overlay.addEventListener('click', async (e) => {
      e.stopPropagation();

      // ドラッグ等によるテキスト選択が行われている場合は、個別タグクリックコピーを発火させない
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed && selection.toString().trim().length > 0) {
        return;
      }

      // セクション全体のコピーボタン処理
      const copyBtn = e.target.closest('.diff-copy-btn');
      if (copyBtn) {
        const text = copyBtn.getAttribute('data-copy-text');
        if (text) {
          await navigator.clipboard.writeText(text);
          showToast('クリップボードにコピーしました', 2000, 'success');
          applyGlowEffect(copyBtn);
        }
        return;
      }

      // 個別タグチップのクリックコピー処理（Ctrl+クリックで追加コピー）
      const tagEl = e.target.closest('.diff-tag');
      if (tagEl) {
        const text = tagEl.textContent;
        if (text) {
          let textToCopy = text;
          let isAppended = false;
          if (e.ctrlKey && _lastCopiedOverlayTags) {
            isAppended = true;
            const currentTags = _lastCopiedOverlayTags.split(',').map(t => t.trim()).filter(t => t);
            if (!currentTags.includes(text)) {
              textToCopy = _lastCopiedOverlayTags + ', ' + text;
            } else {
              textToCopy = _lastCopiedOverlayTags;
            }
          }
          _lastCopiedOverlayTags = textToCopy;
          await navigator.clipboard.writeText(textToCopy);
          const displayTxt = textToCopy.length > 20 ? textToCopy.substring(0, 20) + '...' : textToCopy;
          const prefix = isAppended ? '追加コピーしました: ' : 'コピーしました: ';
          showToast(`${prefix}${displayTxt}`, 2000, 'success');
          applyGlowEffect(tagEl);
        }
      }
    });

    /**
     * プロンプトボックス内のドラッグ選択コピー時のフォーマット調整:
     * メイン画面のインスペクター・Diff画面と同一の挙動とし、
     * タグ単位で選択されたテキストをカンマ区切りでクリップボードに格納する。
     */
    overlay.addEventListener('copy', (e) => {
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed) return;
      const promptLook = e.target.closest('.prompt-look');
      if (!promptLook) return;

      const clone = selection.getRangeAt(0).cloneContents();
      const tempDiv = document.createElement('div');
      tempDiv.appendChild(clone);
      const tags = tempDiv.querySelectorAll('.diff-tag');
      if (tags.length > 0) {
        tags.forEach(tag => { tag.textContent = tag.textContent + ", "; });
        let copiedText = tempDiv.textContent.replace(/,\s*$/, '').trim();
        e.clipboardData.setData('text/plain', copiedText);
        e.preventDefault();
      }
    });

    overlay.addEventListener('dblclick', (e) => e.stopPropagation());
    overlay.addEventListener('mousedown', (e) => e.stopPropagation());
    overlay.addEventListener('mouseup', (e) => e.stopPropagation());
    overlay.addEventListener('pointerdown', (e) => e.stopPropagation());
    overlay.addEventListener('wheel', (e) => e.stopPropagation(), { passive: true });

    document.body.appendChild(overlay);
  }
  return overlay;
}

/**
 * メイン画面のインスペクターと同一構造のセクションDOM要素を生成します。
 * @param {string} title
 * @param {*} value
 * @param {boolean} [isParam=false]
 * @param {boolean} [isRaw=false]
 * @param {string|null} [subLabel=null]
 * @returns {HTMLElement}
 */
function createInspectorSectionElement(title, value, isParam = false, isRaw = false, subLabel = null, isPosition = false, sectionObj = null, filePath = null) {
  const section = document.createElement('div');
  section.className = 'inspector-section inspector-section-block';

  const h3 = document.createElement('h3');
  h3.className = 'inspector-section-h3';

  const titleWrapper = document.createElement('span');
  titleWrapper.className = 'inspector-title-wrapper';

  const titleSpan = document.createElement('span');
  titleSpan.textContent = title;
  titleWrapper.appendChild(titleSpan);

  if (subLabel && subLabel !== 'Text to Image') {
    const subWrapper = document.createElement('span');
    subWrapper.className = 'sublabel-tags-wrapper';
    const labels = subLabel.split(' + ');
    labels.forEach(lbl => {
      let modifier = '';
      if (lbl.includes('Inpainting')) modifier = ' sublabel-tag--inpainting';
      else if (lbl.includes('Vibe Transfer')) modifier = ' sublabel-tag--vibe';
      else if (lbl.includes('Character Reference')) modifier = ' sublabel-tag--char-ref';
      else if (lbl.includes('Image to Image') || lbl.includes('Img2Img')) modifier = ' sublabel-tag--img2img';
      else if (lbl === 'Alpha Channel') modifier = ' sublabel-tag--alpha-channel';
      else modifier = ' sublabel-tag--muted';

      const span = document.createElement('span');
      span.className = `sublabel-tag${modifier}`;
      span.textContent = `[${lbl}]`;
      subWrapper.appendChild(span);
    });
    titleWrapper.appendChild(subWrapper);
  }

  h3.appendChild(titleWrapper);

  const isCopyable = !!sectionObj?.copyable;
  if (isCopyable) {
    const copyWrapper = document.createElement('div');
    copyWrapper.className = 'inspector-copy-wrapper';

    const copyBtn = document.createElement('span');
    copyBtn.className = 'diff-copy-btn';
    copyBtn.title = 'コピー';
    copyBtn.setAttribute('data-copy-text', typeof value === 'object' ? JSON.stringify(value) : String(value));
    copyBtn.innerHTML = COPY_ICON_SVG;
    copyWrapper.appendChild(copyBtn);

    h3.appendChild(copyWrapper);
  }

  section.appendChild(h3);

  const box = document.createElement('div');
  box.tabIndex = -1;

  if (isPosition && sectionObj && sectionObj.charPositions) {
    box.className = 'prompt-look inspector-position-block';

    // モード表示（四角い枠線なしのテキスト表示）
    const isAuto = sectionObj.positionMode === 'AIにおまかせ' || sectionObj.useCoords === false;
    const modeText = sectionObj.positionMode || (isAuto ? 'AIにおまかせ' : 'カスタム');
    const modeRow = document.createElement('div');
    modeRow.className = 'inspector-position-mode-row';
    const modeTag = document.createElement('span');
    modeTag.className = `inspector-position-mode-text ${isAuto ? 'inspector-position-mode--auto' : 'inspector-position-mode--custom'}`;
    modeTag.textContent = modeText;
    modeRow.appendChild(modeTag);
    box.appendChild(modeRow);

    // 「AIにおまかせ」の場合はその旨のみ表示し、画像や座標情報は表示しない
    if (!isAuto && sectionObj.charPositions && sectionObj.charPositions.length > 0) {
      const mapWrapper = document.createElement('div');
      mapWrapper.className = 'inspector-position-map-wrapper';

      const map = document.createElement('div');
      map.className = 'inspector-position-map';

      const imgWidth = sectionObj.width;
      const imgHeight = sectionObj.height;
      if (imgWidth && imgHeight) {
        map.style.aspectRatio = `${imgWidth} / ${imgHeight}`;
      }

      // 背景画像: 現在表示中のビューアー画像
      const currentImg = document.getElementById('viewer-img');
      const thumbUrl = (currentImg && currentImg.src) || (filePath && window.veloceAPI && window.veloceAPI.convertFileSrc(filePath)) || '';
      if (thumbUrl) {
        const bgImg = document.createElement('img');
        bgImg.className = 'inspector-position-bg-img';
        bgImg.src = thumbUrl;
        bgImg.onload = () => {
          if (bgImg.naturalWidth && bgImg.naturalHeight && (!sectionObj.width || !sectionObj.height)) {
            map.style.aspectRatio = `${bgImg.naturalWidth} / ${bgImg.naturalHeight}`;
          }
        };
        map.appendChild(bgImg);
      }

      const coordsContainer = document.createElement('div');
      coordsContainer.className = 'inspector-position-coords';

      sectionObj.charPositions.forEach((cp) => {
        const charNum = cp.index;
        const markerIndex = ((charNum - 1) % 8) + 1;
        const colorClass = `char-marker-${markerIndex}`;

        cp.centers.forEach((center) => {
          const marker = document.createElement('div');
          marker.className = `inspector-position-marker ${colorClass}`;
          marker.style.left = `${(center.x * 100).toFixed(2)}%`;
          marker.style.top = `${(center.y * 100).toFixed(2)}%`;
          marker.textContent = String(charNum);
          map.appendChild(marker);

          const coordItem = document.createElement('div');
          coordItem.className = 'inspector-coord-item';

          const badge = document.createElement('span');
          badge.className = `inspector-coord-badge ${colorClass}`;
          badge.textContent = String(charNum);

          const text = document.createElement('span');
          text.className = 'inspector-coord-text';
          const xPct = (center.x * 100).toFixed(1);
          const yPct = (center.y * 100).toFixed(1);
          text.textContent = `X: ${xPct}%, Y: ${yPct}% (${center.x.toFixed(3)}, ${center.y.toFixed(3)})`;

          coordItem.appendChild(badge);
          coordItem.appendChild(text);
          coordsContainer.appendChild(coordItem);
        });
      });

      mapWrapper.appendChild(map);
      box.appendChild(mapWrapper);
      box.appendChild(coordsContainer);
    }
  } else if (isRaw || (sectionObj && sectionObj.isText)) {
    box.className = (sectionObj && sectionObj.isText) ? 'prompt-look text-box' : 'prompt-look raw-box';
    box.textContent = String(value);
  } else if (isParam) {
    box.className = 'prompt-look param-box';
    box.textContent = String(value);
  } else {
    box.className = 'prompt-look';
    const tags = parsePromptTags(String(value));
    for (const t of tags) {
      const tag = document.createElement('span');
      tag.className = 'diff-tag common';
      tag.textContent = t;
      box.appendChild(tag);
    }
  }

  section.appendChild(box);
  return section;
}

let _metadataOverlayHideTimer = null;

/**
 * メタデータオーバーレイの表示/非表示をバウンス・ポップアニメーションとともに切り替えます。
 * @param {boolean} [forceState]
 */
export function toggleMetadataOverlay(forceState) {
  const newState = (typeof forceState === 'boolean') ? forceState : !viewerState.isMetadataVisible;
  viewerState.isMetadataVisible = newState;

  const overlay = createMetadataOverlay();
  const controls = document.getElementById('window-controls');

  if (viewerState.isMetadataVisible) {
    if (_metadataOverlayHideTimer) {
      clearTimeout(_metadataOverlayHideTimer);
      _metadataOverlayHideTimer = null;
    }
    document.body.classList.add('metadata-open');
    if (controls) controls.classList.add('metadata-open');

    overlay.classList.remove('prompt-hide');
    overlay.classList.add('show');
    // アニメーション再開のためのリフロー強制
    overlay.classList.remove('prompt-pop');
    void overlay.offsetWidth;
    overlay.classList.add('prompt-pop');

    updateMetadataOverlay();
  } else {
    document.body.classList.remove('metadata-open');
    if (controls) controls.classList.remove('metadata-open');

    const wasVisible = overlay.classList.contains('show');
    overlay.classList.remove('show');
    overlay.classList.remove('prompt-pop');

    if (wasVisible) {
      overlay.classList.remove('prompt-hide');
      void overlay.offsetWidth;
      overlay.classList.add('prompt-hide');

      if (_metadataOverlayHideTimer) clearTimeout(_metadataOverlayHideTimer);
      _metadataOverlayHideTimer = setTimeout(() => {
        overlay.classList.remove('prompt-hide');
        _metadataOverlayHideTimer = null;
      }, 220);
    } else {
      overlay.classList.remove('prompt-hide');
    }
  }
}

let currentMetadataSeq = 0;

/**
 * 現在表示中の画像のメタデータを取得し、オーバーレイに描画します。
 */
export async function updateMetadataOverlay() {
  if (!viewerState.isMetadataVisible) return;
  const overlay = createMetadataOverlay();
  const contentEl = document.getElementById('viewer-metadata-content');
  if (!contentEl) return;

  const filePath = viewerState.currentImagePath;
  if (!filePath) {
    contentEl.innerHTML = '<div class="viewer-meta-empty">画像が選択されていません</div>';
    return;
  }

  const seq = ++currentMetadataSeq;
  contentEl.innerHTML = '<div class="viewer-meta-loading">読み込み中...</div>';

  try {
    let rawMeta = null;
    if (window.veloceAPI && window.veloceAPI.parseMetadata) {
      rawMeta = await window.veloceAPI.parseMetadata(filePath);
    }
    if (seq !== currentMetadataSeq) return; // シーケンス不一致の破棄

    const meta = rawMeta || {};
    const filename = filePath.split(/[/\\]/).pop();
    const mediaEl = viewerUI.elements.viewerImg;
    const natW = mediaEl ? (mediaEl.naturalWidth || mediaEl.videoWidth || 0) : 0;
    const natH = mediaEl ? (mediaEl.naturalHeight || mediaEl.videoHeight || 0) : 0;

    const file = {
      path: filePath,
      name: filename,
      width: (meta.width && meta.width > 0) ? meta.width : natW,
      height: (meta.height && meta.height > 0) ? meta.height : natH
    };

    const data = extractMetadataFields(file, meta);
    const sections = buildInspectorSections(data);

    // 有効な値を持つセクションを抽出
    const visibleSections = sections.filter(s => s && s.value !== null && s.value !== undefined && s.value !== '' && s.value !== '-');

    if (visibleSections.length === 0) {
      contentEl.innerHTML = '<div class="viewer-meta-empty">メタデータが見つかりません</div>';
      return;
    }

    const fragment = document.createDocumentFragment();

    // 1. ファイル名セクション（メイン画面と同一形式）
    fragment.appendChild(createInspectorSectionElement('ファイル名', filename, true));

    // 2. メタデータ各セクション
    for (const sec of visibleSections) {
      fragment.appendChild(createInspectorSectionElement(
        sec.title,
        sec.value,
        !!sec.isParam,
        !!sec.isRaw,
        sec.subLabel || null,
        !!sec.isPosition,
        sec,
        filePath
      ));
    }

    const spacer = document.createElement('div');
    spacer.className = 'inspector-bottom-spacer';
    fragment.appendChild(spacer);

    contentEl.replaceChildren(fragment);
  } catch (err) {
    console.error('Failed to update metadata overlay:', err);
    if (seq !== currentMetadataSeq) return;
    contentEl.innerHTML = '<div class="viewer-meta-empty">メタデータの読み込みに失敗しました</div>';
  }
}

/**
 * 指定した画像要素にアルファチャンネルオーバーレイ（メタデータ領域ハイブリッド）を適用
 * @param {HTMLImageElement} imgEl - 対象の画像要素
 * @param {string} filePath - 画像ファイルパス
 * @param {boolean} [isAutoFollow=false] - 画像切り替え時の自動追従呼び出しフラグ
 */
export async function applyAlphaOverlay(imgEl, filePath, isAutoFollow = false) {
  if (!filePath || !window.veloceAPI || !window.veloceAPI.getAlphaOverlayImage) return;

  try {
    let result = viewerState.overlayCache.get(filePath);
    if (!result) {
      result = await window.veloceAPI.getAlphaOverlayImage(filePath);
      if (result) {
        viewerState.overlayCache.set(filePath, result);
      }
    }

    // 非同期通信完了時に表示中パスが変わっている、またはオーバーレイモードが解除されていたら適用を破棄
    if (viewerState.currentImagePath !== filePath || !viewerState.isAlphaOverlayMode) {
      return;
    }

    if (!result || !result.data_url) {
      if (!isAutoFollow) {
        if (viewerState.originalSrc && imgEl) {
          imgEl.src = viewerState.originalSrc;
          viewerState.originalSrc = null;
        }
        viewerState.isAlphaOverlayMode = false;
      }
      return;
    }

    // 元画像のsrcを退避（まだ未退避の場合のみ）
    if (!viewerState.originalSrc) {
      viewerState.originalSrc = imgEl.src;
    }

    imgEl.src = result.data_url;
    viewerState.isAlphaOverlayMode = true;
  } catch (err) {
    console.error('Failed to apply alpha overlay:', err);
    if (!isAutoFollow) {
      if (viewerState.originalSrc && imgEl) {
        imgEl.src = viewerState.originalSrc;
        viewerState.originalSrc = null;
      }
      viewerState.isAlphaOverlayMode = false;
    }
  }
}

/**
 * アルファチャンネルオーバーレイ（メタデータ領域ハイブリッド）のトグル切り替え
 * @param {HTMLImageElement} [customImgEl=null] - 任意の対象画像要素（未指定時は表示中要素を自動解決）
 */
export async function toggleAlphaOverlayMode(customImgEl = null) {
  if (isCurrentlyDisplayingAudio()) {
    return;
  }
  const imgEl = customImgEl || currentViewerImg || (viewerUI && viewerUI.elements && viewerUI.elements.viewerImg) || document.getElementById('viewer-img');
  if (!imgEl || imgEl.tagName !== 'IMG' || (imgEl.dataset && imgEl.dataset.audioPath)) {
    return;
  }

  const currentPath = viewerState.currentImagePath;
  if (!currentPath) return;

  viewerState.isAlphaOverlayMode = !viewerState.isAlphaOverlayMode;

  if (!viewerState.isAlphaOverlayMode) {
    if (viewerState.originalSrc) {
      imgEl.src = viewerState.originalSrc;
      viewerState.originalSrc = null;
    }
    return;
  }

  await applyAlphaOverlay(imgEl, currentPath, false);
}

/**
 * 現在表示中の画像・動画要素のリソースを即座に解放
 */
function cleanupCurrentImage() {
  closeVolumePopup();
  stopAndDiscardAudio();
  if (viewerState.isAlphaOverlayMode && viewerState.originalSrc && currentlyVisibleImg) {
    currentlyVisibleImg.src = viewerState.originalSrc;
  }
  viewerState.originalSrc = null;
  if (currentlyVisibleImg) {
    if (currentlyVisibleImg.tagName === 'VIDEO') {
      currentlyVisibleImg.pause();
      currentlyVisibleImg.removeAttribute('src');
      currentlyVisibleImg.load();
    }
    currentlyVisibleImg.remove();
    currentlyVisibleImg = null;
  }
}

/**
 * SVGシャープネスフィルターの初期化
 * 小数倍率で拡大した際にも滑らかさを保ちつつ輪郭を強調するためのフィルターを生成します。
 */
function initUnsharpFilter() {
  const svgNS = "http://www.w3.org/2000/svg";
  const svgElement = document.createElementNS(svgNS, "svg");
  svgElement.setAttribute("class", "unsharp-svg");

  const unsharpFilter = document.createElementNS(svgNS, "filter");
  unsharpFilter.id = "unsharp-filter";

  const feConvolveUnsharp = document.createElementNS(svgNS, "feConvolveMatrix");
  // stdDev=0.8 のガウスぼかしを 0.8 倍して引き算し、中心を 1.8 倍する数学的近似行列
  feConvolveUnsharp.setAttribute("order", "5 5");
  feConvolveUnsharp.setAttribute("kernelMatrix", 
    " 0     -0.008 -0.018 -0.008  0 " +
    "-0.008 -0.078 -0.170 -0.078 -0.008 " +
    "-0.018 -0.170  2.128 -0.170 -0.018 " +
    "-0.008 -0.078 -0.170 -0.078 -0.008 " +
    " 0     -0.008 -0.018 -0.008  0"
  );
  feConvolveUnsharp.setAttribute("preserveAlpha", "true");

  unsharpFilter.appendChild(feConvolveUnsharp);
  svgElement.appendChild(unsharpFilter);

  document.body.appendChild(svgElement);
}
initUnsharpFilter();

window.addEventListener('DOMContentLoaded', async () => {
    try {
      if (window.veloceAPI && window.veloceAPI.getVideoServerPort) {
        window.videoServerPort = await window.veloceAPI.getVideoServerPort();
        if (window.veloceAPI.getVideoServerToken) {
          window.videoServerToken = await window.veloceAPI.getVideoServerToken();
        }
      }
    } catch (e) {
      console.warn("Failed to get video server port", e);
    }
    const urlParams = new URLSearchParams(window.location.search);
    const indexParam = urlParams.get('index');
    if (indexParam !== null) {
      viewerState.currentIndex = parseInt(indexParam, 10);
    }

    // ウィンドウが最大化されているかを非同期で確認しアイコンを更新する
    window.veloceAPI.isViewerMaximized().then(isMax => {
      if (isMax) {
        const maxBtn = document.getElementById('window-max-btn');
        if (maxBtn) maxBtn.innerHTML = ViewerUI.ICONS.RESTORE;
      }
    }).catch(() => {});

    if (window.veloceAPI && window.veloceAPI.getAllRatings) {
      window.veloceAPI.getAllRatings().then(ratings => {
        viewerRatings = ratings || {};
        if (typeof updateRatingDisplay === 'function') updateRatingDisplay();
      }).catch(() => {});
    }

    if (window.__TAURI__) {
      window.__TAURI__.event.listen('viewer-load-image', async (event) => {
        const newIndex = event.payload;
        viewerState.currentIndex = parseInt(newIndex, 10);
        
        // Single Window Mode (DOM Pool): clear cache and load new image
        clearPreloadCache();
        await loadImage();
      });

      // Window Poolパターン用の初期化セッションイベント
      window.__TAURI__.event.listen('viewer-init-session', async (event) => {
        const payload = event.payload;
        let newIndex = 0;
        let targetPath = null;
        let total = 0;
        if (typeof payload === 'number') {
          newIndex = payload;
        } else if (payload && typeof payload === 'object') {
          newIndex = typeof payload.index === 'number' ? payload.index : 0;
          targetPath = payload.path || null;
          total = typeof payload.total === 'number' ? payload.total : 0;
        }
        viewerState.currentIndex = newIndex;
        
        // プールされたウィンドウが再利用されるため、以前の状態を完全にリセットする
        const sessionTheme = (typeof window !== 'undefined' && window.SettingsStore
          ? window.SettingsStore.getItem('theme')
          : (typeof localStorage !== 'undefined' ? localStorage.getItem('theme') : null)) === 'light' ? 'light' : 'dark';
        applyViewerTheme(sessionTheme);
        cleanupCurrentImage();
        clearPreloadCache();
        viewerState.isAlphaOverlayMode = false;
        viewerState.originalSrc = null;
        viewerState.overlayCache.clear();
        viewerState.lastDirection = 1;
        viewerState.paths = total > 0 ? new Array(total).fill(null) : null;
        viewerState.currentImagePath = targetPath;
        viewerState.totalImages = total;
        if (viewerState.paths && targetPath && viewerState.currentIndex >= 0) {
          viewerState.paths[viewerState.currentIndex] = targetPath;
        }
        
        applyViewerInitialData();
        
        // リセット後、loadImageが確実に新しい画像をロード
        await loadImage();
      });

    }

    const pathsJson = localStorage.getItem('viewerPaths');
    let initialTotal = 0;
    if (pathsJson) {
      try {
        const parsedPaths = JSON.parse(pathsJson);
        const startIndexStr = localStorage.getItem('viewerStartIndex');
        if (startIndexStr) {
          const startIndex = parseInt(startIndexStr, 10);
          const initialData = JSON.parse(localStorage.getItem('viewerInitialData') || '{}');
          initialTotal = initialData.total || parsedPaths.length;
          const fullPaths = new Array(initialTotal).fill(null);
          for (let i = 0; i < parsedPaths.length; i++) fullPaths[startIndex + i] = parsedPaths[i];
          viewerState.paths = fullPaths;
        } else {
          viewerState.paths = parsedPaths;
        }
      } catch (e) {}
      localStorage.removeItem('viewerPaths');
      localStorage.removeItem('viewerStartIndex');
    }

    // 画像のロードイベントを初期化時に1度だけ設定
    if (viewerUI.elements.viewerImg) {
      viewerUI.elements.viewerImg.decoding = 'async'; // メインスレッドをブロックさせないため非同期でデコードする
      viewerUI.elements.viewerImg.onload = async () => {
        setZoomState(viewerState.isZoomed);
        viewerUI.updateImageRendering();
        resizeWindowToFitImage();
        if (!isViewerWindowShown && window.veloceAPI && window.veloceAPI.showWindow) {
          isViewerWindowShown = true;
          await window.veloceAPI.showWindow();
        }
      };
    }

    function applyViewerInitialData() {
      // IPC通信のラグを隠蔽するため、LocalStorageから初期データを取得して即座に描画を開始する
      const initialDataJson = localStorage.getItem('viewerInitialData');
      if (initialDataJson) {
        try {
          const initialData = JSON.parse(initialDataJson);
          // indexが一致している場合のみ適用（別ウィンドウのstaleデータを防止）
          if (typeof initialData.index !== 'number' || initialData.index === viewerState.currentIndex) {
            viewerState.currentImagePath = initialData.path;
            viewerState.totalImages = initialData.total;
            if (typeof initialData.index === 'number') {
              viewerState.currentIndex = initialData.index;
            }
            
            if (!viewerState.paths || viewerState.paths.length !== initialData.total) {
              viewerState.paths = new Array(initialData.total).fill(null);
            }
            // paths に格納しておくことで loadImage() → getImagePath() の冗長 IPC 往復を排除する (#6)
            if (viewerState.paths && viewerState.currentIndex >= 0) {
              viewerState.paths[viewerState.currentIndex] = initialData.path;
            }
            document.title = `Veloce Viewer - ${viewerState.currentIndex + 1} / ${viewerState.totalImages}`;
          }
        } catch (e) {}
        localStorage.removeItem('viewerInitialData');
      }
    }

    applyViewerInitialData();
    
    loadImage();

    const listen = (window.__TAURI__ && window.__TAURI__.event && window.__TAURI__.event.listen) || (window.__TAURI__ && window.__TAURI__.tauri && window.__TAURI__.tauri.listen) || (window.__TAURI__ && window.__TAURI__.core && window.__TAURI__.core.listen);
    if (listen) {
      listen('rating-changed', (event) => {
        const { path, rating } = event.payload || {};
        if (!path) return;
        if (rating === 0 || viewerRatings[path] === rating) {
          delete viewerRatings[path];
        } else {
          viewerRatings[path] = rating;
        }
        if (viewerState.currentImagePath === path) {
          if (typeof updateRatingDisplay === 'function') updateRatingDisplay();
        }
      });
      listen('viewers-arranged', () => {
        viewerState.isImmersiveArranged = true;
        resetZoomAndFit();
      });
      listen('close-viewer', () => {
        viewerState.paths = [];
        viewerState.currentImagePath = null;
        viewerState.totalImages = 0;
        cleanupCurrentImage();
        clearPreloadCache();
      });

      listen('viewer-list-updated', (event) => {
        const newPaths = event.payload || []; // 更新されたファイルパスのリスト
        viewerState.paths = newPaths;
        const newIndex = newPaths.indexOf(viewerState.currentImagePath);
        
        // ソートやフィルタで順序が変わったため、古いインデックスのキャッシュをすべて破棄
        clearPreloadCache();

        if (newIndex !== -1) {
          // 現在表示中の画像が新しいリスト内にも存在する場合、インデックスと総数を更新
          viewerState.currentIndex = newIndex;
          viewerState.totalImages = newPaths.length;
          document.title = `Veloce Viewer - ${viewerState.currentIndex + 1} / ${viewerState.totalImages}`;
          preloadAdjacentImages(); // 新しいリスト順で前後の画像をプリロードし直す
        } else if (newPaths.length > 0) {
          // フィルタリング等で画像が消滅したが、他の画像は残っている場合
          viewerState.currentIndex = Math.min(viewerState.currentIndex, newPaths.length - 1);
          loadImage();
        } else {
          // リストが空になった場合（すべての画像が除外・削除された等）はビューアを閉じる
          if (window.veloceAPI && window.veloceAPI.closeWindow) window.veloceAPI.closeWindow();
        }
      });
    }

    // --- ファイル名の表示設定の初期化と監視 ---
    const updateFilenameVisibility = () => {
      const show = (typeof window !== 'undefined' && window.SettingsStore
        ? window.SettingsStore.getItem('showViewerFilename')
        : localStorage.getItem('showViewerFilename')) !== 'false';
      
      const filenameEl = document.getElementById('window-filename-display');
      if (filenameEl) {
        filenameEl.style.display = show ? 'flex' : 'none';
      }

      const controlsEl = document.getElementById('window-controls');
      if (controlsEl) {
        controlsEl.classList.add('has-gradient');
      }
    };
    updateFilenameVisibility();

    // --- シークバーの規定表示設定の監視 ---
    const updateSeekBarDefaultVisibility = () => {
      const activeMedia = getActivePlaybackMedia();
      if (isPlayableMedia(activeMedia) && typeof setVideoSeekBarVisibility === 'function') {
        setVideoSeekBarVisibility(shouldShowSeekBarForMedia(activeMedia));
      }
    };

    window.addEventListener('storage', (e) => {
      if (e.key === 'showViewerFilename') updateFilenameVisibility();
      if (e.key === 'showViewerSeekBar') updateSeekBarDefaultVisibility();
      if (e.key === VIEWER_VOLUME_KEY || e.key === VIEWER_MUTED_KEY) {
        const activeMedia = getActivePlaybackMedia();
        if (isPlayableMedia(activeMedia)) {
          applyVolumeSettingsToMedia(activeMedia, activeMedia.tagName === 'VIDEO');
        }
        if (videoSeekBarContainer && typeof videoSeekBarContainer.updateVolumeControls === 'function') {
          videoSeekBarContainer.updateVolumeControls();
        }
      }
      if (e.key === 'theme') applyViewerTheme(e.newValue === 'light' ? 'light' : 'dark');
    });
});

// ============================================================================
// 2. Window & View Management
// ============================================================================

const VIEWER_ALIGN_CLASSES = [
  'viewer-body--align-center',
  'viewer-body--align-top',
  'viewer-body--align-left',
  'viewer-body--align-top-left'
];

function setViewerBodyAlignment(alignment) {
  document.body.classList.remove(...VIEWER_ALIGN_CLASSES);
  document.body.classList.add(`viewer-body--align-${alignment}`);
}

function clearViewerImgLayoutClasses(img) {
  img.classList.remove('is-zoomed', 'is-swapped', 'mode-immersive', 'mode-fit-window', 'mode-default');
  img.style.width = '';
  img.style.height = '';
  img.style.margin = '';
  img.style.transform = ''; // オーバースキャン補正をクリア
}

/**
 * 画像のズーム状態（100%表示か、画面フィットか）を設定する。
 * @param {boolean} zoomed - true: 100%表示, false: 画面にフィット
 */
function setZoomState(zoomed) {
  viewerState.isZoomed = zoomed;
  const img = viewerUI.elements.viewerImg;
  if (viewerState.isZoomed) {
    clearViewerImgLayoutClasses(img);
    img.classList.add('is-zoomed');
    img.style.width = `${getMediaWidth(img)}px`;
    img.style.height = `${getMediaHeight(img)}px`;
    viewerUI.setCursor('grab');
  } else {
    applyFitState();
  }
  updateFullscreenStyles();
}

/**
 * 現在の回転角度から、縦横が入れ替わっているかどうかを判定します。
 * @returns {boolean} 縦横が入れ替わっている場合は true
 */
function isRotationSwapped() {
  return Math.abs(viewerState.currentRotation) % 360 === 90 || Math.abs(viewerState.currentRotation) % 360 === 270;
}

/**
 * 現在の回転角度を考慮した画像の本来のサイズを取得します。
 * @returns {{width: number, height: number}} 回転を考慮した幅と高さ
 */
function getNaturalDimensions() {
  const swapped = isRotationSwapped();
  return {
    width: swapped ? getMediaHeight(viewerUI.elements.viewerImg) : getMediaWidth(viewerUI.elements.viewerImg),
    height: swapped ? getMediaWidth(viewerUI.elements.viewerImg) : getMediaHeight(viewerUI.elements.viewerImg)
  };
}

/**
 * ズーム状態とフィット状態を解除し、デフォルトの表示状態に戻します。
 */
function resetZoomAndFit() {
  viewerState.isZoomed = false;
  viewerState.isFitToWindow = false;
  viewerState.currentScale = 1.0;
  viewerState.currentTranslateX = 0;
  viewerState.currentTranslateY = 0;
  viewerUI.updateImageRendering();
  applyFitState();
  updateFullscreenStyles();
}

/**
 * 非ズーム時の表示状態（強制フィット拡大 か デフォルトの縮小のみ か）を適用する。
 */
function applyFitState() {
  if (viewerState.isZoomed) return;

  const img = viewerUI.elements.viewerImg;
  const isSwapped = isRotationSwapped();

  clearViewerImgLayoutClasses(img);
  img.classList.toggle('is-swapped', isSwapped);

  if (viewerState.isImmersiveArranged) {
    img.classList.add('mode-immersive');
  } else if (viewerState.isFitToWindow) {
    img.classList.add('mode-fit-window');
  } else {
    img.classList.add('mode-default');
  }

  viewerUI.setCursor('default');
  setViewerBodyAlignment('center');

  window.scrollTo(0, 0);
  document.body.scrollTop = 0;
  document.body.scrollLeft = 0;
  document.documentElement.scrollTop = 0;
  document.documentElement.scrollLeft = 0;
}

const resizeObserver = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(debounce(async () => {
    // リサイズ中にIPC通信（await invoke）を行うとOSのメッセージループが詰まり
    // 例外0xc000041dでクラッシュするため、ブラウザのAPIを用いて判定する
    const isMax = window.innerWidth >= (window.screen ? window.screen.availWidth - 10 : 0) && window.innerHeight >= (window.screen ? window.screen.availHeight - 10 : 0);
    const maxBtn = document.getElementById('window-max-btn');
    if (maxBtn) {
      maxBtn.innerHTML = isMax ? ViewerUI.ICONS.RESTORE : ViewerUI.ICONS.MAXIMIZE;
    }

    const isFs = window.screen && window.innerHeight === window.screen.height;
    if (isFs && !viewerState.isFullscreen) {
      viewerState.isFullscreen = true;
      const overlay = document.getElementById('border-overlay');
      if (overlay) overlay.classList.add('border-hidden');
      const controls = document.getElementById('window-controls');
      if (controls) controls.classList.add('fs-hidden');
    } else if (!isFs && viewerState.isFullscreen) {
      viewerState.isFullscreen = false;
      viewerUI.applyBorderVisibility();
    }
    
    updateFullscreenStyles();
}, CONFIG.RESIZE_THROTTLE)) : null;

if (resizeObserver && typeof resizeObserver.observe === 'function' && typeof document !== 'undefined' && document.body) {
  resizeObserver.observe(document.body);
}

/**
 * フルスクリーン（100%表示）時のスタイルを更新する。
 * スクロールバーの表示・非表示や、画像の配置を決定する。
 */
function updateFullscreenStyles() {
  const img = viewerUI.elements.viewerImg;
  if (!viewerState.isZoomed) {
    setViewerBodyAlignment('center');
    img.style.margin = '0';
    window.scrollTo(0, 0);
    if (window.updateScaleDisplay) window.updateScaleDisplay();
    return;
  }

  const isSwapped = isRotationSwapped();

  if (isSwapped) {
    const marginY = (getMediaWidth(img) - getMediaHeight(img)) / 2;
    const marginX = (getMediaHeight(img) - getMediaWidth(img)) / 2;
    img.style.margin = `${marginY}px ${marginX}px`;
  } else {
    img.style.margin = '0';
  }

  const { width: imgWidth, height: imgHeight } = getNaturalDimensions();

  const winW = window.innerWidth;
  const winH = window.innerHeight;

  const overflowX = imgWidth > winW;
  const overflowY = imgHeight > winH;

  if (!overflowX && !overflowY) {
    setViewerBodyAlignment('center');
  } else if (!overflowX && overflowY) {
    setViewerBodyAlignment('top');
  } else if (overflowX && !overflowY) {
    setViewerBodyAlignment('left');
  } else {
    setViewerBodyAlignment('top-left');
    document.body.scrollLeft = (imgWidth - winW) / 2;
    document.body.scrollTop = (imgHeight - winH) / 2;
  }
  if (window.updateScaleDisplay) window.updateScaleDisplay();
}

// リサイズ後のフォーカス要求をデバウンスして、連続切り替え時の競合を防ぐ
const debouncedFocusWindow = debounce(() => {
  window.focus();
}, 200);

let _resizePending = false;

/**
 * 回転を考慮した画像本来のサイズに合わせてウィンドウをリサイズします。
 */
function resizeWindowToFitImage() {
  if (viewerState.isFullscreen || document.fullscreenElement || viewerState.isImmersiveArranged) return;

  const { width: natW, height: natH } = getNaturalDimensions();
  const maxWindowWidth = window.screen.width;
  const maxWindowHeight = window.screen.height - 1;

  let scale = Math.min(maxWindowWidth / natW, maxWindowHeight / natH, 1.0);
  
  // ズーム状態が維持されている場合は、そのスケールを反映させる
  if (viewerState.isZoomed) {
    scale = viewerState.currentScale;
  }

  let targetWidth = Math.floor(natW * scale);
  let targetHeight = Math.floor(natH * scale);

  // モニターサイズを超えないように制限
  targetWidth = Math.min(targetWidth, maxWindowWidth);
  targetHeight = Math.min(targetHeight, maxWindowHeight);

  if (window.updateScaleDisplay) setTimeout(window.updateScaleDisplay, 50);

  // 現在のウィンドウサイズと同じ場合は無駄なリサイズ要求をスキップする
  if (Math.abs(window.innerWidth - targetWidth) < 2 && Math.abs(window.innerHeight - targetHeight) < 2) {
    return;
  }

  if (_resizePending) return;

  if (window.veloceAPI && window.veloceAPI.setWindowSize) {
    _resizePending = true;
    window.veloceAPI.setWindowSize(targetWidth, targetHeight).then(() => {
      _resizePending = false;
      debouncedFocusWindow(); // 連続呼び出しによるフォーカス外れを防ぐためデバウンス処理を行う

      // ウィンドウの非クライアント領域（影・ボーダー）による数px誤差を
      // transform: scale() で補正し、画像端の黒い隙間をなくす。
      // ズーム中は補正しない（ユーザー操作の scale と競合するため）。
      if (!viewerState.isZoomed) {
        const img = viewerUI.elements.viewerImg;
        if (img && img.naturalWidth > 0 && img.naturalHeight > 0) {
          const actualW = window.innerWidth;
          const actualH = window.innerHeight;
          // ウィンドウに対して画像が占める割合を計算
          const imgAspect = targetWidth / targetHeight;
          const winAspect = actualW / actualH;
          // 短辺方向の誤差比率を補正倍率として使う（オーバースキャン）
          var compensate;
          if (imgAspect >= winAspect) {
            // 高さが制約軸: actualH と targetHeight の比
            compensate = (actualH > 0 && targetHeight > 0) ? actualH / targetHeight : 1.0;
          } else {
            // 幅が制約軸: actualW と targetWidth の比
            compensate = (actualW > 0 && targetWidth > 0) ? actualW / targetWidth : 1.0;
          }
          // 誤差が0.5px以上の場合のみ適用（不要な再描画を回避）
          if (Math.abs(compensate - 1.0) > 0.0005 && compensate > 0.9 && compensate < 1.1) {
            viewerState.compensateScale = compensate;
          } else {
            viewerState.compensateScale = 1.0;
          }
          viewerUI.updateImageRendering();
        }
      }
    }).catch(() => {
      _resizePending = false;
    });
  }
}

// ============================================================================
// 3. Image Navigation & Loading
// ============================================================================

/**
 * インデックスから画像のパスを取得します。ローカルに無い場合はIPCでフォールバックします。
 */
async function getImagePath(index) {
  if (viewerState.paths && viewerState.paths[index]) {
    return viewerState.paths[index];
  }
  const result = await window.veloceAPI.getViewerImage(index);
  if (result) {
    if (!viewerState.paths || viewerState.paths.length !== result.total) {
      viewerState.paths = new Array(result.total).fill(null);
    }
    if (result.chunk && typeof result.chunkStart === 'number') {
      for (let i = 0; i < result.chunk.length; i++) {
        viewerState.paths[result.chunkStart + i] = result.chunk[i];
      }
    }
    viewerState.paths[index] = result.path;
    return result.path;
  }
  return null;
}

let isViewerWindowShown = false; // 初回表示フラグ
let imageLoadSequence = 0;       // 非同期ロード競合防止用

/**
 * DOM Swap方式：新しい画像を背面に用意しておき、表示する瞬間に要素を切り替えることでラグを無くします。
 */
function swapImageElement(newImg, sequenceId) {
  if (currentViewerImg === newImg) {
    if (!isViewerWindowShown && window.veloceAPI && window.veloceAPI.showWindow) {
      window.veloceAPI.showWindow();
      isViewerWindowShown = true;
    }
    return;
  }
  
  newImg.classList.add('viewer-img-pending');
  newImg.style.display = 'none'; // Initially hide it to prevent pushing the visible image
  viewerUI.elements.viewerImg = newImg;
  
  const borderOverlay = document.getElementById('border-overlay');
  if (borderOverlay && borderOverlay.parentNode) {
    document.body.insertBefore(newImg, borderOverlay);
  } else {
    document.body.appendChild(newImg);
  }

  if (!isViewerWindowShown && window.veloceAPI && window.veloceAPI.showWindow) {
    window.veloceAPI.showWindow();
    isViewerWindowShown = true;
  }

  currentViewerImg = newImg;

  // Clean up any stray elements that are NOT currentlyVisibleImg and not newImg
  const strayImgs = document.querySelectorAll('.viewer-img-pending, #viewer-img');
  strayImgs.forEach(img => {
    if (img !== currentlyVisibleImg && img !== newImg) {
      if (img.tagName === 'VIDEO') {
        img.pause();
      }
      img.remove();
    }
  });

  // ファイル移動・切り替え時は直前の音声再生を即座に停止・破棄する
  stopAndDiscardAudio();

  const makeVisible = () => {
    if (sequenceId !== imageLoadSequence) return;
    
    // Clean up the currently visible image since the new one is ready
    if (currentlyVisibleImg && currentlyVisibleImg !== newImg) {
      if (currentlyVisibleImg.tagName === 'VIDEO') {
        // 表示から外れた動画は一時停止してバックグラウンド再生・音声出力を停止する。
        // ※ preloadCache に保持されている動画要素の src を removeAttribute してしまうと、
        //   再訪時に空の video 要素が再利用されて再生できなくなるため、src の消去は行わない。
        //   メモリ解放は preloadCache から完全に破棄されるタイミング（diff > 3 または clearPreloadCache）で行う。
        currentlyVisibleImg.pause();
      }
      currentlyVisibleImg.remove();
    }
    currentlyVisibleImg = newImg;
    newImg.id = 'viewer-img';
    newImg.classList.remove('viewer-img-pending');
    newImg.style.display = '';
    // DOM置換直後にスタイルの適用とバウンディングボックスの同期計算を確定させ、次行のリサイズ処理へ渡す
    void newImg.offsetHeight;

    setZoomState(viewerState.isZoomed);
    viewerUI.updateImageRendering();
    resizeWindowToFitImage();

    if (newImg.dataset && newImg.dataset.audioPath) {
      stopAndDiscardAudio();
      const audioPath = newImg.dataset.audioPath;
      const audioEl = document.createElement('audio');
      audioEl.autoplay = true;
      audioEl.loop = false;
      audioEl.tabIndex = -1;
      applyVolumeSettingsToMedia(audioEl, false);
      const baseSrc = (window.veloceAPI && window.veloceAPI.convertFileSrc) ? window.veloceAPI.convertFileSrc(audioPath) : '';
      audioEl.src = getStreamUrl(audioPath, baseSrc);
      currentAudioElement = audioEl;
      document.body.appendChild(audioEl);
      if (typeof audioEl.play === 'function') {
        audioEl.play().catch(e => console.warn('Audio play failed:', e));
      }
      if (typeof setVideoSeekBarVisibility === 'function') {
        setVideoSeekBarVisibility(shouldShowSeekBarForMedia(audioEl));
      }
    }
  };

  if (newImg.tagName === 'VIDEO') {
    applyVolumeSettingsToMedia(newImg, true);
    // 再訪時やループ遷移時、動画を確実に先頭から再生する
    try {
      newImg.currentTime = 0;
    } catch (e) {
      /* ignore if not yet seekable */
    }
    if (newImg.readyState >= 1) {
      makeVisible();
      newImg.play().catch(e => console.warn('Video play failed:', e));
    } else {
      newImg.addEventListener('loadedmetadata', () => {
        makeVisible();
        try {
          newImg.currentTime = 0;
        } catch (e) {
          /* ignore */
        }
        newImg.play().catch(e => console.warn('Video play failed:', e));
      }, { once: true });
      newImg.addEventListener('error', () => {
        makeVisible();
      }, { once: true });
    }
  } else {
    const decodePromise = (typeof newImg.decode === 'function') ? newImg.decode() : null;
    if (decodePromise && typeof decodePromise.then === 'function') {
      decodePromise.then(() => {
        makeVisible();
      }).catch((e) => {
        makeVisible();
      });
    } else {
      makeVisible();
    }
  }

  const isAudioTarget = Boolean(newImg.dataset && newImg.dataset.audioPath);
  if (newImg.tagName === 'VIDEO') {
    if (typeof setVideoSeekBarVisibility === 'function') {
      setVideoSeekBarVisibility(shouldShowSeekBarForMedia(newImg));
    }
  } else if (!isAudioTarget) {
    if (typeof setVideoSeekBarVisibility === 'function') {
      setVideoSeekBarVisibility(false);
    } else if (typeof videoSeekBarContainer !== 'undefined' && videoSeekBarContainer) {
      videoSeekBarContainer.style.display = 'none';
    }
  }
}

async function loadImage() {
  closeVolumePopup();

  const currentSeq = ++imageLoadSequence;

  const path = await getImagePath(viewerState.currentIndex);
  if (path) {
    // 非同期でパスを取得している間に別のロードが開始されていたら破棄
    if (currentSeq !== imageLoadSequence) return;

    viewerState.currentImagePath = path;
    if (viewerState.paths && viewerState.paths.length > 0) {
      viewerState.totalImages = viewerState.paths.length;
    }

    let targetImg;
    const isVideo = isVideoFile(viewerState.currentImagePath);
    const isAudio = isAudioFile(viewerState.currentImagePath);
    if (viewerState.preloadCache.has(viewerState.currentIndex)) {
      const cachedData = viewerState.preloadCache.get(viewerState.currentIndex);
      if (cachedData.path === viewerState.currentImagePath) {
        // タグ種別（VIDEO / Audio用IMG / 通常IMG）の整合性確認、および動画要素の破損検出時は安全に破棄
        const hasAudioTag = Boolean(cachedData.img && cachedData.img.dataset && cachedData.img.dataset.audioPath);
        const isTagMismatched = cachedData.img && (
          isVideo ? cachedData.img.tagName !== 'VIDEO'
            : (isAudio ? (cachedData.img.tagName !== 'IMG' || !hasAudioTag)
              : (cachedData.img.tagName === 'VIDEO' || hasAudioTag))
        );
        const isCorruptedVideo = cachedData.img && cachedData.img.tagName === 'VIDEO' && (!cachedData.img.src || cachedData.img.src === '');
        if (isTagMismatched || isCorruptedVideo) {
          viewerState.preloadCache.delete(viewerState.currentIndex);
        } else {
          targetImg = cachedData.img;
        }
      }
    }

    const targetSrc = getStreamUrl(viewerState.currentImagePath, window.veloceAPI.convertFileSrc(viewerState.currentImagePath));
    if (!targetImg && !isAudio && currentViewerImg && currentViewerImg.src === targetSrc) {
      const hasAudioTag = Boolean(currentViewerImg.dataset && currentViewerImg.dataset.audioPath);
      const isTagMismatched = isVideo ? currentViewerImg.tagName !== 'VIDEO' : (currentViewerImg.tagName === 'VIDEO' || hasAudioTag);
      if (!isTagMismatched) {
        targetImg = currentViewerImg;
      }
    }

    if (!targetImg) {
      if (isVideo) {
        targetImg = document.createElement('video');
        targetImg.autoplay = true;
        targetImg.loop = true;
        applyVolumeSettingsToMedia(targetImg, true);
        // フォーカスを受け取らないようにし、window.focus 誘発による ignoreNextClick 誤爆を防ぐ
        targetImg.tabIndex = -1;
        targetImg.src = targetSrc;
      } else if (isAudio) {
        targetImg = createAudioCoverImageElement(viewerState.currentImagePath);
      } else {
        targetImg = document.createElement('img');
        targetImg.decoding = 'async';
        targetImg.src = targetSrc;
      }
      viewerState.preloadCache.set(viewerState.currentIndex, { img: targetImg, path: viewerState.currentImagePath });
    }

    swapImageElement(targetImg, currentSeq);
    preloadAdjacentImages();
    if (typeof updateRatingDisplay === 'function') updateRatingDisplay();

    if (viewerState.isAlphaOverlayMode && targetImg.tagName === 'IMG') {
      applyAlphaOverlay(targetImg, path, true);
    }

    document.title = `Veloce Viewer - ${viewerState.currentIndex + 1} / ${viewerState.totalImages}`;
    const filenameEl = document.getElementById('window-filename-display');
    if (filenameEl && path) {
      filenameEl.textContent = path.split(/[/\\]/).pop();
    }
    if (viewerState.isMetadataVisible) {
      updateMetadataOverlay();
    }
  }
}

/**
 * 進行方向ベクトルに応じたスマートプリロードのオフセット配列を取得する。
 * 連続送り時の描画待ちを排除するため、進行方向に多くの先読み枠を優先配分し、
 * かつ逆方向も最低1枚は即座に戻れるよう枠を確保する。
 * @param {number} [direction=1] - 進行方向 (1: 次へ/前進, -1: 前へ/後退)
 * @returns {number[]} プリロード対象の相対オフセット配列
 */
export function getPreloadDeltas(direction = 1) {
  if (direction === 1) {
    return [1, 2, 3, -1];
  } else if (direction === -1) {
    return [-1, -2, -3, 1];
  }
  return [1, -1, 2, -2];
}
if (typeof window !== 'undefined') {
  window.getPreloadDeltas = getPreloadDeltas;
}

async function preloadAdjacentImages() {
  const total = viewerState.totalImages;
  if (total <= 1) return;

  // 進行方向ベクトルに応じたスマートプリロード（方向予測配分）
  const deltas = getPreloadDeltas(viewerState.lastDirection);
  const indicesToPreload = [];
  for (const delta of deltas) {
    const targetIdx = ((viewerState.currentIndex + delta) % total + total) % total;
    if (!indicesToPreload.includes(targetIdx)) {
      indicesToPreload.push(targetIdx);
    }
  }

  await Promise.all(indicesToPreload.map(async (idx) => {
    if (!viewerState.preloadCache.has(idx)) {
      const path = await getImagePath(idx);
      if (path && !viewerState.preloadCache.has(idx)) {
        const url = getStreamUrl(path, window.veloceAPI.convertFileSrc(path));
        let img;
        if (isVideoFile(path)) {
          img = document.createElement('video');
          img.autoplay = true;
          img.loop = true;
          applyVolumeSettingsToMedia(img, true);
          // フォーカスを受け取らないようにし、window.focus 誘発による ignoreNextClick 誤爆を防ぐ
          img.tabIndex = -1;
          img.src = url;
        } else if (isAudioFile(path)) {
          img = createAudioCoverImageElement(path);
        } else {
          img = document.createElement('img');
          img.decoding = 'async';
          img.src = url;
        }
        viewerState.preloadCache.set(idx, { img: img, path: path });

        if (img.tagName === 'IMG' && typeof img.decode === 'function') {
          img.decode().catch(e => { /* ignore */ });
        }
      }
    }
  }));

  // 不要になった古いキャッシュ（現在地から離れたもの）を削除してメモリを節約
  for (const cachedIdx of viewerState.preloadCache.keys()) {
    let diff = Math.abs(cachedIdx - viewerState.currentIndex);
    if (diff > total / 2) {
      diff = total - diff;
    }
    if (diff > 3) {
      const cached = viewerState.preloadCache.get(cachedIdx);
      if (cached && cached.img) {
        // 現在表示中の画像、またはロード進行中の画像は破棄から保護する（高速スクロール時の非同期レース防止）
        if (cached.img === currentlyVisibleImg || cached.img === currentViewerImg) {
          continue;
        }
        if (cached.img.tagName === 'VIDEO') {
          cached.img.pause();
          cached.img.removeAttribute('src');
          cached.img.load();
        }
        if (typeof cached.img.remove === 'function') cached.img.remove();
      }
      viewerState.preloadCache.delete(cachedIdx);
    }
  }
}

/**
 * 次の画像を表示する (Next)
 */
export function showNext() {
  if (viewerState.totalImages > 0) {
    viewerState.lastDirection = 1;
    const isLooping = viewerState.totalImages > 1 && viewerState.currentIndex === viewerState.totalImages - 1;
    viewerState.currentIndex = (viewerState.currentIndex < viewerState.totalImages - 1) ? viewerState.currentIndex + 1 : 0;
    if (isLooping && viewerUI && typeof viewerUI.triggerLoopFeedback === 'function') {
      viewerUI.triggerLoopFeedback('start');
    }
    loadImage();
  }
}

/**
 * 前の画像を表示する (Prev)
 */
export function showPrev() {
  if (viewerState.totalImages > 0) {
    viewerState.lastDirection = -1;
    const isLooping = viewerState.totalImages > 1 && viewerState.currentIndex === 0;
    viewerState.currentIndex = (viewerState.currentIndex > 0) ? viewerState.currentIndex - 1 : viewerState.totalImages - 1;
    if (isLooping && viewerUI && typeof viewerUI.triggerLoopFeedback === 'function') {
      viewerUI.triggerLoopFeedback('end');
    }
    loadImage();
  }
}

function clampTranslate() {
  if (!viewerUI.elements.viewerImg) return;

  if (viewerState.isImmersiveArranged) {
    const winW = window.innerWidth;
    const winH = window.innerHeight;
    const { width: natW, height: natH } = getNaturalDimensions();
    
    if (natW > 0 && natH > 0) {
      const scale = Math.max(winW / natW, winH / natH);
      const coverW = natW * scale;
      const coverH = natH * scale;
      
      const maxTx = Math.max(0, (coverW - winW) / 2);
      const maxTy = Math.max(0, (coverH - winH) / 2);
      
      viewerState.currentTranslateX = Math.max(-maxTx, Math.min(viewerState.currentTranslateX, maxTx));
      viewerState.currentTranslateY = Math.max(-maxTy, Math.min(viewerState.currentTranslateY, maxTy));
    }
    return;
  }

  const winW = window.innerWidth;
  const winH = window.innerHeight;
  const { width: natW, height: natH } = getNaturalDimensions();
  const comp = viewerState.compensateScale || 1.0;
  
  const scaledW = natW * viewerState.currentScale * comp;
  const scaledH = natH * viewerState.currentScale * comp;

  const baseLeft = (winW - scaledW) / 2;
  const baseTop = (winH - scaledH) / 2;
  const baseRight = baseLeft + scaledW;
  const baseBottom = baseTop + scaledH;
  
  const rect = { width: scaledW, height: scaledH };

  // X軸の制約：縮小時は画面内に収まる範囲で自由に移動、拡大時ははみ出さない範囲で移動
  if (rect.width <= winW) {
    viewerState.currentTranslateX = Math.max(-baseLeft, Math.min(viewerState.currentTranslateX, winW - baseRight));
  } else {
    viewerState.currentTranslateX = Math.max(winW - baseRight, Math.min(viewerState.currentTranslateX, -baseLeft));
  }

  // Y軸の制約：縮小時は画面内に収まる範囲で自由に移動、拡大時ははみ出さない範囲で移動
  if (rect.height <= winH) {
    viewerState.currentTranslateY = Math.max(-baseTop, Math.min(viewerState.currentTranslateY, winH - baseBottom));
  } else {
    viewerState.currentTranslateY = Math.max(winH - baseBottom, Math.min(viewerState.currentTranslateY, -baseTop));
  }
}

// ============================================================================
// 4. UI Controls
// ============================================================================

// ドラッグ、クリック、ダブルクリックを判別するための状態変数
let isDragging = false;
let hasMoved = false; // ドラッグ中に実際にマウスが移動したか
let startX = 0, startY = 0; // ドラッグ開始時の座標
let windowX = 0, windowY = 0; // ウィンドウ移動用の座標

// Windows 8.1 / 10 のボーダーレスウィンドウにおいて、ネイティブタイトルバー制御のホバー判定不整合を防ぎ統一した外観を提供するためカスタムコントロールを構築
function createWindowControls() {
  const controlsContainer = document.createElement('div');
  controlsContainer.id = 'window-controls';
  if (!viewerState.isBorderVisible) controlsContainer.classList.add('controls-hidden');
  ['click', 'dblclick'].forEach(evt => {
    controlsContainer.addEventListener(evt, (e) => e.stopPropagation());
  });

  // 最小化ボタン
  const minBtn = document.createElement('div');
  minBtn.id = 'window-min-btn';
  minBtn.className = 'window-ctrl-btn window-ctrl-btn--min';
  minBtn.innerHTML = ViewerUI.ICONS.MINIMIZE;
  minBtn.onclick = () => window.veloceAPI.minimizeViewer();

  // 最大化/元に戻すボタン
  const maxBtn = document.createElement('div');
  maxBtn.id = 'window-max-btn';
  maxBtn.className = 'window-ctrl-btn window-ctrl-btn--max';
  maxBtn.innerHTML = ViewerUI.ICONS.MAXIMIZE;
  maxBtn.onclick = () => window.veloceAPI.maximizeViewer();

  // 閉じるボタン
  const closeBtn = document.createElement('div');
  closeBtn.id = 'window-close-btn';
  closeBtn.className = 'window-ctrl-btn window-ctrl-btn--close';
  closeBtn.innerHTML = ViewerUI.ICONS.CLOSE;
  closeBtn.onclick = () => {
    if (window.veloceAPI && window.veloceAPI.closeWindow) window.veloceAPI.closeWindow();
  };

  [minBtn, maxBtn, closeBtn].forEach(btn => {
    ['mousedown', 'mouseup'].forEach(evt => {
      btn.addEventListener(evt, (e) => e.stopPropagation());
    });
  });

  const filenameDisplay = document.createElement('div');
  filenameDisplay.id = 'window-filename-display';
  filenameDisplay.className = 'window-filename';

  controlsContainer.appendChild(filenameDisplay);
  const infoContainer = document.createElement('div');
  infoContainer.id = 'window-info-container';
  infoContainer.className = 'window-info-container';
  infoContainer.style.display = 'none';

  const ratingDisplay = document.createElement('div');
  ratingDisplay.id = 'viewer-rating-display';
  ratingDisplay.className = 'viewer-rating-display';
  ratingDisplay.style.display = 'none';

  const scaleDisplay = document.createElement('div');
  scaleDisplay.id = 'window-scale-display';
  scaleDisplay.className = 'window-scale-display';
  scaleDisplay.style.display = 'none';

  infoContainer.appendChild(ratingDisplay);
  infoContainer.appendChild(scaleDisplay);
  controlsContainer.appendChild(infoContainer);

  controlsContainer.appendChild(minBtn);
  controlsContainer.appendChild(maxBtn);
  controlsContainer.appendChild(closeBtn);
  document.body.appendChild(controlsContainer);
}

createWindowControls();
viewerUI.applyBorderVisibility();

// ============================================================================
// 5. Event Handlers (Mouse & Keyboard)
// ============================================================================

window.addEventListener('mousedown', (e) => {
  // ウィンドウがフォーカスを取得した直後のクリック（フォーカス目的のクリック）を画像送りとして扱わない
  if (Date.now() - viewerState.lastFocusTime < CONFIG.FOCUS_DELAY) {
    viewerState.ignoreNextClick = true;
  } else {
    viewerState.ignoreNextClick = false;
  }

  if (e.button === 0) { // 左クリック
    // 画像上でのCtrl+左ドラッグはパン操作とする
    if (e.ctrlKey && e.target && (e.target.id === 'viewer-img' || e.target.closest('#viewer-img') || e.target.id === 'border-overlay')) {
      e.preventDefault(); // デフォルトのドラッグを防止
      viewerState.isImageDragging = true;
      viewerState.imageDragStartX = e.clientX;
      viewerState.imageDragStartY = e.clientY;
      viewerUI.setCursor('grabbing');
      hasMoved = false;
    } else {
      // それ以外の左ドラッグはウィンドウ移動
      const EDGE = CONFIG.EDGE_THRESHOLD;
      if (e.clientX < EDGE || e.clientX > window.innerWidth - EDGE ||
          e.clientY < EDGE || e.clientY > window.innerHeight - EDGE) {
        isDragging = false;
        return;
      }
      isDragging = true;
      hasMoved = false;
      startX = e.screenX;
      startY = e.screenY;
      windowX = e.clientX;
      windowY = e.clientY;
    }
  }
});

let dragRafId = null;
window.addEventListener('mousemove', (e) => {
  if (viewerState.isImageDragging) {
    if (!hasMoved) {
      if (Math.abs(e.clientX - viewerState.imageDragStartX) > 5 || Math.abs(e.clientY - viewerState.imageDragStartY) > 5) {
        hasMoved = true;
      }
    }
    
    if (hasMoved) {
      viewerState.currentTranslateX += e.clientX - viewerState.imageDragStartX;
      viewerState.currentTranslateY += e.clientY - viewerState.imageDragStartY;
      viewerState.imageDragStartX = e.clientX;
      viewerState.imageDragStartY = e.clientY;

      // 一旦DOMに仮反映してから境界をチェックし、最終結果を適用する
      clampTranslate();
      viewerUI.updateImageRendering();
    }
  } else if (isDragging) {
    if (!hasMoved) {
      if (Math.abs(e.screenX - startX) > 5 || Math.abs(e.screenY - startY) > 5) {
        hasMoved = true;
      }
    }
    if (hasMoved) {
      if (dragRafId) cancelAnimationFrame(dragRafId);
      dragRafId = requestAnimationFrame(() => {
        window.veloceAPI.moveViewerWindow(e.screenX - windowX, e.screenY - windowY);
      });
    }
  }
});

window.addEventListener('mouseup', (e) => {
  if (e.button === 0) { // 左クリックのリリース
    if (viewerState.isImageDragging) {
      viewerState.isImageDragging = false;
      viewerUI.setCursor(e.ctrlKey ? 'grab' : 'default');
      // ドラッグせずに離した場合はクリックとして扱う（次の画像へ）※Ctrl押下時はスキップ
      if (!hasMoved && !viewerState.ignoreNextClick && !e.ctrlKey) {
        showPrev();
      }
    } else if (isDragging) {
      isDragging = false;
      if (!hasMoved && !viewerState.ignoreNextClick) {
        showPrev();
      }
    }
  }
});

// Ctrlキーを押した時だけ「手のひら」カーソルにして、ドラッグ可能であることを示す
window.addEventListener('keydown', (e) => {
  if (e.key === 'Control') viewerUI.setCursor('grab');
});
window.addEventListener('keyup', (e) => {
  if (e.key === 'Control' && !viewerState.isImageDragging) {
    viewerUI.setCursor('default');
  }
});

window.addEventListener('contextmenu', (e) => {
  e.preventDefault(); 
  if (viewerState.ignoreNextClick) return; // フォーカス目的の右クリックを無視
  showNext(); // 右クリックで次の画像へ
});

export function handleWheel(e) {
  if (e.ctrlKey) {
    if (typeof e.preventDefault === 'function') e.preventDefault(); // ブラウザ標準のズームを無効化し、親ウィンドウへのイベント伝播を防ぐ
    viewerState.isImmersiveArranged = false; // 手動ズームで解除

    // ズーム状態への移行：初めてズームするときは現在の見た目のスケールを計算して引き継ぎ、二重拡大を防ぐ
    if (!viewerState.isZoomed) {
      const { width: natW, height: natH } = getNaturalDimensions();
      viewerState.currentScale = viewerState.isFitToWindow 
        ? Math.min(window.innerWidth / natW, window.innerHeight / natH)
        : Math.min(1.0, window.innerWidth / natW, window.innerHeight / natH);
      setZoomState(true);
    }

    // ホイールの回転方向に応じてスケールを増減
    if (e.deltaY < 0) {
      viewerState.currentScale *= CONFIG.ZOOM_STEP; // 上スクロールで拡大
    } else {
      viewerState.currentScale /= CONFIG.ZOOM_STEP; // 下スクロールで縮小
    }

    // 倍率の限界値を設定
    viewerState.currentScale = Math.max(CONFIG.MIN_ZOOM, Math.min(viewerState.currentScale, CONFIG.MAX_ZOOM));

    // ウィンドウサイズを画像のズームに合わせて即座に追従させる
    if (!viewerState.isFullscreen && !document.fullscreenElement) {
      const { width: natW, height: natH } = getNaturalDimensions();
      let targetWidth = Math.round(natW * viewerState.currentScale);
      let targetHeight = Math.round(natH * viewerState.currentScale);

      const monitorW = window.screen.availWidth;
      const monitorH = window.screen.availHeight;

      // モニターサイズを超えないように制限
      targetWidth = Math.min(targetWidth, monitorW);
      targetHeight = Math.min(targetHeight, monitorH);

      if (window.veloceAPI && window.veloceAPI.resizeViewerWindow) {
        if (window._resizeRafId) cancelAnimationFrame(window._resizeRafId);
        window._resizeRafId = requestAnimationFrame(() => {
          window.veloceAPI.resizeViewerWindow(targetWidth, targetHeight);
        });
      }
    }

    // 一旦スケールを適用し、縮小時にはみ出しを補正して再適用
    clampTranslate();
    viewerUI.updateImageRendering();
    updateFullscreenStyles(); // マージンの再計算
    debouncedFocusWindow();   // フォーカスの維持
  } else {
    if (typeof e.preventDefault === 'function') e.preventDefault(); // 親ウィンドウのスクロールを防止
    
    // 一定時間ホイール操作がない場合は移動量の端数をリセットする
    clearTimeout(window._wheelResetTimeout);
    window._wheelResetTimeout = setTimeout(() => {
      window._wheelDeltaAccumulator = 0;
    }, 150);
    
    // トラックパッドの連続イベントやマウスの「カチッ」を吸収するため、移動量を累積する
    window._wheelDeltaAccumulator = (window._wheelDeltaAccumulator || 0) + e.deltaY;
    const WHEEL_THRESHOLD = 80; // この値（移動量）ごとに1枚送る
    
    let steps = 0;
    if (window._wheelDeltaAccumulator >= WHEEL_THRESHOLD) {
      steps = Math.floor(window._wheelDeltaAccumulator / WHEEL_THRESHOLD);
      window._wheelDeltaAccumulator %= WHEEL_THRESHOLD;
    } else if (window._wheelDeltaAccumulator <= -WHEEL_THRESHOLD) {
      steps = Math.ceil(window._wheelDeltaAccumulator / WHEEL_THRESHOLD); // マイナスの値
      window._wheelDeltaAccumulator %= WHEEL_THRESHOLD;
    }

    if (steps !== 0 && viewerState.totalImages > 0) {
      if (steps > 0) {
        for (let s = 0; s < steps; s++) {
          const isLooping = viewerState.totalImages > 1 && viewerState.currentIndex === viewerState.totalImages - 1;
          viewerState.currentIndex = (viewerState.currentIndex < viewerState.totalImages - 1) ? viewerState.currentIndex + 1 : 0;
          if (isLooping && viewerUI && typeof viewerUI.triggerLoopFeedback === 'function') {
            viewerUI.triggerLoopFeedback('start');
          }
        }
        viewerState.lastDirection = 1;
        loadImage();
      } else if (steps < 0) {
        for (let s = 0; s < Math.abs(steps); s++) {
          const isLooping = viewerState.totalImages > 1 && viewerState.currentIndex === 0;
          viewerState.currentIndex = (viewerState.currentIndex > 0) ? viewerState.currentIndex - 1 : viewerState.totalImages - 1;
          if (isLooping && viewerUI && typeof viewerUI.triggerLoopFeedback === 'function') {
            viewerUI.triggerLoopFeedback('end');
          }
        }
        viewerState.lastDirection = -1;
        loadImage();
      }
    }
  }
}

window.addEventListener('wheel', handleWheel, { passive: false });

window.addEventListener('keydown', async (e) => {
  // Ctrl+Shift+I で開発者ツールをトグル表示
  if (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'I')) {
    e.preventDefault();
    return;
  }

  const isPlainKey = !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey;
  const isShiftOnly = e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey;

  switch (e.key) {
    case 'ArrowLeft':
      if (isShiftOnly) {
        if (isPlayableMedia(getActivePlaybackMedia())) {
          e.preventDefault();
          seekActiveMediaBySeconds(-5);
        }
        break;
      }
      if (!isPlainKey) break;
      showPrev();
      break;
    case 'ArrowRight':
      if (isShiftOnly) {
        if (isPlayableMedia(getActivePlaybackMedia())) {
          e.preventDefault();
          seekActiveMediaBySeconds(5);
        }
        break;
      }
      if (!isPlainKey) break;
      showNext();
      break;
    case 'ArrowUp':
      if (isShiftOnly) {
        if (isPlayableMedia(getActivePlaybackMedia())) {
          e.preventDefault();
          adjustActiveMediaVolumeByPercent(5);
        }
        break;
      }
      if (!isPlainKey || isCurrentlyDisplayingAudioPlaceholder()) return;
      viewerState.currentRotation += 90;
      applyFitState();
      updateFullscreenStyles();
      // 回転後のバウンディングボックスを同期確定させ、後続のウィンドウリサイズ計算へ反映
      void viewerUI.elements.viewerImg.offsetHeight;
      viewerUI.updateImageRendering();
      resizeWindowToFitImage();
      break;
    case 'ArrowDown':
      if (isShiftOnly) {
        if (isPlayableMedia(getActivePlaybackMedia())) {
          e.preventDefault();
          adjustActiveMediaVolumeByPercent(-5);
        }
        break;
      }
      if (!isPlainKey || isCurrentlyDisplayingAudioPlaceholder()) return;
      viewerState.currentRotation -= 90;
      applyFitState();
      updateFullscreenStyles();
      // 回転後のバウンディングボックスを同期確定させ、後続のウィンドウリサイズ計算へ反映
      void viewerUI.elements.viewerImg.offsetHeight;
      viewerUI.updateImageRendering();
      resizeWindowToFitImage();
      break;
    case 'f':
    case 'F': {
      e.preventDefault();
      viewerState.isImmersiveArranged = false;
      const { width: natW, height: natH } = getNaturalDimensions();

      const monitorW = window.screen.availWidth;
      const monitorH = window.screen.availHeight;

      let targetW = natW;
      let targetH = natH;

      // モニターより大きい場合は画面に収まるように縮小
      if (targetW > monitorW || targetH > monitorH) {
        const scale = Math.min(monitorW / targetW, monitorH / targetH);
        targetW = Math.floor(targetW * scale);
        targetH = Math.floor(targetH * scale);
      }

      if (window.veloceAPI && window.veloceAPI.resizeViewerWindow) {
        window.veloceAPI.resizeViewerWindow(targetW, targetH);
      }

      resetZoomAndFit();
      break;
    }
    case ' ': {
      e.preventDefault();
      viewerState.isImmersiveArranged = false;
      const { width: natW, height: natH } = getNaturalDimensions();

      if (window.veloceAPI && window.veloceAPI.resizeViewerWindow) {
        window.veloceAPI.resizeViewerWindow(natW, natH);
      }

      resetZoomAndFit();
      break;
    }
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5': {
      e.preventDefault();
      let rating = parseInt(e.key.replace('Numpad', ''), 10);
      const filePath = viewerState.currentImagePath;
      if (filePath && window.veloceAPI.setRating) {
        const currentRating = viewerRatings[filePath] || 0;
        if (currentRating === rating) {
          rating = 0;
        }

        window.veloceAPI.setRating(filePath, rating);
      }
      break;
    }
    case 'Escape':
      if (isVolumePopupOpen()) {
        e.preventDefault();
        closeVolumePopup();
        return;
      }
      if (window.veloceAPI && window.veloceAPI.closeWindow) {
        window.veloceAPI.closeWindow();
      }
      break;
    case 'F11':
      e.preventDefault(); // ブラウザ標準のフルスクリーン動作を防ぐ
      window.veloceAPI.toggleViewerFullscreen();
      break;
    case 'a':
    case 'A':
      if (isCurrentlyDisplayingAudio()) return;
      e.preventDefault();
      toggleAlphaOverlayMode();
      break;
    case 'l':
    case 'L':
      if (window.veloceAPI.arrangeViewers) {
        window.veloceAPI.arrangeViewers();
      }
      break;
    case 's':
    case 'S':
      toggleVideoSeekBar();
      break;
    case 'b':
    case 'B':
      viewerState.isBorderVisible = !viewerState.isBorderVisible;
      viewerUI.applyBorderVisibility();
      break;
    case 'i':
    case 'I':
      e.preventDefault();
      toggleMetadataOverlay();
      break;
    case 'u':
    case 'U':
      if (isCurrentlyDisplayingAudio()) return;
      viewerState.isUnsharped = !viewerState.isUnsharped;
      viewerUI.updateImageRendering();
      break;
    case 'h':
    case 'H':
      if (isCurrentlyDisplayingAudioPlaceholder()) return;
      viewerState.flipX *= -1;
      viewerUI.updateImageRendering();
      break;
    case 'v':
    case 'V':
      if (isCurrentlyDisplayingAudioPlaceholder()) return;
      viewerState.flipY *= -1;
      viewerUI.updateImageRendering();
      break;
  }
  
  if (e.key === 'Delete') {
    if (viewerState.currentImagePath) {
      const deletedPath = viewerState.currentImagePath;
      const success = await window.veloceAPI.trashFile(deletedPath);
      if (success) {
        if (window.veloceAPI.notifyFileRemoved) {
          // メイン画面に通知し、そこからbroadcastされる `viewer-list-updated` イベントで画像の切り替えを処理する
          await window.veloceAPI.notifyFileRemoved(deletedPath);
        } else {
          // APIがない場合のフォールバック
          viewerState.paths.splice(viewerState.currentIndex, 1);
          viewerState.totalImages = viewerState.paths.length;
          if (viewerState.paths.length > 0) {
            if (viewerState.currentIndex >= viewerState.paths.length) {
              viewerState.currentIndex = viewerState.paths.length - 1;
            }
            loadImage(); 
          } else {
            if (window.veloceAPI && window.veloceAPI.closeWindow) window.veloceAPI.closeWindow();
          }
        }
      }
    }
  }

  if (e.ctrlKey && (e.key === 'c' || e.key === 'C')) {
    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 0) {
      showToast('テキストをクリップボードにコピーしました', 2000, 'success');
      return;
    }

    if (viewerState.currentImagePath) {
      window.veloceAPI.copyImageToClipboard(viewerState.currentImagePath);
      // 画像のコピーとシャッターフラッシュエフェクトの適用
      let flash = document.getElementById('viewer-flash-effect');
      if (!flash) {
        flash = document.createElement('div');
        flash.id = 'viewer-flash-effect';
        document.body.appendChild(flash);
      }
      
      flash.style.transition = 'none';
      flash.style.opacity = '0.35';
      
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          flash.style.transition = '';
          flash.style.opacity = '0';
        });
      });

      // コピー完了を通知するトーストの表示
      showToast('画像をクリップボードにコピーしました', 3000, 'success');
	}
  }
});

// --- 拡大縮小率の表示更新 ---
function updateScaleDisplay() {
  const scaleDisplay = document.getElementById('window-scale-display');
  const controls = document.getElementById('window-controls');
  if (!scaleDisplay || !controls) return;

  let currentScale = 1.0;
  if (viewerState.isZoomed) {
    currentScale = viewerState.currentScale;
  } else {
    const { width: natW, height: natH } = getNaturalDimensions();
    if (natW > 0 && natH > 0) {
      if (viewerState.isFitToWindow) {
        currentScale = Math.min(window.innerWidth / natW, window.innerHeight / natH);
      } else {
        currentScale = Math.min(1.0, window.innerWidth / natW, window.innerHeight / natH);
      }
    }
  }

  const percent = Math.round(currentScale * 100);
  if (percent !== 100) {
    scaleDisplay.textContent = `${percent}%`;
    scaleDisplay.style.display = 'flex';
  } else {
    scaleDisplay.style.display = 'none';
  }
  if (typeof updateInfoContainerVisibility === 'function') updateInfoContainerVisibility();
};

// --- レーティングの表示更新 ---
function updateRatingDisplay() {
  const display = document.getElementById('viewer-rating-display');
  if (!display) return;

  const filePath = viewerState.currentImagePath;
  if (!filePath) {
    display.style.display = 'none';
    if (typeof updateInfoContainerVisibility === 'function') updateInfoContainerVisibility();
    return;
  }

  const rating = viewerRatings[filePath] || 0;
  if (rating > 0) {
    const starSvg = '<svg class="rating-star-icon" viewBox="0 0 24 24" width="14" height="14"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
    display.innerHTML = starSvg + '<span>' + rating + '</span>';
    display.style.display = 'flex';
  } else {
    display.style.display = 'none';
  }
  if (typeof updateInfoContainerVisibility === 'function') updateInfoContainerVisibility();
}

function updateInfoContainerVisibility() {
  const infoContainer = document.getElementById('window-info-container');
  const scaleDisplay = document.getElementById('window-scale-display');
  const ratingDisplay = document.getElementById('viewer-rating-display');
  const controls = document.getElementById('window-controls');
  if (!infoContainer || !controls) return;

  const hasScale = scaleDisplay && scaleDisplay.style.display !== 'none';
  const hasRating = ratingDisplay && ratingDisplay.style.display !== 'none';

  if (hasScale || hasRating) {
    infoContainer.style.display = 'flex';
    controls.classList.add('showing-scale');
  } else {
    infoContainer.style.display = 'none';
    controls.classList.remove('showing-scale');
  }
}

window.updateScaleDisplay = updateScaleDisplay;

let videoSeekBarContainer = null;
let volumePopupElement = null;
let volumeBtnElement = null;
let isVolumePopupOutsideListenerBound = false;

/**
 * 音量ポップアップが現在開いているかを返す。
 * @returns {boolean} 開いていれば true
 */
function isVolumePopupOpen() {
  return Boolean(volumePopupElement && volumePopupElement.style.display === 'flex');
}

/**
 * 音量ポップアップの表示状態と関連 ARIA 属性を同期する。
 * @param {boolean} open 表示する場合は true
 */
function setVolumePopupOpen(open) {
  if (!volumePopupElement) return;
  const nextOpen = Boolean(open);
  volumePopupElement.style.display = nextOpen ? 'flex' : 'none';
  if (videoSeekBarContainer) {
    videoSeekBarContainer.classList.toggle('volume-popup-open', nextOpen);
  }
  if (volumeBtnElement) {
    volumeBtnElement.setAttribute('aria-expanded', nextOpen ? 'true' : 'false');
  }
}

/**
 * 音量ポップアップを閉じる。
 */
function closeVolumePopup() {
  setVolumePopupOpen(false);
}

function isDefaultSeekBarEnabled() {
  return (typeof window !== 'undefined' && window.SettingsStore
    ? window.SettingsStore.getItem('showViewerSeekBar')
    : (typeof localStorage !== 'undefined' ? localStorage.getItem('showViewerSeekBar') : null)) === 'true';
}

function ensureVideoSeekBarContainer() {
  if (videoSeekBarContainer) {
    if (!videoSeekBarContainer.isConnected && document.body) {
      document.body.appendChild(videoSeekBarContainer);
    }
    return videoSeekBarContainer;
  }

  videoSeekBarContainer = document.createElement('div');
  videoSeekBarContainer.id = 'video-controls-container';
  
  const playBtn = document.createElement('button');
  playBtn.id = 'video-play-btn';
  const playIcon = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M8 5v14l11-7z"/></svg>';
  const pauseIcon = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>';
  playBtn.innerHTML = pauseIcon; // 初期状態は再生中なのでポーズアイコン

  const seekBar = document.createElement('input');
  seekBar.type = 'range';
  seekBar.id = 'video-seek-bar';
  seekBar.min = 0;
  seekBar.max = 100;
  seekBar.step = 0.1;
  seekBar.value = 0;

  const timeDisplay = document.createElement('div');
  timeDisplay.id = 'video-time-display';
  timeDisplay.innerText = '0:00 / 0:00';

  const volumeOnIcon = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg>';
  const volumeZeroIcon = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon></svg>';
  const volumeMutedIcon = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>';

  const actionsContainer = document.createElement('div');
  actionsContainer.id = 'video-controls-actions';

  const volumeWrapper = document.createElement('div');
  volumeWrapper.id = 'video-volume-btn-wrapper';

  const volumeBtn = document.createElement('button');
  volumeBtn.id = 'video-volume-btn';
  volumeBtn.type = 'button';
  volumeBtn.title = '音量';
  volumeBtn.setAttribute('aria-haspopup', 'true');
  volumeBtn.setAttribute('aria-expanded', 'false');
  volumeBtn.setAttribute('aria-controls', 'video-volume-popup');
  volumeBtnElement = volumeBtn;

  const volumePopup = document.createElement('div');
  volumePopup.id = 'video-volume-popup';
  volumePopup.style.display = 'none';
  volumePopupElement = volumePopup;

  const volumeSliderWrapper = document.createElement('div');
  volumeSliderWrapper.id = 'video-volume-slider-wrapper';

  const volumeSlider = document.createElement('input');
  volumeSlider.type = 'range';
  volumeSlider.id = 'video-volume-slider';
  volumeSlider.min = 0;
  volumeSlider.max = 1;
  volumeSlider.step = 0.01;
  volumeSlider.value = String(getSavedViewerVolume());
  volumeSlider.title = '音量';

  const muteBtn = document.createElement('button');
  muteBtn.id = 'video-mute-btn';
  muteBtn.type = 'button';
  muteBtn.title = 'ミュート切替';

  volumeSliderWrapper.appendChild(volumeSlider);
  volumePopup.appendChild(volumeSliderWrapper);
  volumePopup.appendChild(muteBtn);
  volumeWrapper.appendChild(volumeBtn);
  volumeWrapper.appendChild(volumePopup);
  actionsContainer.appendChild(volumeWrapper);

  videoSeekBarContainer.appendChild(playBtn);
  videoSeekBarContainer.appendChild(seekBar);
  videoSeekBarContainer.appendChild(timeDisplay);
  videoSeekBarContainer.appendChild(actionsContainer);
  document.body.appendChild(videoSeekBarContainer);

  // シークバー・音量ポップアップ操作時に画面のパン（移動）やクリック判定が誤爆するのを防ぐ
  const stopPropagation = (e) => e.stopPropagation();
  ['mousedown', 'mousemove', 'mouseup', 'wheel', 'click', 'dblclick', 'contextmenu'].forEach(event => {
    videoSeekBarContainer.addEventListener(event, stopPropagation);
    volumePopup.addEventListener(event, stopPropagation);
  });

  if (!isVolumePopupOutsideListenerBound) {
    isVolumePopupOutsideListenerBound = true;
    const handleOutsidePopupPointer = (e) => {
      if (!isVolumePopupOpen()) return;
      if (volumeWrapper && !volumeWrapper.contains(e.target)) {
        closeVolumePopup();
      }
    };
    // コントロールバーの stopPropagation によりバブルが止まる要素（シークバー等）やバー外クリックも捕捉するためキャプチャフェーズで監視
    document.addEventListener('mousedown', handleOutsidePopupPointer, true);
    document.addEventListener('click', handleOutsidePopupPointer, true);
  }

  // グローバルキャプチャリングフェーズでのメディアイベント監視
  // DOMに追加される各video/audio要素にリスナーを個別にバインドするコストを削減
  document.addEventListener('timeupdate', (e) => {
    const activeMedia = getActivePlaybackMedia();
    if (videoSeekBarContainer && videoSeekBarContainer.style.display !== 'none' && e.target === activeMedia) {
      videoSeekBarContainer.updateProgress();
    }
  }, true);

  document.addEventListener('play', (e) => {
    const activeMedia = getActivePlaybackMedia();
    if (videoSeekBarContainer && videoSeekBarContainer.style.display !== 'none' && e.target === activeMedia) {
      videoSeekBarContainer.updatePlayStateIcon();
    }
  }, true);

  document.addEventListener('pause', (e) => {
    const activeMedia = getActivePlaybackMedia();
    if (videoSeekBarContainer && videoSeekBarContainer.style.display !== 'none' && e.target === activeMedia) {
      videoSeekBarContainer.updatePlayStateIcon();
    }
  }, true);

  document.addEventListener('ended', (e) => {
    const activeMedia = getActivePlaybackMedia();
    if (videoSeekBarContainer && videoSeekBarContainer.style.display !== 'none' && e.target === activeMedia) {
      videoSeekBarContainer.updatePlayStateIcon();
    }
  }, true);

  let isSeeking = false;

  playBtn.addEventListener('click', () => {
    const activeMedia = getActivePlaybackMedia();
    if (isPlayableMedia(activeMedia)) {
      if (activeMedia.paused) {
        activeMedia.play();
      } else {
        activeMedia.pause();
      }
    }
    playBtn.blur();
  });

  let lastPausedState = null;
  videoSeekBarContainer.updatePlayStateIcon = () => {
    const activeMedia = getActivePlaybackMedia();
    if (isPlayableMedia(activeMedia)) {
      if (activeMedia.paused !== lastPausedState) {
        lastPausedState = activeMedia.paused;
        playBtn.innerHTML = activeMedia.paused ? playIcon : pauseIcon;
      }
    }
  };

  let lastVolumeBtnState = null;
  let lastMutedIconState = null;
  videoSeekBarContainer.updateVolumeControls = () => {
    const activeMedia = getActivePlaybackMedia();
    const rawVol = isPlayableMedia(activeMedia) ? activeMedia.volume : getSavedViewerVolume();
    const vol = (typeof rawVol === 'number' && !isNaN(rawVol)) ? Math.max(0, Math.min(1, rawVol)) : 1;
    const muted = isPlayableMedia(activeMedia) ? activeMedia.muted : getSavedViewerMuted(false);
    volumeSlider.value = String(vol);

    const nextVolumeBtnState = muted ? 'muted' : (vol === 0 ? 'zero' : 'on');
    if (nextVolumeBtnState !== lastVolumeBtnState) {
      lastVolumeBtnState = nextVolumeBtnState;
      volumeBtn.innerHTML = muted
        ? volumeMutedIcon
        : (vol === 0 ? volumeZeroIcon : volumeOnIcon);
    }

    if (muted !== lastMutedIconState) {
      lastMutedIconState = muted;
      muteBtn.innerHTML = muted ? volumeMutedIcon : volumeOnIcon;
      muteBtn.setAttribute('aria-pressed', muted ? 'true' : 'false');
    }
  };
  videoSeekBarContainer.updateVolumeControls();

  volumeBtn.addEventListener('click', () => {
    const nextOpen = !isVolumePopupOpen();
    setVolumePopupOpen(nextOpen);
    if (nextOpen && videoSeekBarContainer.updateVolumeControls) {
      videoSeekBarContainer.updateVolumeControls();
    }
    volumeBtn.blur();
  });

  muteBtn.addEventListener('click', () => {
    const activeMedia = getActivePlaybackMedia();
    const currentMuted = isPlayableMedia(activeMedia) ? activeMedia.muted : getSavedViewerMuted(false);
    const nextMuted = !currentMuted;
    writeViewerSetting(VIEWER_MUTED_KEY, nextMuted ? 'true' : 'false');
    if (isPlayableMedia(activeMedia)) {
      activeMedia.muted = nextMuted;
    }
    videoSeekBarContainer.updateVolumeControls();
    muteBtn.blur();
  });

  volumeSlider.addEventListener('input', () => {
    const rawVal = parseFloat(volumeSlider.value);
    const vol = isNaN(rawVal) ? 1 : Math.max(0, Math.min(1, rawVal));
    writeViewerSetting(VIEWER_VOLUME_KEY, String(vol));
    const activeMedia = getActivePlaybackMedia();
    if (isPlayableMedia(activeMedia)) {
      try {
        activeMedia.volume = vol;
      } catch (e) {}
    }
    videoSeekBarContainer.updateVolumeControls();
  });

  volumeSlider.addEventListener('change', () => {
    volumeSlider.blur();
  });

  volumeSlider.addEventListener('mouseup', () => {
    volumeSlider.blur();
  });

  seekBar.addEventListener('input', () => {
    isSeeking = true;
    const activeMedia = getActivePlaybackMedia();
    if (isPlayableMedia(activeMedia) && activeMedia.duration) {
      const time = (seekBar.value / 100) * activeMedia.duration;
      activeMedia.currentTime = time;
      const nextText = formatDurationSeconds(time) + ' / ' + formatDurationSeconds(activeMedia.duration);
      if (timeDisplay.textContent !== nextText) {
        timeDisplay.textContent = nextText;
      }
    }
  });

  seekBar.addEventListener('change', () => {
    isSeeking = false;
    seekBar.blur();
  });

  seekBar.addEventListener('mouseup', () => {
    seekBar.blur();
  });

  // マウスカーソルがシークバー領域から離れた際、内部コントロールのフォーカスを解除して
  // ホバー解除とともに確実に元の透明度へ戻し、スペースキー等のキーボードショートカットとの競合を防ぐ
  videoSeekBarContainer.addEventListener('mouseleave', () => {
    if (videoSeekBarContainer.contains(document.activeElement)) {
      document.activeElement.blur();
    }
  });

  videoSeekBarContainer.updateProgress = () => {
    if (isSeeking) return;
    const activeMedia = getActivePlaybackMedia();
    if (isPlayableMedia(activeMedia) && activeMedia.duration) {
      seekBar.value = (activeMedia.currentTime / activeMedia.duration) * 100;
      const nextText = formatDurationSeconds(activeMedia.currentTime) + ' / ' + formatDurationSeconds(activeMedia.duration);
      if (timeDisplay.textContent !== nextText) {
        timeDisplay.textContent = nextText;
      }
      videoSeekBarContainer.updatePlayStateIcon();
    }
  };

  return videoSeekBarContainer;
}

function setVideoSeekBarVisibility(visible) {
  const activeMedia = getActivePlaybackMedia();
  if (!visible || !isPlayableMedia(activeMedia)) {
    closeVolumePopup();
    if (videoSeekBarContainer) {
      videoSeekBarContainer.style.display = 'none';
    }
    return;
  }

  ensureVideoSeekBarContainer();
  if (videoSeekBarContainer.updatePlayStateIcon) {
    videoSeekBarContainer.updatePlayStateIcon();
  }
  if (videoSeekBarContainer.updateVolumeControls) {
    videoSeekBarContainer.updateVolumeControls();
  }
  if (videoSeekBarContainer.updateProgress) {
    videoSeekBarContainer.updateProgress();
  }
  videoSeekBarContainer.style.display = 'flex';
}

function toggleVideoSeekBar() {
  const activeMedia = getActivePlaybackMedia();
  if (!isPlayableMedia(activeMedia)) {
    showToast("動画・音声ではありません", 3000, 'warning');
    return;
  }

  ensureVideoSeekBarContainer();
  const isVisible = videoSeekBarContainer.style.display === 'flex';
  setVideoSeekBarVisibility(!isVisible);
}

export { loadImage, getMediaWidth, getMediaHeight, swapImageElement };

if (typeof window !== 'undefined') {
  window.loadImage = loadImage;
  window.isDefaultSeekBarEnabled = isDefaultSeekBarEnabled;
  window.ensureVideoSeekBarContainer = ensureVideoSeekBarContainer;
  window.setVideoSeekBarVisibility = setVideoSeekBarVisibility;
  window.toggleVideoSeekBar = toggleVideoSeekBar;
  window.getActivePlaybackMedia = getActivePlaybackMedia;
  window.stopAndDiscardAudio = stopAndDiscardAudio;
  window.getSavedViewerVolume = getSavedViewerVolume;
  window.getSavedViewerMuted = getSavedViewerMuted;
  window.applyVolumeSettingsToMedia = applyVolumeSettingsToMedia;
  window.showNext = showNext;
  window.showPrev = showPrev;
  window.handleWheel = handleWheel;
}

window.addEventListener('beforeunload', () => {
  if (typeof dragRafId !== 'undefined' && dragRafId) {
    cancelAnimationFrame(dragRafId);
    dragRafId = null;
  }
  if (typeof window._resizeRafId !== 'undefined' && window._resizeRafId) {
    cancelAnimationFrame(window._resizeRafId);
    window._resizeRafId = null;
  }
});
