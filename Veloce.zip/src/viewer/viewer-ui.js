import { viewerState } from './viewer-state.js';
import { applyGlowEffect as glowElement } from '../common/utils.js';

/**
 * ビューア画面のUIとDOM操作を管理するクラス
 */
class ViewerUI {
  static ICONS = {
    MINIMIZE: `<svg viewBox="0 0 10 1" width="10" height="1"><rect width="10" height="1" fill="currentColor"/></svg>`,
    MAXIMIZE: `<svg viewBox="0 0 10 10" width="10" height="10"><rect width="10" height="10" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
    RESTORE: `<svg viewBox="0 0 10 10" width="10" height="10"><rect x="1" y="3" width="6" height="6" fill="none" stroke="currentColor" stroke-width="1"/><polyline points="3,3 3,1 9,1 9,7 7,7" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
    CLOSE: `<svg viewBox="0 0 10 10" width="10" height="10"><path d="M0,0 L10,10 M10,0 L0,10" stroke="currentColor" stroke-width="1"/></svg>`
  };

  /**
   * @param {ViewerState} state - ビューア状態のインスタンス
   */
  constructor(state) {
    this.state = state;
    this.elements = {
      viewerImg: document.getElementById('viewer-img')
    };
  }

  /**
   * 画像の変形（ズーム・パン・回転）とフィルター（シャープネス）を適用し、画面の描画を更新します。
   */
  updateImageRendering() {
    if (!this.elements.viewerImg) return;
    let filters = [];
    if (this.state.isUnsharped) filters.push('url(#unsharp-filter)');
    this.elements.viewerImg.style.filter = filters.length > 0 ? filters.join(' ') : 'none';
    
    if (this.state.isImmersiveArranged) {
      let r = ((this.state.currentRotation % 360) + 360) % 360;
      let tx = this.state.currentTranslateX * this.state.flipX;
      let ty = this.state.currentTranslateY * this.state.flipY;
      let posX = tx;
      let posY = ty;

      if (r === 90) {
        posX = ty;
        posY = -tx;
      } else if (r === 180) {
        posX = -tx;
        posY = -ty;
      } else if (r === 270) {
        posX = -ty;
        posY = tx;
      }
      
      let comp = this.state.compensateScale || 1.0;
      this.elements.viewerImg.style.objectPosition = `calc(50% + ${posX}px) calc(50% + ${posY}px)`;
      this.elements.viewerImg.style.transform = `translate(0px, 0px) scale(${this.state.flipX}, ${this.state.flipY}) rotate(${this.state.currentRotation}deg) scale(${this.state.currentScale * comp})`;
    } else {
      let comp = this.state.compensateScale || 1.0;
      this.elements.viewerImg.style.objectPosition = '50% 50%';
      this.elements.viewerImg.style.transform = `translate(${this.state.currentTranslateX}px, ${this.state.currentTranslateY}px) scale(${this.state.flipX}, ${this.state.flipY}) rotate(${this.state.currentRotation}deg) scale(${this.state.currentScale * comp})`;
    }
  }

  /**
   * フルスクリーン状態などを考慮して、ウィンドウ枠（ボーダー）とコントロールボタンの表示状態を更新します。
   */
  applyBorderVisibility() {
    if (this.state.isFullscreen) return;
    const overlay = document.getElementById('border-overlay');
    if (overlay) overlay.classList.toggle('border-hidden', !this.state.isBorderVisible);
    const controls = document.getElementById('window-controls');
    if (controls) {
      controls.classList.toggle('controls-hidden', !this.state.isBorderVisible);
      controls.classList.remove('fs-hidden');
    }
  }
  
  /**
   * 画像上のマウスカーソルの種類を変更します。
   * @param {string} type - CSSのcursorプロパティに設定する値（例: 'grab', 'default'）
   */
  setCursor(type) {
    if (this.elements.viewerImg) this.elements.viewerImg.style.cursor = type;
  }

  /**
   * アイコンや要素を発光させます。
   * @param {HTMLElement} el 対象の要素
   */
  applyGlowEffect(el) {
    glowElement(el);
  }

  /**
   * ループ境界（先頭または末尾への折り返し）到達時の視覚的フィードバックを発火します。
   * 画面両端・外周に微弱なアクセント発光（viewer-edge-glow）を適用し、軽量なトースト通知を表示します。
   * @param {'start'|'end'} boundary - 'start' (末尾から先頭へループ) または 'end' (先頭から末尾へループ)
   */
  triggerLoopFeedback(boundary) {
    const body = document.body;
    if (body) {
      if (this._edgeGlowTimer) {
        clearTimeout(this._edgeGlowTimer);
        body.classList.remove('viewer-edge-glow');
        void body.offsetWidth; // リフローを強制してアニメーションを再トリガー
      }
      body.classList.add('viewer-edge-glow');
      this._edgeGlowTimer = setTimeout(() => {
        body.classList.remove('viewer-edge-glow');
        this._edgeGlowTimer = null;
      }, 400);
    }

    const message = boundary === 'start' ? '先頭に戻りました' : '末尾に戻りました';
    const toastFn = (typeof showToast === 'function') 
      ? showToast 
      : (typeof window !== 'undefined' && typeof window.showToast === 'function')
        ? window.showToast
        : (typeof globalThis !== 'undefined' && typeof globalThis.showToast === 'function')
          ? globalThis.showToast
          : null;
    if (typeof toastFn === 'function') {
      toastFn(message, 1500, 'info');
    }
  }
}

export { ViewerUI };
export const viewerUI = new ViewerUI(viewerState);